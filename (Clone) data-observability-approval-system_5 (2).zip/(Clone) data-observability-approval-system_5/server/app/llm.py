import json
import re
from datetime import datetime
import uuid

RULE_TAXONOMY = {
    "condition_types": [
        "NOT_NULL", "BLANK", "LENGTH_CHECK", "NOT_NULL_LENGTH_CHECK",
        "MUST_HAVE_VALUE", "REGEX_MATCH", "FORMAT_CHECK", "UNIQUE",
        "DUPLICATE", "RANGE_CHECK", "VALUE_THRESHOLD", "TIME_STAMP_CHECK",
        "DATE_RANGE", "OUTLIER_DETECTION", "MAPPING_CHECK", "ROW_COUNT_TREND",
        "KPI_CHECK"
    ],
    "condition_categories": [
        "Completeness Check", "Format & Pattern Validation",
        "Uniqueness", "Timeliness", "KPI Statistics",
        "Range & Threshold Validation", "Consistency Check"
    ],
    "severities": ["Critical", "Warning", "Info"],
    "criteria_formats": {
        "NOT_NULL": "null (no criteria needed)",
        "BLANK": "null (no criteria needed)",
        "LENGTH_CHECK": '{"value": <exact_length>}',
        "NOT_NULL_LENGTH_CHECK": '{"value": <exact_length>}',
        "MUST_HAVE_VALUE": '{"value": [<allowed_values>]}',
        "REGEX_MATCH": '{"regex_pattern": "<pattern>"}',
        "FORMAT_CHECK": '{"regex_pattern": "<pattern>"}',
        "UNIQUE": '{"identifier_column": "<column_name>"}',
        "DUPLICATE": "null (columns in column_name field)",
        "RANGE_CHECK": '{"min_value": <min>, "max_value": <max>}',
        "VALUE_THRESHOLD": '{"operator": "<op>", "value_threshold": <val>}',
        "TIME_STAMP_CHECK": '{"condition": "<sql_condition>"}',
        "DATE_RANGE": '{"start_date": "<start>", "end_date": "<end>"}',
        "OUTLIER_DETECTION": '{"value": <num_std_devs>}',
        "MAPPING_CHECK": '{"value": [<mapped_values>]}',
        "ROW_COUNT_TREND": '{"interval": <days>}',
        "KPI_CHECK": '{"custom_query": "<sql>", "interval": <days>, "lower_threshold": <val>, "upper_threshold": <val>}'
    }
}

def infer_pattern(samples):
    patterns_found = []
    if not samples:
        return patterns_found
    
    email_pat = r"^[\w.+-]+@[\w-]+\.[\w.]+" + "$"
    phone_pat = r"^[\d\-\(\)\s\+]+" + "$"
    uuid_pat = r"^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}" + "$"
    hex_pat = r"^[0-9a-fA-F]+" + "$"
    iso_date_pat = r"^\d{4}-\d{2}-\d{2}"
    us_date_pat = r"^\d{2}/\d{2}/\d{4}"
    alpha_num_pat = r"^[A-Z]+\d+" + "$"
    state_pat = r"^[A-Z]{2}" + "$"
    zip_pat = r"^\d{5}(-\d{4})?" + "$"
    numeric_pat = r"^\d+" + "$"
    
    clean_samples = [s for s in samples if s and str(s).strip()]
    if not clean_samples:
        return patterns_found
    
    if all(re.match(email_pat, s) for s in clean_samples):
        patterns_found.append({"type": "email", "pattern": email_pat})
    if all(re.match(phone_pat, s) for s in clean_samples if len(s) >= 7):
        if len([s for s in clean_samples if len(s) >= 7]) == len(clean_samples):
            patterns_found.append({"type": "phone", "pattern": phone_pat})
    if all(re.match(uuid_pat, s, re.I) for s in clean_samples):
        patterns_found.append({"type": "uuid", "pattern": uuid_pat})
    if all(re.match(hex_pat, s) for s in clean_samples):
        lengths = set(len(s) for s in clean_samples)
        if len(lengths) == 1:
            L = lengths.pop()
            patterns_found.append({"type": f"hex_hash_{L}", "pattern": f"^[0-9a-fA-F]{{{L}}}" + "$"})
    if all(re.match(iso_date_pat, s) for s in clean_samples):
        patterns_found.append({"type": "date_iso", "pattern": iso_date_pat + "$"})
    elif all(re.match(us_date_pat, s) for s in clean_samples):
        patterns_found.append({"type": "date_us", "pattern": us_date_pat + "$"})
    if all(re.match(alpha_num_pat, s) for s in clean_samples):
        patterns_found.append({"type": "alpha_numeric_code", "pattern": alpha_num_pat})
    if all(re.match(state_pat, s) for s in clean_samples):
        patterns_found.append({"type": "state_code", "pattern": state_pat})
    if all(re.match(zip_pat, s) for s in clean_samples):
        patterns_found.append({"type": "zip_code", "pattern": zip_pat})
    if all(re.match(numeric_pat, s) for s in clean_samples):
        patterns_found.append({"type": "numeric_string", "pattern": numeric_pat})
    
    return patterns_found

def classify_column(col_profile, total_rows):
    distinct = col_profile.get("distinct_count", 0)
    if col_profile.get("is_potential_key"):
        return "primary_key"
    
    if total_rows > 0:
        uniqueness_ratio = distinct / total_rows
        if uniqueness_ratio > 0.95:
            return "high_cardinality_id"
        elif distinct <= 2:
            return "binary_flag"
        elif distinct <= 20:
            return "low_cardinality_categorical"
        elif distinct <= 100:
            return "medium_cardinality_categorical"
        elif uniqueness_ratio > 0.5:
            return "free_text_or_id"
    
    return "general"

def profile_table(catalog, schema, table):
    from pyspark.sql import SparkSession
    from pyspark.sql import functions as F
    spark = SparkSession.builder.getOrCreate()

    full_table = f"{catalog}.{schema}.{table}"
    df = spark.table(full_table)
    total_rows = df.count()
    schema_fields = df.schema.fields
    
    profile = {
        "table": full_table,
        "total_rows": total_rows,
        "total_columns": len(schema_fields),
        "columns": []
    }
    
    for col_info in schema_fields:
        col_name = col_info.name
        col_type = str(col_info.dataType)
        
        col_profile = {
            "column_name": col_name,
            "data_type": col_type,
            "nullable": col_info.nullable,
            "comment": col_info.metadata.get("comment", "") if col_info.metadata else ""
        }
        
        null_count = df.where(F.col(col_name).isNull()).count()
        col_profile["null_count"] = null_count
        col_profile["null_pct"] = round((null_count / total_rows * 100), 2) if total_rows > 0 else 0
        
        if "StringType" in col_type:
            blank_count = df.where(
                (F.col(col_name).isNull()) | 
                (F.trim(F.col(col_name)) == "") |
                (F.lower(F.trim(F.col(col_name))).isin("na", "null", "none", "n/a", ""))
            ).count()
            col_profile["blank_or_placeholder_count"] = blank_count
            col_profile["blank_pct"] = round((blank_count / total_rows * 100), 2) if total_rows > 0 else 0
        
        distinct_count = df.select(col_name).distinct().count()
        col_profile["distinct_count"] = distinct_count
        col_profile["is_potential_key"] = (distinct_count == total_rows and total_rows > 0)
        col_profile["uniqueness_ratio"] = round(distinct_count / total_rows, 4) if total_rows > 0 else 0
        
        if col_type in ("LongType()", "IntegerType()", "DoubleType()", "FloatType()", "DecimalType()", "ShortType()"):
            stats = df.select(
                F.min(col_name).alias("min_val"),
                F.max(col_name).alias("max_val"),
                F.avg(col_name).alias("avg_val"),
                F.stddev(col_name).alias("stddev_val"),
                F.percentile_approx(col_name, 0.25).alias("p25"),
                F.percentile_approx(col_name, 0.75).alias("p75")
            ).first()
            col_profile["min"] = str(stats["min_val"])
            col_profile["max"] = str(stats["max_val"])
            col_profile["avg"] = str(round(float(stats["avg_val"]), 2)) if stats["avg_val"] else None
            col_profile["stddev"] = str(round(float(stats["stddev_val"]), 2)) if stats["stddev_val"] else None
            col_profile["p25"] = str(stats["p25"])
            col_profile["p75"] = str(stats["p75"])
            neg_count = df.where(F.col(col_name) < 0).count()
            col_profile["has_negatives"] = neg_count > 0
            col_profile["negative_count"] = neg_count
            
        elif "StringType" in col_type:
            samples = [row[0] for row in df.select(col_name).where(F.col(col_name).isNotNull()).limit(20).collect()]
            col_profile["sample_values"] = samples[:10]
            
            len_stats = df.where(F.col(col_name).isNotNull()).select(
                F.min(F.length(col_name)).alias("min_len"),
                F.max(F.length(col_name)).alias("max_len"),
                F.avg(F.length(col_name)).alias("avg_len")
            ).first()
            if len_stats:
                col_profile["min_length"] = len_stats["min_len"]
                col_profile["max_length"] = len_stats["max_len"]
                col_profile["avg_length"] = round(float(len_stats["avg_len"]), 1) if len_stats["avg_len"] else None
                col_profile["is_fixed_length"] = (len_stats["min_len"] == len_stats["max_len"])
            
            if distinct_count <= 50:
                top_values = (
                    df.where(F.col(col_name).isNotNull())
                    .groupBy(col_name).count()
                    .orderBy(F.desc("count"))
                    .limit(15)
                    .collect()
                )
                col_profile["top_values"] = [
                    {"value": row[col_name], "count": row["count"], 
                     "pct": round(row["count"] / total_rows * 100, 1)}
                    for row in top_values
                ]
            
            detected_patterns = infer_pattern(samples[:20])
            if detected_patterns:
                col_profile["detected_patterns"] = detected_patterns
                
        elif "TimestampType" in col_type or "DateType" in col_type:
            ts_stats = df.select(
                F.min(col_name).alias("min_ts"),
                F.max(col_name).alias("max_ts")
            ).first()
            col_profile["min_date"] = str(ts_stats["min_ts"])
            col_profile["max_date"] = str(ts_stats["max_ts"])
            future_count = df.where(F.col(col_name) > F.current_timestamp()).count()
            col_profile["has_future_dates"] = future_count > 0
            col_profile["future_date_count"] = future_count
        
        elif "BooleanType" in col_type:
            true_count = df.where(F.col(col_name) == True).count()
            false_count = df.where(F.col(col_name) == False).count()
            col_profile["true_count"] = true_count
            col_profile["false_count"] = false_count
        
        col_profile["column_classification"] = classify_column(col_profile, total_rows)
        profile["columns"].append(col_profile)
    
    return profile

def recommend_dq_rules(catalog, schema, table, created_by="llm_auto_generated", chunk_size=20, max_total_rules=20):
    from pyspark.sql import SparkSession
    spark = SparkSession.builder.getOrCreate()

    profile = profile_table(catalog, schema, table)
    num_cols = len(profile['columns'])
    
    taxonomy_json = json.dumps(RULE_TAXONOMY, indent=2)
    all_rules = []
    columns_list = profile['columns']
    
    for i in range(0, num_cols, chunk_size):
        chunk_cols = columns_list[i : i + chunk_size]
        chunk_profile = {
            "table": profile["table"],
            "total_rows": profile["total_rows"],
            "total_columns": profile["total_columns"],
            "columns": chunk_cols
        }
        profile_json = json.dumps(chunk_profile, indent=2, default=str)
        
        prompt = f"""You are a senior data quality architect. Generate 15-20 MOST IMPORTANT quality rules.
=== TABLE PROFILE ===
{profile_json}
=== TAXONOMY ===
{taxonomy_json}
Return a JSON array of rules. Fields required: column_name, condition_category, condition_type, condition_criteria, rule_description, severity, violation_threshold. Use ONLY upper-case taxonomy string conditions. Return strictly the JSON array, no wrap prose."""

        escaped_prompt = prompt.replace("'", "''").replace("\\", "\\\\").replace(chr(10), ' ')
        
        try:
            result_df = spark.sql(f"""
                SELECT ai_query(
                    'databricks-meta-llama-3-3-70b-instruct',
                    '{escaped_prompt}',
                    modelParameters => named_struct('max_tokens', 8192, 'temperature', 0.15)
                ) AS rules_json
            """)
            rules_text = result_df.first()["rules_json"]
            start_idx = rules_text.find('[')
            end_idx = rules_text.rfind(']') + 1
            if start_idx != -1 and end_idx != 0:
                all_rules.extend(json.loads(rules_text[start_idx:end_idx]))
        except Exception:
            continue

    if not all_rules:
        return []

    severity_scores = {"Critical": 300, "Warning": 200, "Info": 100}
    ranked_rules = sorted(all_rules, key=lambda r: severity_scores.get(r.get("severity", "Warning"), 200), reverse=True)[:max_total_rules]

    formatted_requests = []
    for rule in ranked_rules:
        criteria = rule.get("condition_criteria")
        if criteria is not None and not isinstance(criteria, str):
            criteria = json.dumps(criteria)
            
        formatted_requests.append({
            "catalog": catalog,
            "schema": schema,
            "table_name": table,
            "column_name": rule.get("column_name", ""),
            "rule_description": rule.get("rule_description", ""),
            "condition_category": rule.get("condition_category", ""),
            "condition_type": rule.get("condition_type", ""),
            "condition_criteria": criteria,
            "severity": rule.get("severity", "Warning"),
            "violation_threshold": int(rule.get("violation_threshold", 0))
        })
    return formatted_requests