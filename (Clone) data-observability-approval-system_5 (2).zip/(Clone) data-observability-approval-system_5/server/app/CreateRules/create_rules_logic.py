# server/app/RuleManagement/metadata_logic.py (Example file name)
import uuid
import time
import requests
import re
import os
import yaml
import json

# Import config assuming it is available in the Python path
from config import config
# Shared query_table -- replaces the local copy that used to be
# duplicated in this file. See db_utils.py.
from app.db_utils import query_table


# Load config.yaml
# Always point to server/config.yaml (one level up from app/)
CONFIG_PATH = os.path.join(os.path.dirname(os.path.dirname(__file__)), "config.yaml")
# Load config.yaml
try:
    with open(CONFIG_PATH, "r") as f:
        yaml_config = yaml.safe_load(f)
except FileNotFoundError:
    # Fallback/Error handling if config.yaml is not found at the expected path
    print(f"Warning: config.yaml not found at {CONFIG_PATH}. Using mock values.")
    yaml_config = {}

# Assign values
CATALOG = yaml_config.get("catalog")
SCHEMA = yaml_config.get("schema")
RULE_REQUESTS_TABLE = yaml_config.get("rule_requests_table")
GROUPS_TABLE=yaml_config.get("group_table")
TABLES_TABLE=yaml_config.get("table_config")
# NOTE: Only the required tables are loaded, matching your configuration variables used in the functions below.


# --- HELPER FUNCTION FOR VALIDATING SQL IDENTIFIERS ---
def is_valid_identifier(name):
    """
    Checks if a string is a valid and safe SQL identifier.
    Prevents SQL injection by ensuring the string contains only 
    alphanumeric characters and underscores.
    """
    if not isinstance(name, str) or not name:
        return False
    # Regular expression to check for alphanumeric characters and underscores
    return re.match(r'^[a-zA-Z0-9_]+$', name) is not None


# --- GET METADATA FUNCTIONS ---
def get_catalogs():
    """
    Fetches ALL catalogs visible to the app's service principal (that its
    token has permission to see), using SHOW CATALOGS.
    Internal/system catalogs are filtered out.
    """
    rows = query_table("get_catalogs", "SHOW CATALOGS")
    hidden = {"__databricks_internal", "system"}
    catalogs = [
        {"catalog_name": row["catalog"]}
        for row in rows
        if row.get("catalog") and row["catalog"] not in hidden
    ]
    return catalogs

def get_schemas(catalog_name):
    """Fetches schemas for a given catalog by dynamically injecting a validated catalog name."""
    if not is_valid_identifier(catalog_name):
        raise ValueError("Invalid catalog name provided.")
        
    query = f"""
        SELECT DISTINCT
            schema_name 
        FROM {catalog_name}.information_schema.schemata
        WHERE catalog_name = :catalog_name ORDER BY schema_name
    """
    params = [
        {"name": "catalog_name", "type": "STRING", "value": catalog_name}
    ]
    return query_table("get_schemas", query, params)

def get_tables(catalog_name, schema_name):
    """Fetches tables for a given catalog and schema by dynamically injecting validated names."""
    if not is_valid_identifier(catalog_name) or not is_valid_identifier(schema_name):
        raise ValueError("Invalid catalog or schema name provided.")

    query = f"""
        SELECT DISTINCT
            table_name
        FROM {catalog_name}.information_schema.tables
        WHERE table_catalog = :catalog_name
        AND table_schema = :schema_name ORDER BY table_name
    """
    params = [
        {"name": "catalog_name", "type": "STRING", "value": catalog_name},
        {"name": "schema_name", "type": "STRING", "value": schema_name}
    ]
    return query_table("get_tables", query, params)

def get_columns(catalog_name, schema_name, table_name):
    """Fetches columns for a given catalog, schema, and table by dynamically injecting validated names."""
    if not is_valid_identifier(catalog_name) or not is_valid_identifier(schema_name) or not is_valid_identifier(table_name):
        raise ValueError("Invalid catalog, schema, or table name provided.")

    query = f"""
        SELECT
            column_name,
            data_type
        FROM {catalog_name}.information_schema.columns
        WHERE table_catalog = :catalog_name
        AND table_schema = :schema_name
        AND table_name = :table_name ORDER BY ordinal_position
    """
    params = [
        {"name": "catalog_name", "type": "STRING", "value": catalog_name},
        {"name": "schema_name", "type": "STRING", "value": schema_name},
        {"name": "table_name", "type": "STRING", "value": table_name}
    ]
    return query_table("get_columns", query, params)


# # --- INSERT RULE FUNCTION (PARAMETERIZED) ---
# def insert_rule(data):
#     """
#     Inserts a new rule request into the rules table.
#     Uses globally loaded CONFIG variables (CATALOG, SCHEMA, RULE_REQUESTS_TABLE).
#     """
#     global CATALOG, SCHEMA, RULE_REQUESTS_TABLE
    
#     # Check if config is loaded
#     if not all([CATALOG, SCHEMA, RULE_REQUESTS_TABLE]):
#         raise Exception("Configuration variables (CATALOG, SCHEMA, RULE_REQUESTS_TABLE) are missing.")

#     # Generate a unique request_id
#     request_id = str(uuid.uuid4())
    
#     # Sanitize violation_threshold
#     violation_threshold = data.get("violation_threshold")
#     if not violation_threshold or str(violation_threshold).lower() in ('none', 'null', ''):
#         safe_threshold = None  # Will be inserted as NULL
#     else:
#         try:
#             safe_threshold = int(violation_threshold)  
#         except (ValueError, TypeError):
#             safe_threshold = None
    
#     # PARAMETERIZATION CHANGE: Table path is constructed using f-string
#     query = f"""
#         INSERT INTO {CATALOG}.{SCHEMA}.{RULE_REQUESTS_TABLE}
#         (request_id, catalog, schema, table_name, column_name, rule_description,
#          status, created_by, created_at, condition_category,
#          condition_type, condition_criteria, operation, severity, violation_threshold)
#         VALUES (:request_id, :catalog, :schema, :table_name, :column_name, :rule_description,
#                 'PENDING', :created_by, current_timestamp(),
#                 :condition_category, :condition_type, :condition_criteria,
#                 :operation, :severity, :violation_threshold)
#     """
    
#     params = [
#         {"name": "request_id", "type": "STRING", "value": request_id},
#         {"name": "catalog", "type": "STRING", "value": data["catalog"]},
#         {"name": "schema", "type": "STRING", "value": data["schema"]},
#         {"name": "table_name", "type": "STRING", "value": data["table_name"]},
#         {"name": "column_name", "type": "STRING", "value": data["column_name"]},
#         {"name": "rule_description", "type": "STRING", "value": data["rule_description"]},
#         {"name": "condition_category", "type": "STRING", "value": data["condition_category"]},
#         {"name": "condition_type", "type": "STRING", "value": data["condition_type"]},
#         {"name": "condition_criteria", "type": "STRING", "value": data["condition_criteria"]},
#         {"name": "operation", "type": "STRING", "value": data["operation"]},
#         {"name": "severity", "type": "STRING", "value": data["severity"]},
#         {"name": "violation_threshold", "type": "INT", "value": safe_threshold}, 
#         {"name": "created_by", "type": "STRING", "value": str(data["created_by"])}
#     ]
    
#     query_table("insert_rule", query, params)
    
#     return {"request_id": request_id}

# Assuming these global variables are defined elsewhere:
# CATALOG = "ds_training_1"
# SCHEMA = "dq_config"
# GROUPS_TABLE = "groups"
# TABLES_TABLE = "tables"

# --- NEW METADATA FUNCTION (PARAMETERIZED) ---
def get_group_id_by_name(group_name):
    """Fetches the group_id for a given group_name."""
    catalog, schema = CATALOG, SCHEMA

    # Use f-strings to dynamically construct the table path
    query = f"""
        SELECT group_id
        FROM {catalog}.{schema}.{GROUPS_TABLE}
        WHERE group_name = :group_name
    """
    params = [
        {"name": "group_name", "type": "STRING", "value": group_name}
    ]
    
    result = query_table("get_group_id", query, params)
    
    if result and len(result) > 0:
        return result[0]['group_id']
    else:
        # Raise a specific error if the required group is missing
        raise ValueError(f"Approvers group '{group_name}' not found in {catalog}.{schema}.{GROUPS_TABLE}.")

# --- INSERT RULE HELPER (PARAMETERIZED) ---
def check_and_add_table_to_approvers(catalog, schema, table_name):
    """
    Checks if the table is in the 'Approvals' group and adds it if it's not.
    The group ID is dynamically fetched.
    """
    gov_catalog, gov_schema = CATALOG, SCHEMA

    # 1. Dynamically fetch the Group ID for 'Approvers'
    APPROVERS_GROUP_ID = get_group_id_by_name("Approvers")
    
    # 2. Check if the table is already linked to the Approvers group
    # Use f-strings to dynamically construct the table path
    check_query = f"""
        SELECT count(*) AS count
        FROM {gov_catalog}.{gov_schema}.{TABLES_TABLE}
        WHERE group_id = :group_id
          AND catalog_name = :catalog
          AND schema_name = :schema
          AND table_name = :table_name
    """
    check_params = [
        {"name": "group_id", "type": "STRING", "value": APPROVERS_GROUP_ID},
        {"name": "catalog", "type": "STRING", "value": catalog},
        {"name": "schema", "type": "STRING", "value": schema},
        {"name": "table_name", "type": "STRING", "value": table_name}
    ]
    
    # query_table returns a list of dictionaries for SELECT queries
    check_result = query_table("check_approvers_group", check_query, check_params)
    print(check_result)
    # Ensure result is valid and check the count
    count = check_result[0]['count'] if check_result and len(check_result) > 0 else 0
    print(count)
    # FIX: count is a numeric value (int) from COUNT(*), but was being
    # compared against the string '0' -- always False in Python regardless
    # of the actual count, so this function never actually inserted a
    # missing registration from ANY call site (both the original
    # Create-Rule flow and the new auto-registration in get_tables_data()).
    # Safely convert to int before comparing, regardless of whether the
    # underlying value already comes back as int or string.
    try:
        count = int(count)
    except (TypeError, ValueError):
        count = 0
    if count == 0:
        # 3. If not found, insert the table into the Approvals group
        print(f"Adding table {catalog}.{schema}.{table_name} to Approvals group (ID: {APPROVERS_GROUP_ID}).")
        
        # Use f-strings to dynamically construct the table path
        insert_query = f"""
            INSERT INTO {gov_catalog}.{gov_schema}.{TABLES_TABLE}
            (group_id, catalog_name, schema_name, table_name)
            VALUES (:group_id, :catalog, :schema, :table_name)
        """
        insert_params = [
            {"name": "group_id", "type": "STRING", "value": APPROVERS_GROUP_ID},
            {"name": "catalog", "type": "STRING", "value": catalog},
            {"name": "schema", "type": "STRING", "value": schema},
            {"name": "table_name", "type": "STRING", "value": table_name}
        ]
        query_table("add_table_to_approvers_group", insert_query, insert_params)
        return True
    
    return False

import csv
import io

def bulk_upload_rules_from_csv(file_stream, created_by):
    r"""
    NEW: bulk-create rules from an uploaded CSV, one PENDING request per
    row -- reuses insert_rule() for each row, so every rule created this
    way goes through the exact same approval flow as one entered by hand
    in the UI; nothing here bypasses approval.

    ASSUMPTION FLAGGED: the exact CSV format/columns Antonio wants have
    not been specified yet ("Antonio has details on the way"). This
    implementation uses the most direct, reasonable mapping available --
    one CSV column per field insert_rule() already requires -- so it's
    usable today and easy to adjust once the real spec arrives (the only
    thing that needs to change is the column-name mapping below; the
    row-by-row insert_rule() reuse and per-row error reporting stay the
    same regardless of the final column names).

    Expected CSV columns (case-insensitive, order doesn't matter):
        catalog, schema, table_name, column_name, condition_category,
        condition_type, condition_criteria, rule_description, severity,
        violation_threshold, enforcement_action, email_alert_enabled,
        alert_group_id

    Required: catalog, schema, table_name, column_name, condition_category,
    condition_type, condition_criteria, severity.
    condition_criteria must be a single JSON string per cell, e.g.
    "{""regex_pattern"": ""^[A-Z]+$""}" (CSV-escaped double quotes).

    IMPORTANT for regex patterns containing a backslash (e.g. \. \d \s):
    JSON requires every backslash to be doubled, since JSON itself treats
    a single backslash as the start of its own escape sequence. A regex
    like ^[^@]+@[^@]+\.[^@]+$ must be written as
    ^[^@]+@[^@]+\\.[^@]+$ inside the JSON string -- e.g.
    "{""regex_pattern"": ""^[^@]+@[^@]+\\\\.[^@]+$""}" once CSV's own
    double-quote escaping is added on top. Forgetting this is the most
    common reason a row fails with "Invalid \escape".

    Returns: {"total": N, "succeeded": N, "failed": N, "errors": [...]}
    where errors is a list of {"row": <1-based row number>, "error": "..."}.
    """
    REQUIRED_COLUMNS = {
        "catalog", "schema", "table_name", "column_name",
        "condition_category", "condition_type", "condition_criteria", "severity",
    }
    OPTIONAL_COLUMNS = {
        "rule_description", "violation_threshold", "enforcement_action",
        "email_alert_enabled", "alert_group_id",
    }

    text_stream = io.StringIO(file_stream.read().decode("utf-8-sig"))
    reader = csv.DictReader(text_stream)

    if reader.fieldnames is None:
        raise ValueError("CSV file appears to be empty or has no header row.")

    normalized_fieldnames = {f.strip().lower(): f for f in reader.fieldnames}
    missing_required = REQUIRED_COLUMNS - set(normalized_fieldnames.keys())
    if missing_required:
        raise ValueError(
            f"CSV is missing required column(s): {', '.join(sorted(missing_required))}. "
            f"Required columns: {', '.join(sorted(REQUIRED_COLUMNS))}."
        )

    results = {"total": 0, "succeeded": 0, "failed": 0, "errors": []}

    for row_num, raw_row in enumerate(reader, start=2):  # row 1 is the header
        results["total"] += 1
        try:
            row = {k.strip().lower(): (v.strip() if isinstance(v, str) else v)
                   for k, v in raw_row.items() if k}

            missing_in_row = [c for c in REQUIRED_COLUMNS if not row.get(c)]
            if missing_in_row:
                raise ValueError(f"Missing required value(s): {', '.join(missing_in_row)}")

            # condition_criteria must be valid JSON -- fail this row clearly
            # rather than silently inserting a broken rule.
            try:
                json.loads(row["condition_criteria"])
            except json.JSONDecodeError as e:
                # FIX: a very common, non-obvious mistake here is putting a
                # regex pattern straight into the JSON without escaping its
                # backslashes -- e.g. writing \. (a valid regex escape) when
                # JSON itself requires \\. to represent that same content.
                # "Invalid \escape" is JSON's own error for exactly this
                # case, so give a specific, actionable hint instead of just
                # the raw parser error.
                hint = ""
                if "Invalid \\escape" in str(e) or "escape" in str(e).lower():
                    hint = (
                        " -- this usually means a regex pattern's backslashes "
                        "(e.g. \\.) need to be doubled for JSON (\\\\.) since "
                        "JSON itself treats a single backslash as the start "
                        "of its own escape sequence. Example: write "
                        '\\.[^@]+$ as \\\\.[^@]+$ inside the JSON string.'
                    )
                raise ValueError(f"condition_criteria is not valid JSON: {e}{hint}")

            data = {
                "catalog": row["catalog"],
                "schema": row["schema"],
                "table_name": row["table_name"],
                "column_name": row["column_name"],
                "condition_category": row["condition_category"],
                "condition_type": row["condition_type"],
                "condition_criteria": row["condition_criteria"],
                "rule_description": row.get("rule_description") or "",
                "severity": row["severity"],
                "violation_threshold": row.get("violation_threshold"),
                "enforcement_action": row.get("enforcement_action") or "BLOCK_AND_AUDIT",
                "email_alert_enabled": str(row.get("email_alert_enabled", "true")).lower() in ("true", "1", "yes"),
                "alert_group_id": row.get("alert_group_id") or None,
                "created_by": created_by or "csv_bulk_upload",
                "updated_by": created_by or "csv_bulk_upload",
                # FIX: insert_rule() reads data["operation"] directly (a
                # plain dict access, not .get()) -- this key was missing
                # entirely from every CSV row's data dict, raising a bare
                # KeyError: 'operation' on every single row regardless of
                # how well-formed the rest of the row was. Bulk CSV upload
                # only ever creates brand-new rules, so this is always
                # "CREATE".
                "operation": "CREATE",
            }

            insert_rule(data)
            results["succeeded"] += 1

        except Exception as e:
            results["failed"] += 1
            results["errors"].append({"row": row_num, "error": str(e)})

    return results


def insert_rule(data):
    """
    Inserts a new rule request into the rules table and ensures the target 
    table is associated with the 'Approvals' group.
    Uses globally loaded CONFIG variables (CATALOG, SCHEMA, RULE_REQUESTS_TABLE).
    """
    gov_catalog, gov_schema = CATALOG, SCHEMA

    catalog_name = data["catalog"]
    schema_name = data["schema"]
    table_name = data["table_name"]
    
    # 1. Input Validation
    if not is_valid_identifier(catalog_name) or not is_valid_identifier(schema_name) or not is_valid_identifier(table_name):
        raise ValueError("Invalid catalog, schema, or table name provided.")

    # 2. Check and Add Table to Approvers Group
    table_added=check_and_add_table_to_approvers(catalog_name, schema_name, table_name)
    
    # 3. Insert the new rule request

    # Generate a unique request_id
    request_id = str(uuid.uuid4())
    
    # Sanitize violation_threshold to handle None/malformed strings gracefully
    violation_threshold = data.get("violation_threshold")
    safe_threshold = None
    if violation_threshold is not None:
        try:
            # Convert to int if possible, otherwise keep None (which results in NULL)
            safe_threshold = int(violation_threshold)
        except (ValueError, TypeError):
            # If conversion fails, safe_threshold remains None
            pass 
    
    # Enforcement action: how the execution engine should treat records that
    # fail this rule when moving bronze -> silver. Restricted to a known set
    # so a bad/missing value from an older client can't silently disable
    # filtering; default is the safer option (block bad records + audit).
    VALID_ENFORCEMENT_ACTIONS = ("BLOCK_AND_AUDIT", "AUDIT_ONLY")
    enforcement_action = data.get("enforcement_action")
    if enforcement_action not in VALID_ENFORCEMENT_ACTIONS:
        enforcement_action = "BLOCK_AND_AUDIT"

    # Email alert toggle: defaults to enabled so existing/omitted values keep
    # today's behavior (alerts fire for every violated rule).
    email_alert_enabled = bool(data.get("email_alert_enabled", True))

    # Optional per-rule alert group override.
    # group_id is a UUID (contains hyphens) — validate against that shape.
    alert_group_id = data.get("alert_group_id") or None
    if alert_group_id is not None and not re.fullmatch(r"[0-9a-fA-F\-]{8,36}", str(alert_group_id)):
        alert_group_id = None

    # PARAMETERIZATION: Table path is constructed using f-string
    query = f"""
        INSERT INTO {gov_catalog}.{gov_schema}.{RULE_REQUESTS_TABLE}
        (request_id, catalog, schema, table_name, column_name, rule_description,
         status, created_by, updated_by, created_at, condition_category,
         condition_type, condition_criteria, operation, severity, violation_threshold,
         enforcement_action, email_alert_enabled, alert_group_id)
        VALUES (:request_id, :catalog, :schema, :table_name, :column_name, :rule_description,
                 'PENDING', :created_by, :updated_by, current_timestamp(),
                 :condition_category, :condition_type, :condition_criteria,
                 :operation, :severity, :violation_threshold, :enforcement_action,
                 :email_alert_enabled, :alert_group_id)
    """
    
    # Determine updated_by: prefer the value sent by the UI; fall back to
    # created_by for older clients (but never fall back to 'llm_generated',
    # since that is a system marker, not a real user).
    safe_updated_by = data.get("updated_by")
    if not safe_updated_by and str(data.get("created_by", "")) != "llm_generated":
        safe_updated_by = str(data["created_by"])

    params = [
        {"name": "request_id", "type": "STRING", "value": request_id},
        {"name": "catalog", "type": "STRING", "value": catalog_name},
        {"name": "schema", "type": "STRING", "value": schema_name},
        {"name": "table_name", "type": "STRING", "value": table_name},
        {"name": "column_name", "type": "STRING", "value": data["column_name"]},
        {"name": "rule_description", "type": "STRING", "value": data["rule_description"]},
        {"name": "condition_category", "type": "STRING", "value": data["condition_category"]},
        {"name": "condition_type", "type": "STRING", "value": data["condition_type"]},
        {"name": "condition_criteria", "type": "STRING", "value": data["condition_criteria"]},
        {"name": "operation", "type": "STRING", "value": data["operation"]},
        {"name": "severity", "type": "STRING", "value": data["severity"]},
        {"name": "violation_threshold", "type": "INT", "value": safe_threshold}, # Correctly passes Python None as SQL NULL
        {"name": "created_by", "type": "STRING", "value": str(data["created_by"])},
        # updated_by: the actual user submitting the request. Falls back to
        # created_by for older clients that don't send it (unless created_by
        # is the system marker 'llm_generated', in which case NULL).
        {"name": "updated_by", "type": "STRING", "value": safe_updated_by},
        {"name": "enforcement_action", "type": "STRING", "value": enforcement_action},
        {"name": "email_alert_enabled", "type": "BOOLEAN", "value": email_alert_enabled},
        {"name": "alert_group_id", "type": "STRING", "value": alert_group_id}
    ]
    
    query_table("insert_rule", query, params)
    
    return {"request_id": request_id,"table_added_to_approvers_group": table_added}

# ---------------------------------------------------------------------------
# NEW: Preview a rule's impact BEFORE submitting it, so a user can see how
# many rows would currently violate the rule (and a few examples) without
# creating anything yet.
#
# Coverage: every condition type is previewable, using the exact
# condition_type names and condition_criteria field names the real UI
# sends (verified against conditionConfig in DynamicConditionFields.jsx --
# several of these differ from what earlier design docs assumed, e.g.
# "DUPLICATE" not "DUPLICATE_CHECK", "UNIQUE" not "UNIQUE_VALUE_CHECK",
# "TIME_STAMP_CHECK" not "TIMESTAMP_CHECK", VALUE_THRESHOLD's field is
# 'value_threshold' not 'value', DATE_RANGE's fields are 'start_date'/
# 'end_date' not 'min_date'/'max_date', REFERENCE_CHECK's fields are
# 'catalog'/'schema'/'table_name'/'targeted_column' not the 'reference_*'
# names, and REFERENCE_CHECK_CUSTOM is a structured transform-based check,
# not a custom_query).
#   - Row-level types (NOT_NULL, BLANK, MUST_HAVE_VALUE, MAPPING_CHECK,
#     REGEX_MATCH, FORMAT_CHECK, LENGTH_CHECK, NOT_NULL_LENGTH_CHECK,
#     RANGE_CHECK, VALUE_THRESHOLD, DATE_RANGE, TIME_STAMP_CHECK,
#     CASE_STANDARDIZATION, DUPLICATE, UNIQUE, OUTLIER_DETECTION,
#     REFERENCE_CHECK, REFERENCE_CHECK_CUSTOM, CUSTOM_RULE) run a direct
#     SQL check against the real table.
#   - KPI_CHECK always uses a custom_query (there is no built-in
#     agg_type/agg_column mode in the real UI). The query's result is
#     compared against lower_threshold/upper_threshold if given; if no
#     fixed thresholds are set (relying instead on a historical baseline
#     that doesn't exist yet for a brand-new rule), the current value is
#     reported with a clear note instead of a fabricated pass/fail.
#   - ROW_COUNT_TREND looks up whatever historical batch row-count metrics
#     already exist for this table (independent of any specific rule),
#     using 'interval' as the lookback window, and computes a real mean/
#     std-dev comparison once there are at least 3 prior batches;
#     otherwise it reports the current row count with a clear "no
#     baseline yet" note.
# ---------------------------------------------------------------------------

NOT_PREVIEWABLE_TYPES = set()  # every condition type is now previewable in some form


def _build_violation_predicate(column_name, condition_type, criteria):
    """Returns a SQL boolean expression that is TRUE for a VIOLATING row,
    for condition types that can be expressed as a single per-row
    predicate. Raises ValueError for types handled separately (duplicate/
    unique checks, outlier detection, custom queries) or not previewable."""
    col = f"`{column_name}`"
    ctype = condition_type.upper()

    if ctype == "NOT_NULL":
        return f"{col} IS NULL"

    if ctype == "BLANK":
        placeholders = "'NA','N/A','NULL','NONE','UNDEFINED','-','--'"
        return (f"({col} IS NULL OR TRIM(CAST({col} AS STRING)) = '' "
                f"OR UPPER(TRIM(CAST({col} AS STRING))) IN ({placeholders}))")

    if ctype in ("MUST_HAVE_VALUE", "MAPPING_CHECK"):
        values = criteria.get("value", [])
        if not values:
            raise ValueError(f"{condition_type} requires a non-empty 'value' list in condition_criteria.")
        values_sql = ", ".join("'" + str(v).replace("'", "''") + "'" for v in values)
        return f"({col} IS NULL OR CAST({col} AS STRING) NOT IN ({values_sql}))"

    if ctype in ("REGEX_MATCH", "FORMAT_CHECK"):
        pattern = criteria.get("regex_pattern")
        if not pattern:
            raise ValueError(f"{condition_type} requires 'regex_pattern' in condition_criteria.")
        pattern_escaped = pattern.replace("'", "''")
        return f"({col} IS NULL OR NOT (CAST({col} AS STRING) RLIKE '{pattern_escaped}'))"

    if ctype == "LENGTH_CHECK":
        length = criteria.get("value")
        if length is None:
            raise ValueError("LENGTH_CHECK requires 'value' (expected length) in condition_criteria.")
        # Placeholders get a free pass regardless of length, matching the
        # documented semantics -- only flag real, present values of the
        # wrong length.
        return (f"({col} IS NOT NULL AND TRIM(CAST({col} AS STRING)) != '' "
                f"AND UPPER(TRIM(CAST({col} AS STRING))) NOT IN ('NA','N/A','NULL','NONE','UNDEFINED') "
                f"AND LENGTH(TRIM(CAST({col} AS STRING))) != {int(length)})")

    if ctype == "NOT_NULL_LENGTH_CHECK":
        length = criteria.get("value")
        if length is None:
            raise ValueError("NOT_NULL_LENGTH_CHECK requires 'value' (expected length) in condition_criteria.")
        return (f"({col} IS NULL OR TRIM(CAST({col} AS STRING)) = '' "
                f"OR LENGTH(TRIM(CAST({col} AS STRING))) != {int(length)})")

    if ctype == "RANGE_CHECK":
        min_v, max_v = criteria.get("min_value"), criteria.get("max_value")
        if min_v is None or max_v is None:
            raise ValueError("RANGE_CHECK requires 'min_value' and 'max_value' in condition_criteria.")
        return f"({col} IS NULL OR {col} < {min_v} OR {col} > {max_v})"

    if ctype == "VALUE_THRESHOLD":
        op, val = criteria.get("operator"), criteria.get("value_threshold")
        if not op or val is None:
            raise ValueError("VALUE_THRESHOLD requires 'operator' and 'value_threshold' in condition_criteria.")
        if op not in (">", "<", ">=", "<=", "==", "!="):
            raise ValueError(f"Unsupported operator: {op}")
        sql_op = "=" if op == "==" else op
        return f"({col} IS NULL OR NOT ({col} {sql_op} {val}))"

    if ctype == "DATE_RANGE":
        start_date, end_date = criteria.get("start_date"), criteria.get("end_date")
        if not start_date or not end_date:
            raise ValueError("DATE_RANGE requires 'start_date' and 'end_date' in condition_criteria.")
        return (f"({col} IS NULL OR CAST({col} AS DATE) < DATE'{start_date}' "
                f"OR CAST({col} AS DATE) > DATE'{end_date}')")

    if ctype == "TIME_STAMP_CHECK":
        condition = criteria.get("condition")
        if not condition:
            raise ValueError("TIME_STAMP_CHECK requires 'condition' in condition_criteria.")
        return f"(NOT ({condition}))"

    if ctype == "CASE_STANDARDIZATION":
        case_type = (criteria.get("case") or "").upper()
        if case_type == "UPPER":
            transform = f"UPPER(CAST({col} AS STRING))"
        elif case_type == "LOWER":
            transform = f"LOWER(CAST({col} AS STRING))"
        else:
            raise ValueError("CASE_STANDARDIZATION requires 'case' to be UPPER or LOWER.")
        return f"({col} IS NOT NULL AND CAST({col} AS STRING) != {transform})"

    raise ValueError(f"Preview not implemented for condition type: {condition_type}")


def preview_rule_impact(catalog, schema, table_name, column_name, condition_type,
                        condition_criteria, sample_limit=5):
    """
    Runs a dry-run check of a not-yet-created rule against the real table,
    without saving anything. Returns:
      {
        "total_rows": int,
        "violation_count": int,
        "violation_pct": float,
        "sample_violations": [ {col: val, ...}, ... ]   # up to sample_limit rows
      }
    or raises ValueError with a clear message for unsupported types.
    """
    ctype = condition_type.upper()
    if ctype in NOT_PREVIEWABLE_TYPES:
        raise ValueError(
            f"{condition_type} compares against historical data that doesn't exist yet "
            f"for a new rule, so it can't be meaningfully previewed."
        )

    full_table = f"{catalog}.{schema}.{table_name}"

    try:
        criteria = json.loads(condition_criteria) if isinstance(condition_criteria, str) else (condition_criteria or {})
    except json.JSONDecodeError as e:
        raise ValueError(f"condition_criteria is not valid JSON: {e}")

    total_row = query_table("preview_total_rows", f"SELECT COUNT(*) AS total FROM {full_table}")
    total_rows = int(total_row[0]["total"]) if total_row else 0
    if total_rows == 0:
        return {"total_rows": 0, "violation_count": 0, "violation_pct": 0.0, "sample_violations": []}

    # --- Custom-query-based type: the query already IS the violation-finder ---
    if ctype == "CUSTOM_RULE":
        custom_query = criteria.get("custom_query")
        if not custom_query:
            raise ValueError(f"{condition_type} requires 'custom_query' in condition_criteria.")
        resolved_query = custom_query.format(catalog_name=catalog, schema_name=schema, table_name=table_name)
        violation_rows = query_table("preview_custom_rule", resolved_query)
        violation_count = len(violation_rows)
        return {
            "total_rows": total_rows,
            "violation_count": violation_count,
            "violation_pct": round(100.0 * violation_count / total_rows, 2),
            "sample_violations": violation_rows[:sample_limit],
        }

    # --- KPI_CHECK: the custom_query returns a metric value (or
    # metric_name/metric_value pairs), which gets compared against
    # lower_threshold/upper_threshold -- NOT "rows returned = violations"
    # like CUSTOM_RULE. Matches how the actual production DQ engine's
    # run_kpi_check() interprets this same query + threshold shape. ---
    if ctype == "KPI_CHECK":
        custom_query = criteria.get("custom_query")
        if not custom_query:
            raise ValueError("KPI_CHECK requires 'custom_query' in condition_criteria.")
        lower_threshold = criteria.get("lower_threshold")
        upper_threshold = criteria.get("upper_threshold")

        resolved_query = custom_query.format(catalog_name=catalog, schema_name=schema, table_name=table_name)
        kpi_rows = query_table("preview_kpi_check", resolved_query)
        if not kpi_rows:
            return {"total_rows": 0, "violation_count": 0, "violation_pct": 0.0, "sample_violations": [],
                    "note": "The custom query returned no rows -- nothing to evaluate."}

        cols = list(kpi_rows[0].keys())
        value_col = "metric_value" if "metric_value" in cols else cols[-1]

        if lower_threshold is None and upper_threshold is None:
            # No fixed thresholds -- this rule relies on a historical
            # baseline that doesn't exist yet for a rule that hasn't run
            # before. Report the current value(s) instead of a fabricated
            # pass/fail.
            return {
                "total_rows": len(kpi_rows),
                "violation_count": 0,
                "violation_pct": 0.0,
                "sample_violations": kpi_rows[:sample_limit],
                "note": (
                    "No lower_threshold/upper_threshold set, so this rule relies on a "
                    "historical baseline that doesn't exist yet for a rule that hasn't run "
                    f"before. Showing the current {value_col} value(s) instead of a pass/fail result."
                ),
            }

        def _violates(v):
            if v is None:
                return False
            if lower_threshold is not None and v < lower_threshold:
                return True
            if upper_threshold is not None and v > upper_threshold:
                return True
            return False

        violating_rows = [r for r in kpi_rows if _violates(r.get(value_col))]
        total_metric_rows = len(kpi_rows)
        return {
            "total_rows": total_metric_rows,
            "violation_count": len(violating_rows),
            "violation_pct": round(100.0 * len(violating_rows) / total_metric_rows, 2),
            "sample_violations": violating_rows[:sample_limit],
        }

    # --- ROW_COUNT_TREND: compares against historical batch counts. A
    # brand-new rule has no rule-specific history, but the table itself
    # may already have prior batch metrics recorded (independent of any
    # rule) -- use those if present; otherwise report the current count
    # honestly rather than fabricating a pass/fail verdict. ---
    if ctype == "ROW_COUNT_TREND":
        gov_catalog, gov_schema = CATALOG, SCHEMA
        # FIX: the actual UI field is 'interval' (how many recent batches
        # to look back across for the trend baseline), not
        # 'std_dev_multiplier' which doesn't exist in the real
        # conditionConfig for this type.
        lookback = int(criteria.get("interval") or 30)
        try:
            history_query = f"""
                SELECT row_count
                FROM {gov_catalog}.{gov_schema}.{yaml_config.get("metrics_table", "dq_table_metrics")}
                WHERE catalog_name = :catalog_name AND schema_name = :schema_name
                  AND table_name = :table_name
                ORDER BY batch_timestamp DESC
                LIMIT {lookback}
            """
            history_params = [
                {"name": "catalog_name", "type": "STRING", "value": catalog},
                {"name": "schema_name", "type": "STRING", "value": schema},
                {"name": "table_name", "type": "STRING", "value": table_name},
            ]
            history_rows = query_table("preview_row_count_history", history_query, history_params)
            historical_counts = [r["row_count"] for r in history_rows if r.get("row_count") is not None]
        except Exception:
            # Metrics table missing, differently structured, or no
            # permission to read it -- fall back to "no baseline"
            # rather than failing the whole preview over this.
            historical_counts = []

        if len(historical_counts) < 3:
            return {
                "total_rows": total_rows,
                "violation_count": 0,
                "violation_pct": 0.0,
                "sample_violations": [],
                "note": (
                    f"Not enough historical batch data yet for this table to establish a "
                    f"trend baseline (found {len(historical_counts)} prior batch(es) within "
                    f"the last {lookback}, need at least 3). Current row count is "
                    f"{total_rows} -- this rule will start building a real baseline once "
                    f"it's active and the pipeline runs against this table going forward."
                ),
            }

        mean = sum(historical_counts) / len(historical_counts)
        variance = sum((c - mean) ** 2 for c in historical_counts) / len(historical_counts)
        stddev = variance ** 0.5
        k = 3  # no dedicated std-dev-multiplier field in the real UI; 3 is a standard default
        lower_bound = mean - k * stddev
        upper_bound = mean + k * stddev
        is_violation = total_rows < lower_bound or total_rows > upper_bound

        return {
            "total_rows": total_rows,
            "violation_count": 1 if is_violation else 0,
            "violation_pct": 100.0 if is_violation else 0.0,
            "sample_violations": [],
            "note": (
                f"Historical baseline from {len(historical_counts)} prior batch(es) "
                f"(last {lookback} checked): mean={mean:.1f}, expected range "
                f"[{lower_bound:.1f}, {upper_bound:.1f}] (mean +/- {k} std dev). "
                f"Current row count is {total_rows}, which "
                f"{'would be flagged as anomalous' if is_violation else 'falls within the expected range'}."
            ),
        }

    # --- Reference check: value must exist in another table's column ---
    if ctype == "REFERENCE_CHECK":
        ref_catalog = criteria.get("catalog")
        ref_schema = criteria.get("schema")
        ref_table = criteria.get("table_name")
        ref_column = criteria.get("targeted_column")
        if not all([ref_catalog, ref_schema, ref_table, ref_column]):
            raise ValueError("REFERENCE_CHECK requires catalog, schema, table_name, and "
                             "targeted_column in condition_criteria.")
        ref_full = f"{ref_catalog}.{ref_schema}.{ref_table}"
        predicate = (f"(`{column_name}` IS NULL OR `{column_name}` NOT IN "
                    f"(SELECT DISTINCT `{ref_column}` FROM {ref_full} WHERE `{ref_column}` IS NOT NULL))")

    # --- Reference check (custom transform): only a TRANSFORMED PORTION of
    # the column's value (a prefix, suffix, fixed substring, or text
    # before/after a delimiter) is compared against the reference table's
    # distinct values -- e.g. first 15 characters of a code, or the domain
    # after '@' in an email. ---
    elif ctype == "REFERENCE_CHECK_CUSTOM":
        ref_catalog = criteria.get("catalog")
        ref_schema = criteria.get("schema")
        ref_table = criteria.get("table_name")
        ref_column = criteria.get("targeted_column")
        transform = (criteria.get("transform") or "").upper()
        if not all([ref_catalog, ref_schema, ref_table, ref_column, transform]):
            raise ValueError("REFERENCE_CHECK_CUSTOM requires catalog, schema, table_name, "
                             "targeted_column, and transform in condition_criteria.")

        col_str = f"CAST(`{column_name}` AS STRING)"
        if transform == "FIRST_N":
            length = criteria.get("length")
            if length is None:
                raise ValueError("REFERENCE_CHECK_CUSTOM with transform FIRST_N requires 'length'.")
            transformed_expr = f"SUBSTRING({col_str}, 1, {int(length)})"
        elif transform == "LAST_N":
            length = criteria.get("length")
            if length is None:
                raise ValueError("REFERENCE_CHECK_CUSTOM with transform LAST_N requires 'length'.")
            transformed_expr = f"SUBSTRING({col_str}, GREATEST(LENGTH({col_str}) - {int(length)} + 1, 1))"
        elif transform == "MIDDLE":
            length = criteria.get("length")
            start = criteria.get("start")
            if length is None or start is None:
                raise ValueError("REFERENCE_CHECK_CUSTOM with transform MIDDLE requires 'length' and 'start'.")
            transformed_expr = f"SUBSTRING({col_str}, {int(start)}, {int(length)})"
        elif transform == "AFTER_DELIMITER":
            delimiter = criteria.get("delimiter")
            if not delimiter:
                raise ValueError("REFERENCE_CHECK_CUSTOM with transform AFTER_DELIMITER requires 'delimiter'.")
            delim_escaped = delimiter.replace("'", "''")
            transformed_expr = (f"SUBSTRING({col_str}, INSTR({col_str}, '{delim_escaped}') + "
                               f"LENGTH('{delim_escaped}'))")
        elif transform == "BEFORE_DELIMITER":
            delimiter = criteria.get("delimiter")
            if not delimiter:
                raise ValueError("REFERENCE_CHECK_CUSTOM with transform BEFORE_DELIMITER requires 'delimiter'.")
            delim_escaped = delimiter.replace("'", "''")
            transformed_expr = f"SUBSTRING({col_str}, 1, INSTR({col_str}, '{delim_escaped}') - 1)"
        else:
            raise ValueError(
                "REFERENCE_CHECK_CUSTOM 'transform' must be one of: FIRST_N, LAST_N, "
                "MIDDLE, AFTER_DELIMITER, BEFORE_DELIMITER."
            )

        ref_full = f"{ref_catalog}.{ref_schema}.{ref_table}"
        predicate = (f"(`{column_name}` IS NULL OR {transformed_expr} NOT IN "
                    f"(SELECT DISTINCT `{ref_column}` FROM {ref_full} WHERE `{ref_column}` IS NOT NULL))")

    # --- Duplicate / uniqueness checks: need a GROUP BY, not a row predicate ---
    elif ctype == "UNIQUE":
        # FIX: the real UI's condition_type is "UNIQUE" (not
        # "UNIQUE_VALUE_CHECK"), and it checks the 'identifier_column'
        # field from criteria -- which may be a DIFFERENT column than the
        # rule's own column_name (e.g. a rule on "email" that actually
        # enforces uniqueness on "customer_id").
        identifier_column = criteria.get("identifier_column") or column_name
        key_columns = [identifier_column]
        cols_sql = ", ".join(f"`{c}`" for c in key_columns)
        dup_query = f"""
            SELECT {cols_sql}, COUNT(*) AS occurrence_count
            FROM {full_table}
            GROUP BY {cols_sql}
            HAVING COUNT(*) > 1
            LIMIT {sample_limit}
        """
        dup_rows = query_table("preview_duplicates", dup_query)
        count_query = f"""
            SELECT COALESCE(SUM(occurrence_count), 0) AS violation_count FROM (
                SELECT COUNT(*) AS occurrence_count
                FROM {full_table}
                GROUP BY {cols_sql}
                HAVING COUNT(*) > 1
            )
        """
        violation_count = int(query_table("preview_duplicate_count", count_query)[0]["violation_count"])
        return {
            "total_rows": total_rows,
            "violation_count": violation_count,
            "violation_pct": round(100.0 * violation_count / total_rows, 2),
            "sample_violations": dup_rows,
        }

    elif ctype == "DUPLICATE":
        # FIX: the real UI's condition_type is "DUPLICATE" (not
        # "DUPLICATE_CHECK"), and it has NO criteria fields at all -- it
        # simply checks the rule's own column_name for duplicate values,
        # unlike UNIQUE which reads a separate identifier_column.
        cols_sql = f"`{column_name}`"
        dup_query = f"""
            SELECT {cols_sql}, COUNT(*) AS occurrence_count
            FROM {full_table}
            GROUP BY {cols_sql}
            HAVING COUNT(*) > 1
            LIMIT {sample_limit}
        """
        dup_rows = query_table("preview_duplicates", dup_query)
        count_query = f"""
            SELECT COALESCE(SUM(occurrence_count), 0) AS violation_count FROM (
                SELECT COUNT(*) AS occurrence_count
                FROM {full_table}
                GROUP BY {cols_sql}
                HAVING COUNT(*) > 1
            )
        """
        violation_count = int(query_table("preview_duplicate_count", count_query)[0]["violation_count"])
        return {
            "total_rows": total_rows,
            "violation_count": violation_count,
            "violation_pct": round(100.0 * violation_count / total_rows, 2),
            "sample_violations": dup_rows,
        }

    # --- Outlier detection: needs mean/stddev computed first ---
    elif ctype == "OUTLIER_DETECTION":
        k = criteria.get("value")
        if k is None:
            raise ValueError("OUTLIER_DETECTION requires 'value' (std-dev multiplier) in condition_criteria.")
        predicate = f"""(
            `{column_name}` IS NOT NULL AND (
                SELECT ABS(`{column_name}` - stats.avg_val) > {k} * stats.stddev_val
                FROM (SELECT AVG(`{column_name}`) AS avg_val, STDDEV(`{column_name}`) AS stddev_val
                      FROM {full_table} WHERE `{column_name}` IS NOT NULL) AS stats
            )
        )"""

    else:
        predicate = _build_violation_predicate(column_name, condition_type, criteria)

    count_query = f"SELECT SUM(CASE WHEN {predicate} THEN 1 ELSE 0 END) AS violation_count FROM {full_table}"
    violation_count_row = query_table("preview_violation_count", count_query)
    violation_count = int(violation_count_row[0]["violation_count"] or 0)

    sample_violations = []
    if violation_count > 0:
        sample_query = f"SELECT * FROM {full_table} WHERE {predicate} LIMIT {sample_limit}"
        sample_violations = query_table("preview_sample_violations", sample_query)

    return {
        "total_rows": total_rows,
        "violation_count": violation_count,
        "violation_pct": round(100.0 * violation_count / total_rows, 2),
        "sample_violations": sample_violations,
    }
