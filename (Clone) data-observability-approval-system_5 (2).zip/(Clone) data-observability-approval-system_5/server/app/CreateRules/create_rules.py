from flask import Flask, jsonify, request, Blueprint
from .create_rules_logic import get_catalogs, get_schemas, get_tables, get_columns, insert_rule, bulk_upload_rules_from_csv, preview_rule_impact

app = Flask(__name__)

# --- define blueprint ---
create_rules_bp = Blueprint("create_rules", __name__)

# --- GET Catalog Metadata (all catalogs) ---
@create_rules_bp.route("/api/catalog-meta", methods=['GET'])
def api_get_catalog_meta():
    try:
        data = get_catalogs()
        return jsonify(data)
    except Exception as e:
        return jsonify({"error": str(e)}), 500

# --- GET Schema Metadata ---
@create_rules_bp.route("/api/schema-meta", methods=['GET'])
def api_get_schema_meta():
    try:
        catalog_name = request.args.get('catalog')
        if not catalog_name:
            return jsonify({"error": "Missing 'catalog' query parameter"}), 400
        data = get_schemas(catalog_name)
        return jsonify(data)
    except Exception as e:
        return jsonify({"error": str(e)}), 500

# --- GET Table Metadata ---
@create_rules_bp.route("/api/table-meta", methods=['GET'])
def api_get_table_meta():
    try:
        catalog_name = request.args.get('catalog')
        schema_name = request.args.get('schema')
        if not all([catalog_name, schema_name]):
            return jsonify({"error": "Missing 'catalog' or 'schema' query parameter"}), 400
        data = get_tables(catalog_name, schema_name)
        return jsonify(data)
    except Exception as e:
        return jsonify({"error": str(e)}), 500

# --- GET Column Metadata ---
@create_rules_bp.route("/api/column-meta", methods=['GET'])
def api_get_column_meta():
    try:
        catalog_name = request.args.get('catalog')
        schema_name = request.args.get('schema')
        table_name = request.args.get('table')
        if not all([catalog_name, schema_name, table_name]):
            return jsonify({"error": "Missing 'catalog', 'schema', or 'table' query parameter"}), 400
        data = get_columns(catalog_name, schema_name, table_name)
        return jsonify(data)
    except Exception as e:
        return jsonify({"error": str(e)}), 500

# --- POST Create Rule ---
@create_rules_bp.route("/api/rules/add", methods=['POST'])
def api_add_rule():
    try:
        payload = request.get_json(force=True)
        # Check if payload is a list (multiple rules)
        if isinstance(payload, list):
            results = []
            for rule_data in payload:
                res = insert_rule(rule_data)
                results.append(res)
            return jsonify({"message": "Rules added successfully", "results": results})
        else:
            # Single rule
            res = insert_rule(payload)
            return jsonify({"message": "Rule added successfully", "result": res})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


# --- POST Bulk Upload Rules via CSV ---
# NOTE: CSV column format is a reasonable best-effort mapping pending
# Antonio's actual spec -- see bulk_upload_rules_from_csv()'s docstring in
# create_rules_logic.py for the exact expected columns and how to adjust
# them once the real spec is available.
@create_rules_bp.route("/api/rules/bulk-upload", methods=['POST'])
def api_bulk_upload_rules():
    try:
        if "file" not in request.files:
            return jsonify({"error": "No file uploaded. Send the CSV as multipart/form-data under the 'file' field."}), 400

        file = request.files["file"]
        if not file or file.filename == "":
            return jsonify({"error": "No file selected."}), 400
        if not file.filename.lower().endswith(".csv"):
            return jsonify({"error": "Only .csv files are supported."}), 400

        created_by = request.form.get("created_by") or request.args.get("created_by")

        result = bulk_upload_rules_from_csv(file.stream, created_by)
        status_code = 200 if result["failed"] == 0 else 207  # 207 Multi-Status: partial success
        return jsonify(result), status_code
    except ValueError as e:
        # Bad CSV structure (missing columns, empty file, etc.) -- a client
        # error, not a server error.
        return jsonify({"error": str(e)}), 400
    except Exception as e:
        return jsonify({"error": str(e)}), 500


# --- POST Preview Rule Impact (dry-run, nothing is saved) ---
@create_rules_bp.route("/api/rules/preview", methods=['POST'])
def api_preview_rule_impact():
    try:
        body = request.get_json(force=True) or {}
        required = ["catalog", "schema", "table_name", "column_name", "condition_type", "condition_criteria"]
        missing = [f for f in required if not body.get(f)]
        if missing:
            return jsonify({"error": f"Missing required field(s): {', '.join(missing)}"}), 400

        result = preview_rule_impact(
            catalog=body["catalog"],
            schema=body["schema"],
            table_name=body["table_name"],
            column_name=body["column_name"],
            condition_type=body["condition_type"],
            condition_criteria=body["condition_criteria"],
            sample_limit=body.get("sample_limit", 5),
        )
        return jsonify(result), 200
    except ValueError as e:
        # Unsupported condition type, or bad/missing criteria -- a client
        # error, not a server error.
        return jsonify({"error": str(e)}), 400
    except Exception as e:
        return jsonify({"error": str(e)}), 500
