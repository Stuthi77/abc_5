# import requests

# url = "http://127.0.0.1:5000/api/create/rules"

# payload = {
#   "catalog": "ds_training_1",
#   "schema": "tpch_bronze",
#   "table_name": "customer",
#   "column_name": "c_name",
#   "rule_description": "Customer name must not be null",
#   "created_by": "brinda",
#   "condition_category": "Completeness",
#   "condition_type": "NOT NULL",
#   "condition_criteria": "c_name IS NOT NULL",
#   "operation": "CREATE",
#   "severity": "High",
#   "violation_threshold": "1"
# }

# response = requests.post(url, json=payload)
# print(response.status_code)
# print(response.json())

import requests

url = "http://127.0.0.1:5000/api/rules/add"

# Multiple rules in a list
payload = [
    {
        "catalog": "ds_training_1",
        "schema": "tpch_bronze",
        "table_name": "customer",
        "column_name": "c_name",
        "rule_description": "Customer name must not be null",
        "created_by": "brinda",
        "condition_category": "Completeness",
        "condition_type": "NOT NULL",
        "condition_criteria": "c_name IS NOT NULL",
        "operation": "CREATE",
        "severity": "High",
        "violation_threshold": "1"
    },
    {
        "catalog": "ds_training_1",
        "schema": "tpch_bronze",
        "table_name": "customer",
        "column_name": "c_custkey",
        "rule_description": "Customer ID must not be null",
        "created_by": "brinda",
        "condition_category": "Completeness",
        "condition_type": "NOT NULL",
        "condition_criteria": "c_custkey IS NOT NULL",
        "operation": "CREATE",
        "severity": "High",
        "violation_threshold": "1"
    },
    {
        "catalog": "ds_training_1",
        "schema": "tpch_bronze",
        "table_name": "customer",
        "column_name": "c_address",
        "rule_description": "Customer address must not be null",
        "created_by": "brinda",
        "condition_category": "Completeness",
        "condition_type": "NOT NULL",
        "condition_criteria": "c_address IS NOT NULL",
        "operation": "CREATE",
        "severity": "High",
        "violation_threshold": "1"
    }
]

response = requests.post(url, json=payload)

print(response.status_code)
print(response.json())
