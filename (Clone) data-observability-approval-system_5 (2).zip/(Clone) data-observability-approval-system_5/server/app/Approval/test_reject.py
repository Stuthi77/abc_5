import requests
import json


# Define the base URL of your API
BASE_URL = "http://127.0.0.1:5000"  # Replace with your actual API URL if different


def test_reject_rule_endpoint(request_id, rejected_by, reason):
    """
    Sends a POST request to the /api/approval/reject_rule endpoint
    and prints the response.
    """
    endpoint = f"{BASE_URL}/api/approval/reject_rule"
   
    # Payload for the POST request
    payload = {
        "request_id": request_id,
        "rejected_by": rejected_by,
        "reason": reason
    }


    headers = {
        "Content-Type": "application/json"
    }


    try:
        print(f"--- Attempting to reject request ID: {request_id} ---")
        print(f"Payload: {json.dumps(payload, indent=2)}")
       
        # Make the POST request
        response = requests.post(endpoint, data=json.dumps(payload), headers=headers)
       
        # Print the response details
        print(f"Status Code: {response.status_code}")
       
        try:
            # Attempt to parse the JSON response
            response_json = response.json()
            print("Response JSON:")
            print(json.dumps(response_json, indent=4))
        except json.JSONDecodeError:
            print("Response is not valid JSON. Response text:")
            print(response.text)


    except requests.exceptions.RequestException as e:
        print(f"An error occurred: {e}")


# --- Test Scenario ---


# Scenario 1: Successful rejection
# This tests the rejection of request ID 65.
print("\n--- Test Case: Successful Rejection of Request ID 65 ---")
test_reject_rule_endpoint("69", "test_user", "Duplicate rule, already exists in the system.")
print("-" * 50)


