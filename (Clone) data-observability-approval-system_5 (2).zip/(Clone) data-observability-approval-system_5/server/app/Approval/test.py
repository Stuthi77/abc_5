import requests
import json


# Replace this with the actual base URL of your API
BASE_URL = "http://127.0.0.1:5000"  


def test_approve_rule(request_id,approved_by):
    """
    Sends a POST request to the API to approve a rule request.
   
    Args:
        request_id (int or str): The ID of the request to approve.
    """
    endpoint = f"{BASE_URL}/api/approval/approve_rule"
   
    payload = {
        "request_id": str(request_id),  # Ensure the ID is a string if your endpoint expects it
        "approved_by": str(approved_by)
    }


    headers = {
        "Content-Type": "application/json"
    }


    print(f"Testing endpoint: {endpoint}")
    print(f"Request Payload: {payload}\n")


    try:
        response = requests.post(endpoint, data=json.dumps(payload), headers=headers)
       
        print(f"Response Status Code: {response.status_code}")
       
        # Pretty print the JSON response
        try:
            response_json = response.json()
            print("Response Body:")
            print(json.dumps(response_json, indent=4))
        except json.JSONDecodeError:
            print("Response is not valid JSON. Response text:")
            print(response.text)
           
        response.raise_for_status()  # Raise an HTTPError for bad responses (4xx or 5xx)


    except requests.exceptions.HTTPError as errh:
        print(f"HTTP Error: {errh}")
    except requests.exceptions.ConnectionError as errc:
        print(f"Connection Error: {errc}")
    except requests.exceptions.Timeout as errt:
        print(f"Timeout Error: {errt}")
    except requests.exceptions.RequestException as err:
        print(f"An unexpected error occurred: {err}")


# --- Execute the test ---
# Pass the request_id you want to test
test_approve_rule(66,"akilan")



