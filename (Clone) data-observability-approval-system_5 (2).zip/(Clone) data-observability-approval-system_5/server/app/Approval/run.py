# server/run.py
import sys
import os

# This adds the 'server' directory to Python's path
sys.path.insert(0, os.path.abspath(os.path.dirname(__file__)))

from app.Approval.Approval import app

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)