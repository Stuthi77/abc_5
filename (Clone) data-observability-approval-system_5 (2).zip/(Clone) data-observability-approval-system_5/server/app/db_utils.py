# server/app/db_utils.py
#
# Shared Databricks connection layer. Every backend module previously had
# its OWN local copy of this exact query_table() function, duplicated
# across files -- this is the single, shared version they all import
# instead.
import time
import requests
from config import config


def query_table(name, query, params=None):
    """
    Executes a SQL query on Databricks using the Statement Execution API.
    """
    url = f"{config.DATABRICKS_HOST}/api/2.0/sql/statements"
    headers = {
        "Authorization": f"Bearer {config.DATABRICKS_TOKEN}",
        "Content-Type": "application/json"
    }
    payload = {"statement": query, "warehouse_id": config.SQL_WAREHOUSE_ID, "wait_timeout": "5s"}
    if params:
        payload["parameters"] = params

    res = requests.post(url, headers=headers, json=payload)
    res.raise_for_status()
    response_json = res.json()
    statement_id = response_json.get("statement_id")
    if not statement_id:
        raise Exception(f"No statement_id returned for query '{name}'")

    status_url = f"{config.DATABRICKS_HOST}/api/2.0/sql/statements/{statement_id}"
    while True:
        status_res = requests.get(status_url, headers=headers)
        status_res.raise_for_status()
        status_json = status_res.json()
        state = status_json.get("status", {}).get("state")

        if state == "SUCCEEDED":
            manifest = status_json.get("manifest", {})
            columns = [col["name"] for col in manifest.get("schema", {}).get("columns", [])]
            data_array = status_json.get("result", {}).get("data_array", [])
            return [dict(zip(columns, row)) for row in data_array]
        elif state in ["FAILED", "CANCELED", "CLOSED"]:
            error = status_json.get("status", {}).get("error", {})
            raise Exception(f"Query '{name}' failed: {error.get('message', 'Unknown error')}")

        time.sleep(1)


def execute_query(name, query, params=None):
    """Alias for query_table -- some modules call the same execution
    pattern execute_query for statements where the result set itself
    isn't the point (INSERT/UPDATE/DELETE). Kept as a separate name to
    match existing call sites without forcing a rename everywhere."""
    return query_table(name, query, params=params)
