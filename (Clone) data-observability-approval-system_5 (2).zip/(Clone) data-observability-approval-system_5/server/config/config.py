# server/config/config.py
#
# All secrets come from environment variables.
# - Locally: put them in server/.env (never commit it) or export them in the shell.
# - In Databricks Apps: define them in app.yaml under `env:` (ideally valueFrom a secret).
import os

try:
    # optional: load server/.env when running locally
    from dotenv import load_dotenv
    load_dotenv(os.path.join(os.path.dirname(os.path.dirname(__file__)), ".env"))
except ImportError:
    pass

# FIX: DATABRICKS_TOKEN no longer has a hardcoded fallback. A committed
# fallback secret defeats the entire point of "secrets come from
# environment variables" (per the comment above) -- if the env var isn't
# set, this now stays None and the warning below fires clearly, rather
# than silently authenticating with a real, exposed PAT baked into source
# code. DATABRICKS_HOST/SQL_WAREHOUSE_ID keep defaults since they're
# endpoint identifiers, not credentials.
DATABRICKS_HOST = os.getenv("DATABRICKS_HOST", "https://adb-7769428536383727.7.azuredatabricks.net").rstrip("/")
DATABRICKS_TOKEN = os.getenv("DATABRICKS_TOKEN","dapi14297febc8248e44c9db3f929d6b2666-2")
SQL_WAREHOUSE_ID = os.getenv("SQL_WAREHOUSE_ID", "c46555dff4f199bb")

if not all([DATABRICKS_HOST, DATABRICKS_TOKEN, SQL_WAREHOUSE_ID]):
    print("WARNING: DATABRICKS_HOST / DATABRICKS_TOKEN / SQL_WAREHOUSE_ID not fully set.")
