import { createTheme } from "@mui/material/styles";

const theme = createTheme({
  typography: {
    fontFamily: "'Inter', 'Segoe UI', sans-serif",
    fontSize: 13,
  },
  palette: {
    primary: {
      main: "#2186EB",
    },
    background: {
      default: "#F5F5F5",
      paper: "#ffffff",
    },
    text: {
      primary: "#1a1a1a",
      secondary: "#5f6368",
    },
  },
  components: {
    MuiListItemText: {
      styleOverrides: {
        primary: {
          fontSize: "13px",
        },
      },
    },
  },
});

export default theme;
