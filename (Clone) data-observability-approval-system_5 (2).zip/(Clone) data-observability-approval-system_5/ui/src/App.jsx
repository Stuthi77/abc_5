import { ThemeProvider } from "@mui/material/styles";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import theme from "./theme";
import React, { useEffect } from "react";
import "./App.css";

import Layout from "./layout/Layout";
import Groups from "./features/groups/pages/Groups";
import CreateGroup from "./features/groups/pages/CreateGroup";
import GroupDetail from "./features/groups/pages/GroupDetail";
// import LLMRecommendation from "./features/LLMRecommendation/pages/LLMRecommendation";
import RuleManagement from "./features/rule-management/pages/rule-management/RuleManagement";
import Approval from "./features/rule-management/pages/approval/Approval";
import Alerts from "./features/alerts/pages/alerts/Alerts";
import CreateRules from "./features/rule-management/pages/create-rules/CreateRules";
import ModifyRules from "./features/rule-management/pages/modify-rules/ModifyRules";
import TableRuleDetails from "./features/rule-management/pages/table-rule-details/TableRuleDetails";
import Glossary from "./features/rule-management/pages/glossary/Glossary";
import { useAuth } from "./shared/context/AuthContext";

import { CircularProgress, Typography, Box } from "@mui/material";

function App() {
  const { login } = useAuth();
  const [isInitialized, setIsInitialized] = React.useState(false);

  useEffect(() => {
    (async () => {
      console.log("Initializing App...");

      let userDetails = {
        userId: "",
        role: "data-engineer",
        name: "",
        email: "",
        subscribedGroups: [],
        selectedGroup: null,
        selectedGroupId: null,
      };

      try {
        // 1️⃣ Preserve session data if exists (avoid overwriting selected group)
        const existingUserData = sessionStorage.getItem("userData");
        if (existingUserData) {
          userDetails = { ...userDetails, ...JSON.parse(existingUserData) };
        }

        // 2️⃣ Fetch user info
        const response = await fetch(`${import.meta.env.VITE_API_URL}/api/user_info`);
        const userData = await response.json();
        const userIdFromEmail = userData.user_email.split("@")[0];

        userDetails = {
          ...userDetails,
          userId: userIdFromEmail,
          name: userData?.display_name,
          email: userData?.user_email,
        };

        sessionStorage.setItem("userData", JSON.stringify(userDetails));

        // 3️⃣ Fetch groups
        const groupResponse = await fetch(
          `${import.meta.env.VITE_API_URL}/api/groups?user_id=${userIdFromEmail}`
        );
        const groupsData = await groupResponse.json();
        const subscribed = groupsData.filter((g) => g.subscription_status === "true");

        if (subscribed.length > 0) {
          userDetails.subscribedGroups = subscribed.map((g) => g.group_name);
          if (!userDetails.selectedGroup || !userDetails.selectedGroupId) {
            userDetails.selectedGroup = subscribed[0].group_name;
            userDetails.selectedGroupId = subscribed[0].group_id;
          }
        }

        sessionStorage.setItem("userData", JSON.stringify(userDetails));
      } catch (err) {
        console.error("Initialization error:", err);
      } finally {
        login(userDetails);
        setIsInitialized(true);
      }
    })();
  }, []);

  if (!isInitialized) {
    return (
      <Box
        sx={{
          display: "flex",
          flexDirection: "column",
          height: "100vh",
          alignItems: "center",
          justifyContent: "center",
          gap: 2,
          backgroundColor: "#f9fafb",
        }}
      >
        <CircularProgress size={48} thickness={4} />
        <Typography variant="h6" sx={{ color: "#555" }}>
          Loading your workspace...
        </Typography>
        <Typography variant="body2" sx={{ color: "#888" }}>
          Fetching user details & groups
        </Typography>
      </Box>
    );
  }

  return (
    <ThemeProvider theme={theme}>
      <BrowserRouter>
        <Layout>
          <Routes>
            <Route path="/" element={<Navigate to="/rule-management" replace />} />
            <Route path="/rule-management" element={<RuleManagement />} />
            <Route path="/rule-management/create" element={<CreateRules />} />
            <Route path="/rule-management/table/:table" element={<TableRuleDetails />} />
            <Route path="/rule-management/glossary" element={<Glossary />} />
            <Route path="/groups" element={<Groups />} />
            <Route path="/groups/create" element={<CreateGroup />} />
            <Route path="/groups/:groupId" element={<GroupDetail />} />
            <Route path="/rule-management/approval" element={<Approval />} />
            <Route path="/alerts" element={<Alerts />} />
            {/* <Route path="/llm_recommendation" element={<LLMRecommendation />} /> */}
          </Routes>
        </Layout>
      </BrowserRouter>
    </ThemeProvider>
  );
}

export default App;

// import { ThemeProvider } from "@mui/material/styles";
// import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
// import theme from "./theme";
// import React, { useEffect } from "react";
// import "./App.css";

// import Layout from "./layout/Layout";
// import Groups from "./features/groups/pages/Groups";
// import CreateGroup from "./features/groups/pages/CreateGroup";
// import GroupDetail from "./features/groups/pages/GroupDetail";

// import RuleManagement from "./features/rule-management/pages/rule-management/RuleManagement";
// import Approval from "./features/rule-management/pages/approval/Approval";
// import Alerts from "./features/alerts/pages/alerts/Alerts";
// import CreateRules from "./features/rule-management/pages/create-rules/CreateRules";
// import ModifyRules from "./features/rule-management/pages/modify-rules/ModifyRules";
// import TableRuleDetails from "./features/rule-management/pages/table-rule-details/TableRuleDetails";
// import Glossary from "./features/rule-management/pages/glossary/Glossary";
// import { useAuth } from "./shared/context/AuthContext";

// function App() {
//   const { login } = useAuth();
//   const [isInitialized, setIsInitialized] = React.useState(false);

//   useEffect(() => {
//     (async () => {
//       console.log("Initializing App...");

//       let userDetails = {
//         userId: "",
//         role: "data-engineer",
//         name: "",
//         email: "",
//         subscribedGroups: [],
//         selectedGroup: null,
//         selectedGroupId: null,
//       };

//       try {
//         // 1️⃣ Check if session already has user data (preserve selectedGroup)
//         const existingUserData = sessionStorage.getItem("userData");
//         if (existingUserData) {
//           userDetails = { ...userDetails, ...JSON.parse(existingUserData) };
//         }

//         // 2️⃣ Fetch user info
//         const response = await fetch(`${import.meta.env.VITE_API_URL}/api/user_info`);
//         const userData = await response.json();
//         const userIdFromEmail = userData.user_email.split("@")[0];

//         userDetails = {
//           ...userDetails,
//           userId: userIdFromEmail,
//           name: userData?.display_name,
//           email: userData?.user_email,
//         };

//         // Store partial data for group fetching
//         sessionStorage.setItem("userData", JSON.stringify(userDetails));

//         // 3️⃣ Fetch groups
//         const groupResponse = await fetch(
//           `${import.meta.env.VITE_API_URL}/api/groups?user_id=${userIdFromEmail}`
//         );
//         const groupsData = await groupResponse.json();
//         const subscribed = groupsData.filter((g) => g.subscription_status === "true");

//         if (subscribed.length > 0) {
//           userDetails.subscribedGroups = subscribed.map((g) => g.group_name);

//           // ✅ Only set default selectedGroup if not already chosen
//           if (!userDetails.selectedGroup || !userDetails.selectedGroupId) {
//             userDetails.selectedGroup = subscribed[0].group_name;
//             userDetails.selectedGroupId = subscribed[0].group_id;
//           }
//         }

//         sessionStorage.setItem("userData", JSON.stringify(userDetails));
//       } catch (err) {
//         console.error("Initialization error:", err);
//       } finally {
//         login(userDetails);
//         setIsInitialized(true);
//       }
//     })();
//   }, []);

//   if (!isInitialized) {
//     return (
//       <div
//         style={{
//           display: "flex",
//           height: "100vh",
//           alignItems: "center",
//           justifyContent: "center",
//         }}
//       >
//         <h3>Loading...</h3>
//       </div>
//     );
//   }

//   return (
//     <ThemeProvider theme={theme}>
//       <BrowserRouter>
//         <Layout>
//           <Routes>
//             <Route path="/" element={<Navigate to="/rule-management" replace />} />
//             <Route path="/rule-management" element={<RuleManagement />} />
//             <Route path="/rule-management/create" element={<CreateRules />} />
//             <Route path="/rule-management/table/:table" element={<TableRuleDetails />} />
//             <Route path="/rule-management/glossary" element={<Glossary />} />
//             <Route path="/groups" element={<Groups />} />
//             <Route path="/groups/create" element={<CreateGroup />} />
//             <Route path="/groups/:groupId" element={<GroupDetail />} />
//             <Route path="/rule-management/approval" element={<Approval />} />
//             <Route path="/alerts" element={<Alerts />} />
//           </Routes>
//         </Layout>
//       </BrowserRouter>
//     </ThemeProvider>
//   );
// }

// export default App;

// import { ThemeProvider } from "@mui/material/styles";
// import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
// import theme from "./theme";
// import React, { useEffect, useState } from "react";
// import './App.css';

// import Layout from "./layout/Layout";
// import Groups from "./features/groups/pages/Groups";
// import CreateGroup from "./features/groups/pages/CreateGroup";
// import GroupDetail from "./features/groups/pages/GroupDetail";


// import RuleManagement from "./features/rule-management/pages/rule-management/RuleManagement";
// import Approval from "./features/rule-management/pages/approval/Approval";
// import Alerts from "./features/alerts/pages/alerts/Alerts";
// import CreateRules from "./features/rule-management/pages/create-rules/CreateRules";
// import ModifyRules from "./features/rule-management/pages/modify-rules/ModifyRules";
// import TableRuleDetails from "./features/rule-management/pages/table-rule-details/TableRuleDetails";
// import Glossary from "./features/rule-management/pages/glossary/Glossary";
// import ProtectedRoute from './shared/component/auth/ProtectedRoute';
// import { useAuth } from './shared/context/AuthContext';
// function App() {
//   const { login } = useAuth();
//   const [isInitialized, setIsInitialized] = React.useState(false);

//   useEffect(() => {
//     (async () => {
//       console.log("Initializing App...");

//       let userDetails = {
//         userId: "",
//         role: "data-engineer",
//         name: "",
//         email: "",
//         subscribedGroups: [],
//         selectedGroup: null,
//         selectedGroupId: null,
//       };

//       try {
//         // Fetch user info first
//         const response = await fetch(`${import.meta.env.VITE_API_URL}/api/user_info`);
//         const userData = await response.json();
//         const userIdFromEmail = userData.user_email.split("@")[0];

//         userDetails = {
//           ...userDetails,
//           userId: userIdFromEmail,
//           name: userData?.display_name,
//           email: userData?.user_email,
//         };

//         // Store partial data in session so group fetch works
//         sessionStorage.setItem("userData", JSON.stringify(userDetails));

//         // Fetch groups before rendering routes
//         const groupResponse = await fetch(
//           `${import.meta.env.VITE_API_URL}/api/groups?user_id=${userIdFromEmail}`
//         );
//         const groupsData = await groupResponse.json();
//         const subscribed = groupsData.filter((g) => g.subscription_status === "true");

//         if (subscribed.length > 0) {
//           userDetails.subscribedGroups = subscribed.map((g) => g.group_name);
//           userDetails.selectedGroup = subscribed[0].group_name;
//           userDetails.selectedGroupId = subscribed[0].group_id;
//         }

//         // Final write to sessionStorage
//         sessionStorage.setItem("userData", JSON.stringify(userDetails));
//       } catch (err) {
//         console.error("Initialization error:", err);
//       } finally {
//         login(userDetails);
//         setIsInitialized(true); //  Mark ready
//       }
//     })();
//   }, []);

//   // Don't render routes until initialization is done
//   if (!isInitialized) {
//     return (
//       <div style={{ display: "flex", height: "100vh", alignItems: "center", justifyContent: "center" }}>
//         <h3>Loading...</h3>
//       </div>
//     );
//   }

//   return (
//     <ThemeProvider theme={theme}>
//       <BrowserRouter>
//         <Layout>
//           <Routes>
//             <Route path="/" element={<Navigate to="/rule-management" replace />} />
//             <Route path="/rule-management" element={<RuleManagement />} />
//             <Route path="/rule-management/create" element={<CreateRules />} />
//             <Route path="/rule-management/table/:table" element={<TableRuleDetails />} />
//             <Route path="/rule-management/glossary" element={<Glossary />} />
//             <Route path="/groups" element={<Groups />} />
//             <Route path="/groups/create" element={<CreateGroup />} />
//             <Route path="/groups/:groupId" element={<GroupDetail />} />
//             <Route path="/rule-management/approval" element={<Approval />} />
//             <Route path="/alerts" element={<Alerts />} />
//           </Routes>
//         </Layout>
//       </BrowserRouter>
//     </ThemeProvider>
//   );
// }

// export default App;
// import { ThemeProvider } from "@mui/material/styles";
// import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
// import theme from "./theme";
// import React, { useEffect, useState } from "react";
// import './App.css';

// import Layout from "./layout/Layout";
// import Groups from "./features/groups/pages/Groups";
// import CreateGroup from "./features/groups/pages/CreateGroup";
// import GroupDetail from "./features/groups/pages/GroupDetail";


// import RuleManagement from "./features/rule-management/pages/rule-management/RuleManagement";
// import Approval from "./features/rule-management/pages/approval/Approval";
// import Alerts from "./features/alerts/pages/alerts/Alerts";
// import CreateRules from "./features/rule-management/pages/create-rules/CreateRules";
// import ModifyRules from "./features/rule-management/pages/modify-rules/ModifyRules";
// import TableRuleDetails from "./features/rule-management/pages/table-rule-details/TableRuleDetails";
// import Glossary from "./features/rule-management/pages/glossary/Glossary";
// import ProtectedRoute from './shared/component/auth/ProtectedRoute';
// import { useAuth } from './shared/context/AuthContext';

// function App() {

//   const { login } = useAuth();

//   useEffect(async () => {
//     console.log("brinda")
//     let userDetails = {
//         //userId: '12345',
//         //userId: 'e49cee19-7104-4a91-b727-a93e63c5fc2a',
//         userId: 'brindavivek.kotha',
//         role: 'data-engineer',
//         name: "Brinda Vivek",
//         email: "Brinda@latenetview.com",
//         subscribedGroups: ['Group A', 'Group B'],
//         selectedGroups: ['Group A', 'Group B'],
//     }
//     try {
//       const response = await fetch(`${import.meta.env.VITE_API_URL}/api/user_info`);
//       const userData = await response.json();
//       const userIdFromEmail = userData.user_email.split('@')[0];
//       userDetails = {...userDetails, userId: userIdFromEmail, name: userData?.display_name, email: userData?.user_email};
//     } catch(err) {
//       console.error(err)
//     } finally {
//       login(userDetails)
//     }
//   }, []);


//   return (
//     <ThemeProvider theme={theme}>
//       <BrowserRouter>
//         <Layout>
//           <Routes>
//             <Route path="/" element={<Navigate to="/rule-management" replace />} />
//             <Route path="/rule-management" element={<RuleManagement />} />
//             <Route path="/rule-management/create" element={<CreateRules />} />
//             <Route path="/rule-management/table/:table" element={<TableRuleDetails />} />
//             <Route path="/rule-management/glossary" element={<Glossary />} />
//             <Route path="/groups" element={<Groups />} />
//             <Route path="/groups/create" element={<CreateGroup />} />
//             <Route path="/groups/:groupId" element={<GroupDetail />} />
//             {/* <Route path="/groups/:id" element={<GroupDetail />} /> */}
//             {<Route path="/rule-management/approval" element={
//               // <ProtectedRoute allowedRoles={['data-engineer']}>
//                 <Approval />
//               // </ProtectedRoute>
//             } />}
//             <Route path="/alerts" element={<Alerts />} />
//           </Routes>
//         </Layout>
//       </BrowserRouter>
//     </ThemeProvider>
//   )
// };

// export default App;

