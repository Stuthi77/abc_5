import * as React from 'react';
import { useTheme } from '@mui/material/styles';
import OutlinedInput from '@mui/material/OutlinedInput';
import MenuItem from '@mui/material/MenuItem';
import FormControl from '@mui/material/FormControl';
import Select from '@mui/material/Select';
import { useLocation } from 'react-router-dom'; // 1. IMPORT useLocation
import useSessionStorage from './useSessionStorage';

const ITEM_HEIGHT = 48;
const ITEM_PADDING_TOP = 10;
const MenuProps = {
  PaperProps: {
    style: {
      maxHeight: ITEM_HEIGHT * 4.5 + ITEM_PADDING_TOP,
      width: 200,
    },
  },
};

export default function GroupSelect() {
  const theme = useTheme();
  // 2. GET CURRENT LOCATION
  const location = useLocation();
  
  // Using a custom hook to manage userData from sessionStorage
  const [userData, setUserData] = useSessionStorage("userData");
  
  const [selectedGroup, setSelectedGroup] = React.useState("");
  const [groups, setGroups] = React.useState([]);

  // 3. DEFINE DISABLE CONDITION
  // Disable if the current path is the approval page
  const isApprovalPage = location.pathname.startsWith("/rule-management/approval");

  // Use this effect to fetch groups initially and update state
  React.useEffect(() => {
    // This part should be modified to fetch the data directly from the API
    // as the initial source of truth, rather than sessionStorage.
    const fetchGroups = async () => {
      try {
        // Ensure userId exists before fetching
        if (!userData.userId) return; 

        const response = await fetch(`${import.meta.env.VITE_API_URL}/api/groups?user_id=${userData.userId}`);
        const allGroups = await response.json();

        // Assuming your API response has a subscription_status field
        // Only show groups the user is subscribed to
        const subscribed = allGroups.filter((g) => g.subscription_status === "true");
        setGroups(subscribed);

        // Check if a selected group exists in sessionStorage and if it's still a subscribed group
        const selectedGroupFromSession = userData?.selectedGroup;
        const isSelectedValid = selectedGroupFromSession && subscribed.some(g => g.group_name === selectedGroupFromSession);

        if (!isSelectedValid && subscribed.length > 0) {
          // Fallback to the first subscribed group
          const fallbackGroup = subscribed[0];
          setSelectedGroup(fallbackGroup.group_name);
          setUserData(prevUserData => ({
            ...prevUserData,
            selectedGroup: fallbackGroup.group_name,
            selectedGroupId: fallbackGroup.group_id
          }));
        } else {
          // Use stored selection or empty string
          setSelectedGroup(selectedGroupFromSession || "");
        }
      } catch (error) {
        console.error("Error fetching groups:", error);
      }
    };

    if (userData && userData.userId) {
      fetchGroups();
    }

  }, [userData.userId, setUserData]); // Removed userData from dependency array, using only userId/setUserData to prevent infinite loop

  const handleChange = (event) => {
    // If disabled, prevent any change logic
    if (isApprovalPage) return; 
    
    const newValue = event.target.value;
    
    // Check if the new value is different from the current selected group
    if (newValue !== selectedGroup) {
      // Find the group object from the 'groups' state to get the group_id
      const selected = groups.find(g => g.group_name === newValue);
      
      if (selected) {
        setSelectedGroup(newValue);
        setUserData(prevUserData => ({
          ...prevUserData,
          selectedGroup: selected.group_name,
          selectedGroupId: selected.group_id
        }));
        
        // Reload the page only if the selection has changed
        window.location.reload();
      }
    }
  };

  return (
    <FormControl sx={{ width: 200 }}>
      <Select
        value={selectedGroup}
        onChange={handleChange}
        input={<OutlinedInput />}
        displayEmpty
        MenuProps={MenuProps}
        inputProps={{ "aria-label": "Without label" }}
        sx={{ height: "30px !important;" }}
        renderValue={(selected) => {
          if (!selected) return <em>Choose Group</em>;
          return selected;
        }}
        // 4. APPLY DISABLED PROP
        disabled={isApprovalPage} 
      >
        <MenuItem disabled value="">
          <em>Choose Group</em>
        </MenuItem>
        {groups.map((group) => (
          <MenuItem key={group.group_id} value={group.group_name}>
            {group.group_name}
          </MenuItem>
        ))}
      </Select>
    </FormControl>
  );
}
// import * as React from 'react';
// import { useTheme } from '@mui/material/styles';
// import OutlinedInput from '@mui/material/OutlinedInput';
// import MenuItem from '@mui/material/MenuItem';
// import FormControl from '@mui/material/FormControl';
// import Select from '@mui/material/Select';
// import useSessionStorage from './useSessionStorage';

// const ITEM_HEIGHT = 48;
// const ITEM_PADDING_TOP = 10;
// const MenuProps = {
//   PaperProps: {
//     style: {
//       maxHeight: ITEM_HEIGHT * 4.5 + ITEM_PADDING_TOP,
//       width: 200,
//     },
//   },
// };

// export default function GroupSelect() {
//   const theme = useTheme();
//   // Using a custom hook to manage userData from sessionStorage
//   const [userData, setUserData] = useSessionStorage("userData");
  
//   const [selectedGroup, setSelectedGroup] = React.useState("");
//   const [groups, setGroups] = React.useState([]);

//   // Use this effect to fetch groups initially and update state
//   React.useEffect(() => {
//     // This part should be modified to fetch the data directly from the API
//     // as the initial source of truth, rather than sessionStorage.
//     const fetchGroups = async () => {
//       try {
//         const response = await fetch(`${import.meta.env.VITE_API_URL}/api/groups?user_id=${userData.userId}`);
//         const allGroups = await response.json();

//         // Assuming your API response has a subscription_status field
//         const subscribed = allGroups.filter((g) => g.subscription_status === "true");
//         setGroups(subscribed);

//         // Check if a selected group exists in sessionStorage and if it's still a subscribed group
//         const selectedGroupFromSession = userData?.selectedGroup;
//         const isSelectedValid = selectedGroupFromSession && subscribed.some(g => g.group_name === selectedGroupFromSession);

//         if (!isSelectedValid && subscribed.length > 0) {
//           const fallbackGroup = subscribed[0];
//           setSelectedGroup(fallbackGroup.group_name);
//           setUserData({
//             ...userData,
//             selectedGroup: fallbackGroup.group_name,
//             selectedGroupId: fallbackGroup.group_id
//           });
//         } else {
//           setSelectedGroup(selectedGroupFromSession || "");
//         }
//       } catch (error) {
//         console.error("Error fetching groups:", error);
//       }
//     };

//     if (userData && userData.userId) {
//       fetchGroups();
//     }

//   }, [userData, setUserData]);

//   const handleChange = (event) => {
//     const newValue = event.target.value;
    
//     // Check if the new value is different from the current selected group
//     if (newValue !== selectedGroup) {
//       // Find the group object from the 'groups' state to get the group_id
//       const selected = groups.find(g => g.group_name === newValue);
      
//       if (selected) {
//         setSelectedGroup(newValue);
//         setUserData(prevUserData => ({
//           ...prevUserData,
//           selectedGroup: selected.group_name,
//           selectedGroupId: selected.group_id
//         }));
        
//         // Reload the page only if the selection has changed
//         window.location.reload();
//       }
//     }
//   };

//   return (
//     <FormControl sx={{ width: 200 }}>
//       <Select
//         value={selectedGroup}
//         onChange={handleChange}
//         input={<OutlinedInput />}
//         displayEmpty
//         MenuProps={MenuProps}
//         inputProps={{ "aria-label": "Without label" }}
//         sx={{ height: "30px !important;" }}
//         renderValue={(selected) => {
//           if (!selected) return <em>Choose Group</em>;
//           return selected;
//         }}
//       >
//         <MenuItem disabled value="">
//           <em>Choose Group</em>
//         </MenuItem>
//         {groups.map((group) => (
//           <MenuItem key={group.group_id} value={group.group_name}>
//             {group.group_name}
//           </MenuItem>
//         ))}
//       </Select>
//     </FormControl>
//   );
// }
// import * as React from 'react';
// import { useTheme } from '@mui/material/styles';
// import OutlinedInput from '@mui/material/OutlinedInput';
// import MenuItem from '@mui/material/MenuItem';
// import FormControl from '@mui/material/FormControl';
// import Select from '@mui/material/Select';
// import useSessionStorage from './useSessionStorage';

// const ITEM_HEIGHT = 48;
// const ITEM_PADDING_TOP = 10;
// const MenuProps = {
//   PaperProps: {
//     style: {
//       maxHeight: ITEM_HEIGHT * 4.5 + ITEM_PADDING_TOP,
//       width: 200,
//     },
//   },
// };

// export default function GroupSelect() {
//   const theme = useTheme();
//   const [userData, setUserData] = useSessionStorage("userData");
  
//   const [selectedGroup, setSelectedGroup] = React.useState("");
//   const [groups, setGroups] = React.useState([]);

//   React.useEffect(() => {
//     if (!userData) {
//       setGroups([]);
//       setSelectedGroup("");
//       return;
//     }

//     try {
//       const subscribedGroups = userData?.subscribedGroups || [];
//       const selectedGroupFromSession = userData?.selectedGroup;
      
//       const formattedGroups = subscribedGroups.map(groupName => ({
//         group_id: null,
//         group_name: groupName,
//       }));
//       setGroups(formattedGroups);

//       const isSelectedValid = selectedGroupFromSession && subscribedGroups.includes(selectedGroupFromSession);

//       if (!isSelectedValid && subscribedGroups.length > 0) {
//         const fallbackGroup = subscribedGroups[0];
//         setSelectedGroup(fallbackGroup);
//         setUserData({ ...userData, selectedGroup: fallbackGroup });
//       } else {
//         setSelectedGroup(selectedGroupFromSession || "");
//       }
//     } catch (e) {
//       console.error("Failed to process user data from session storage", e);
//     }
//   }, [userData, setUserData]);

//   const handleChange = (event) => {
//     const newValue = event.target.value;
    
//     // Check if the new value is different from the current selected group
//     if (newValue !== selectedGroup) {
//       setSelectedGroup(newValue);
      
//       setUserData(prevUserData => ({
//         ...prevUserData,
//         selectedGroup: newValue,
//       }));
      
//       // Reload the page only if the selection has changed
//       window.location.reload();
//     }
//   };

//   return (
//     <FormControl sx={{ width: 200 }}>
//       <Select
//         value={selectedGroup}
//         onChange={handleChange}
//         input={<OutlinedInput />}
//         displayEmpty
//         MenuProps={MenuProps}
//         inputProps={{ "aria-label": "Without label" }}
//         sx={{ height: "30px !important;" }}
//         renderValue={(selected) => {
//           if (!selected) return <em>Choose Group</em>;
//           return selected;
//         }}
//       >
//         <MenuItem disabled value="">
//           <em>Choose Group</em>
//         </MenuItem>
//         {groups.map((group) => (
//           <MenuItem key={group.group_name} value={group.group_name}>
//             {group.group_name}
//           </MenuItem>
//         ))}
//       </Select>
//     </FormControl>
//   );
// }
// import * as React from 'react';
// import { useTheme } from '@mui/material/styles';
// import OutlinedInput from '@mui/material/OutlinedInput';
// import MenuItem from '@mui/material/MenuItem';
// import FormControl from '@mui/material/FormControl';
// import Select from '@mui/material/Select';

// const ITEM_HEIGHT = 48;
// const ITEM_PADDING_TOP = 10;
// const MenuProps = {
//   PaperProps: {
//     style: {
//       maxHeight: ITEM_HEIGHT * 4.5 + ITEM_PADDING_TOP,
//       width: 200,
//     },
//   },
// };

// export default function GroupSelect() {
//   const theme = useTheme();
//   const [selectedGroup, setSelectedGroup] = React.useState("");
//   const [groups, setGroups] = React.useState([]);

//   React.useEffect(() => {
//     const userData = sessionStorage.getItem("userData");
//     if (!userData) return;

//     try {
//       const parsedData = JSON.parse(userData);
//       const userId = parsedData?.userId;
//       if (!userId) return;

//       const fetchGroups = async () => {
//         try {
//           const response = await fetch(
//             `${import.meta.env.VITE_API_URL}/api/groups?user_id=${userId}`
//           );
//           const data = await response.json();

//           // ✅ Filter subscribed groups
//           const subscribed = data.filter((g) => g.subscription_status === "true");
//           setGroups(subscribed);

//           // ✅ Validate currently selected group
//           const isSelectedValid =
//             parsedData.selectedGroupId &&
//             subscribed.some((g) => g.group_id === parsedData.selectedGroupId);

//           if (!isSelectedValid && subscribed.length > 0) {
//             // ✅ If invalid or not subscribed, fallback to first subscribed group
//             parsedData.selectedGroup = subscribed[0].group_name;
//             parsedData.selectedGroupId = subscribed[0].group_id;
//             setSelectedGroup(subscribed[0].group_name);
//           } else {
//             setSelectedGroup(parsedData.selectedGroup || "");
//           }

//           sessionStorage.setItem("userData", JSON.stringify(parsedData));
//         } catch (error) {
//           console.error("Error fetching groups:", error);
//         }
//       };

//       fetchGroups();
//     } catch (e) {
//       console.error("Failed to parse user data from session storage", e);
//     }
//   }, []);

//   const handleChange = (event) => {
//     const value = event.target.value;
//     setSelectedGroup(value);

//     const selected = groups.find((g) => g.group_name === value);

//     if (selected) {
//       const userData = sessionStorage.getItem("userData");
//       if (userData) {
//         try {
//           const parsedData = JSON.parse(userData);
//           parsedData.selectedGroup = selected.group_name;
//           parsedData.selectedGroupId = selected.group_id;
//           sessionStorage.setItem("userData", JSON.stringify(parsedData));

//           // You can remove window.location.reload() if your app reacts to context/state changes
//           window.location.reload();
//         } catch (e) {
//           console.error("Failed to update user data in session storage", e);
//         }
//       }
//     }
//   };

//   return (
//     <FormControl sx={{ width: 200 }}>
//       <Select
//         value={selectedGroup}
//         onChange={handleChange}
//         input={<OutlinedInput />}
//         displayEmpty
//         MenuProps={MenuProps}
//         inputProps={{ "aria-label": "Without label" }}
//         sx={{ height: "30px !important;" }}
//         renderValue={(selected) => {
//           if (!selected) return <em>Choose Group</em>;
//           return selected;
//         }}
//       >
//         <MenuItem disabled value="">
//           <em>Choose Group</em>
//         </MenuItem>
//         {groups.map((group) => (
//           <MenuItem key={group.group_id} value={group.group_name}>
//             {group.group_name}
//           </MenuItem>
//         ))}
//       </Select>
//     </FormControl>
//   );
// }

// // import * as React from 'react';
// // import { useTheme } from '@mui/material/styles';
// // import OutlinedInput from '@mui/material/OutlinedInput';
// // import MenuItem from '@mui/material/MenuItem';
// // import FormControl from '@mui/material/FormControl';
// // import Select from '@mui/material/Select';

// // const ITEM_HEIGHT = 48;
// // const ITEM_PADDING_TOP = 10;
// // const MenuProps = {
// //   PaperProps: {
// //     style: {
// //       maxHeight: ITEM_HEIGHT * 4.5 + ITEM_PADDING_TOP,
// //       width: 200,
// //     },
// //   },
// // };

// // export default function GroupSelect() {
// //   const theme = useTheme();
// //   const [selectedGroup, setSelectedGroup] = React.useState("");
// //   const [groups, setGroups] = React.useState([]);

// //   React.useEffect(() => {
// //     const userData = sessionStorage.getItem("userData");
// //     if (!userData) return;

// //     try {
// //       const parsedData = JSON.parse(userData);
// //       const userId = parsedData?.userId;
// //       if (!userId) return;

// //       const fetchGroups = async () => {
// //         try {
// //           const response = await fetch(
// //             `${import.meta.env.VITE_API_URL}/api/groups?user_id=${userId}`
// //           );
// //           const data = await response.json();

// //           // Only subscribed groups
// //           const subscribed = data.filter((g) => g.subscription_status === "true");
// //           setGroups(subscribed);

// //           // Check if current selected group is part of subscribed
// //           const isSelectedValid = parsedData.selectedGroupId
// //             ? subscribed.some((g) => g.group_id === parsedData.selectedGroupId)
// //             : false;

// //           // If invalid or missing, set to default first group
// //           if (!isSelectedValid && subscribed.length > 0) {
// //             parsedData.selectedGroup = subscribed[0].group_name;
// //             parsedData.selectedGroupId = subscribed[0].group_id;
// //             setSelectedGroup(subscribed[0].group_name);
// //           } else {
// //             setSelectedGroup(parsedData.selectedGroup || "");
// //           }

// //           sessionStorage.setItem("userData", JSON.stringify(parsedData));
// //         } catch (error) {
// //           console.error("Error fetching groups:", error);
// //         }
// //       };

// //       fetchGroups();
// //     } catch (e) {
// //       console.error("Failed to parse user data from session storage", e);
// //     }
// //   }, []);

// //   const handleChange = (event) => {
// //     const value = event.target.value;
// //     setSelectedGroup(value);

// //     const selected = groups.find((g) => g.group_name === value);

// //     if (selected) {
// //       const userData = sessionStorage.getItem("userData");
// //       if (userData) {
// //         try {
// //           const parsedData = JSON.parse(userData);
// //           parsedData.selectedGroup = selected.group_name;
// //           parsedData.selectedGroupId = selected.group_id;
// //           sessionStorage.setItem("userData", JSON.stringify(parsedData));

// //           // You can remove window.location.reload() if your app reacts to context/state changes
// //           window.location.reload();
// //         } catch (e) {
// //           console.error("Failed to update user data in session storage", e);
// //         }
// //       }
// //     }
// //   };

// //   return (
// //     <FormControl sx={{ width: 200 }}>
// //       <Select
// //         value={selectedGroup}
// //         onChange={handleChange}
// //         input={<OutlinedInput />}
// //         displayEmpty
// //         MenuProps={MenuProps}
// //         inputProps={{ "aria-label": "Without label" }}
// //         sx={{ height: "30px !important;" }}
// //         renderValue={(selected) => {
// //           if (!selected) return <em>Choose Group</em>;
// //           return selected;
// //         }}
// //       >
// //         <MenuItem disabled value="">
// //           <em>Choose Group</em>
// //         </MenuItem>
// //         {groups.map((group) => (
// //           <MenuItem key={group.group_id} value={group.group_name}>
// //             {group.group_name}
// //           </MenuItem>
// //         ))}
// //       </Select>
// //     </FormControl>
// //   );
// // }
// // // import * as React from 'react';
// // // import { useTheme } from '@mui/material/styles';
// // // import OutlinedInput from '@mui/material/OutlinedInput';
// // // import MenuItem from '@mui/material/MenuItem';
// // // import FormControl from '@mui/material/FormControl';
// // // import Select from '@mui/material/Select';

// // // const ITEM_HEIGHT = 48;
// // // const ITEM_PADDING_TOP = 10;
// // // const MenuProps = {
// // //   PaperProps: {
// // //     style: {
// // //       maxHeight: ITEM_HEIGHT * 4.5 + ITEM_PADDING_TOP,
// // //       width: 200,
// // //     },
// // //   },
// // // };
// // // export default function GroupSelect() {
// // //   const theme = useTheme();
// // //   const [selectedGroup, setSelectedGroup] = React.useState("");
// // //   const [groups, setGroups] = React.useState([]);

// // //   React.useEffect(() => {
// // //     const userData = sessionStorage.getItem("userData");
// // //     if (!userData) return;

// // //     try {
// // //       const parsedData = JSON.parse(userData);
// // //       const userId = parsedData?.userId;
// // //       if (!userId) return;

// // //       const fetchGroups = async () => {
// // //         try {
// // //           const response = await fetch(
// // //             `${import.meta.env.VITE_API_URL}/api/groups?user_id=${userId}`
// // //           );
// // //           const data = await response.json();

// // //           const subscribed = data.filter(
// // //             (group) => group.subscription_status === "true"
// // //           );
// // //           setGroups(subscribed);

// // //           // ✅ Only set default if nothing already saved
// // //           if (!parsedData.selectedGroupId && subscribed.length > 0) {
// // //             parsedData.selectedGroup = subscribed[0].group_name;
// // //             parsedData.selectedGroupId = subscribed[0].group_id;
// // //             sessionStorage.setItem("userData", JSON.stringify(parsedData));
// // //             setSelectedGroup(subscribed[0].group_name);
// // //           } else {
// // //             setSelectedGroup(parsedData.selectedGroup || "");
// // //           }
// // //         } catch (error) {
// // //           console.error("Error fetching groups:", error);
// // //         }
// // //       };

// // //       fetchGroups();
// // //     } catch (e) {
// // //       console.error("Failed to parse user data from session storage", e);
// // //     }
// // //   }, []);

// // //   const handleChange = (event) => {
// // //     const value = event.target.value;
// // //     setSelectedGroup(value);

// // //     const selected = groups.find((g) => g.group_name === value);

// // //     if (selected) {
// // //       const userData = sessionStorage.getItem("userData");
// // //       if (userData) {
// // //         try {
// // //           const parsedData = JSON.parse(userData);
// // //           parsedData.selectedGroup = selected.group_name;
// // //           parsedData.selectedGroupId = selected.group_id;
// // //           sessionStorage.setItem("userData", JSON.stringify(parsedData));

// // //           // ✅ No need to reload entire page, just trigger re-render if needed
// // //           window.location.reload();
// // //         } catch (e) {
// // //           console.error("Failed to update user data in session storage", e);
// // //         }
// // //       }
// // //     }
// // //   };

// // //   return (
// // //     <FormControl sx={{ width: 200 }}>
// // //       <Select
// // //         value={selectedGroup}
// // //         onChange={handleChange}
// // //         input={<OutlinedInput />}
// // //         displayEmpty
// // //         MenuProps={MenuProps}
// // //         inputProps={{ "aria-label": "Without label" }}
// // //         sx={{ height: "30px !important;" }}
// // //         renderValue={(selected) => {
// // //           if (!selected) return <em>Choose Group</em>;
// // //           return selected;
// // //         }}
// // //       >
// // //         <MenuItem disabled value="">
// // //           <em>Choose Group</em>
// // //         </MenuItem>
// // //         {groups.map((group) => (
// // //           <MenuItem key={group.group_id} value={group.group_name}>
// // //             {group.group_name}
// // //           </MenuItem>
// // //         ))}
// // //       </Select>
// // //     </FormControl>
// // //   );
// // // }

// // // export default function GroupSelect() {
// // //   const theme = useTheme();
// // //   const [selectedGroup, setSelectedGroup] = React.useState("");
// // //   const [groups, setGroups] = React.useState([]);

// // //   React.useEffect(() => {
// // //     const userData = sessionStorage.getItem("userData");
// // //     if (!userData) return;

// // //     try {
// // //       const parsedData = JSON.parse(userData);
// // //       const userId = parsedData?.userId;

// // //       if (!userId) return;

// // //       const fetchGroups = async () => {
// // //         try {
// // //           const response = await fetch(
// // //             `${import.meta.env.VITE_API_URL}/api/groups?user_id=${userId}`
// // //           );
// // //           const data = await response.json();

// // //           // Only subscribed groups
// // //           const subscribed = data.filter(
// // //             (group) => group.subscription_status === "true"
// // //           );
// // //           setGroups(subscribed);

// // //           // Save subscribedGroups list in session
// // //           parsedData.subscribedGroups = subscribed.map((g) => g.group_name);

// // //           // Set default group
// // //           if (parsedData.selectedGroup && parsedData.selectedGroupId) {
// // //             setSelectedGroup(parsedData.selectedGroup);
// // //           } else if (subscribed.length > 0) {
// // //             setSelectedGroup(subscribed[0].group_name);
// // //             parsedData.selectedGroup = subscribed[0].group_name;
// // //             parsedData.selectedGroupId = subscribed[0].group_id;
// // //           }

// // //           sessionStorage.setItem("userData", JSON.stringify(parsedData));
// // //         } catch (error) {
// // //           console.error("Error fetching groups:", error);
// // //         }
// // //       };

// // //       fetchGroups();
// // //     } catch (e) {
// // //       console.error("Failed to parse user data from session storage", e);
// // //     }
// // //   }, []);

// // //   const handleChange = (event) => {
// // //     const value = event.target.value;
// // //     setSelectedGroup(value);

// // //     // Find group_id for selected group
// // //     const selected = groups.find((g) => g.group_name === value);

// // //     // Update sessionStorage
// // //     const userData = sessionStorage.getItem("userData");
// // //     if (userData && selected) {
// // //       try {
// // //         const parsedData = JSON.parse(userData);
// // //         parsedData.selectedGroup = selected.group_name;
// // //         parsedData.selectedGroupId = selected.group_id;
// // //         sessionStorage.setItem("userData", JSON.stringify(parsedData));
// // //         window.location.reload();
// // //       } catch (e) {
// // //         console.error("Failed to update user data in session storage", e);
// // //       }
// // //     }
// // //   };

// // //   return (
// // //     <div>
// // //       <FormControl sx={{ width: 200 }}>
// // //         <Select
// // //           value={selectedGroup}
// // //           onChange={handleChange}
// // //           input={<OutlinedInput />}
// // //           displayEmpty
// // //           MenuProps={MenuProps}
// // //           inputProps={{ "aria-label": "Without label" }}
// // //           sx={{ height: "30px !important;" }}
// // //           renderValue={(selected) => {
// // //             if (!selected) {
// // //               return <em>Choose Group</em>;
// // //             }
// // //             return selected;
// // //           }}
// // //         >
// // //           <MenuItem disabled value="">
// // //             <em>Choose Group</em>
// // //           </MenuItem>
// // //           {groups.map((group) => (
// // //             <MenuItem key={group.group_id} value={group.group_name}>
// // //               {group.group_name}
// // //             </MenuItem>
// // //           ))}
// // //         </Select>
// // //       </FormControl>
// // //     </div>
// // //   );
// // // }