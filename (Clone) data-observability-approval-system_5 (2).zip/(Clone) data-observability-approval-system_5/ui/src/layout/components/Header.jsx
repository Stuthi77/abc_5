// import React, { useState, useEffect } from "react";
// import { AppBar, Toolbar, IconButton, Typography, Box, Select, MenuItem, FormControl } from "@mui/material";
// import MenuIcon from "@mui/icons-material/Menu";
// import DatabricksLogo from "../../assets/databricks.png";
// import UserProfile from "./UserProfile";
// import { useAuth } from "../../shared/context/AuthContext";
// import SelectGroup from "./SelectGroup";

// const Header = ({ toggleDrawer }) => {
//   const { user } = useAuth();
//   const [selectedGroup, setSelectedGroup] = useState(sessionStorage.getItem("selectedGroup") || "");

//   useEffect(() => {
//     // if (!selectedGroup && user?.subscribedGroups?.length > 0) {
//     //   setSelectedGroup(user.subscribedGroups[0]);
//     //   sessionStorage.setItem("selectedGroup", user.subscribedGroups[0]);

//     // }
//   }, [user, selectedGroup]);

//   const handleGroupChange = (e) => {
//     const value = e.target.value;
//     setSelectedGroup(value);
//     sessionStorage.setItem("selectedGroup", value);
//   };

//   return (
//     <Box sx={{ flexGrow: 1, position: "sticky", top: 0, zIndex: 1000 }}>
//       <AppBar
//         position="static"
//         elevation={0}
//         sx={{
//           zIndex: (theme) => theme.zIndex.drawer + 1,
//           backgroundColor: "#F5F5F5",
//           height: "58px",
//           color: "#1a1a1a",
//           borderBottom: "1px solid #e0e0e0",
//         }}
//       >
//         <Toolbar
//           sx={{
//             minHeight: "58px !important",
//             px: 1,
//             justifyContent: "space-between",
//           }}
//         >
//           <Box sx={{ display: "flex" }}>
//             <IconButton
//               color="inherit"
//               edge="start"
//               onClick={toggleDrawer}
//               sx={{ mr: 1, pl: 0.75 }}
//             >
//               <MenuIcon fontSize="small" />
//             </IconButton>

//             <Box sx={{ display: "flex", alignItems: "center" }}>
//               <img
//                 src={DatabricksLogo}
//                 alt="logo"
//                 style={{ height: 20, marginRight: 0, marginLeft: -15 }}
//               />
//               <Typography variant="h5" sx={{ fontSize: 14, fontWeight: 500 }}>
//                 Lakewatch
//               </Typography>
//             </Box>
//           </Box>
//           <Box
//             sx={{
//               display: "flex",
//               justifyItems: "end",
//               alignItems: "center",
//               gap: 2,
//             }}
//           >
//             <Box sx={{ display: "flex", alignItems: "center", gap: 1, fontSize: 14, fontWeight: 500 }}>
//               <SelectGroup />
//             </Box>
//             <Box>
//               <UserProfile />
//             </Box>
//           </Box>
//         </Toolbar>
//       </AppBar>
//     </Box>
//   );
// };

// export default Header;
import React, { useState, useEffect } from "react";
import { AppBar, Toolbar, IconButton, Typography, Box, Select, MenuItem, FormControl } from "@mui/material";
import MenuIcon from "@mui/icons-material/Menu";
import DatabricksLogo from "../../assets/databricks.png";
import UserProfile from "./UserProfile";
import { useAuth } from "../../shared/context/AuthContext";
import SelectGroup from "./SelectGroup";

const Header = ({ toggleDrawer }) => {
  const { user } = useAuth();
  const [selectedGroup, setSelectedGroup] = useState(sessionStorage.getItem("selectedGroup") || "");

  useEffect(() => {
    // if (!selectedGroup && user?.subscribedGroups?.length > 0) {
    //   setSelectedGroup(user.subscribedGroups[0]);
    //   sessionStorage.setItem("selectedGroup", user.subscribedGroups[0]);

    // }
  }, [user, selectedGroup]);

  const handleGroupChange = (e) => {
    const value = e.target.value;
    setSelectedGroup(value);
    sessionStorage.setItem("selectedGroup", value);
  };

  return (
    <Box sx={{ flexGrow: 1, position: "sticky", top: 0, zIndex: 1000 }}>
      <AppBar
        position="static"
        elevation={0}
        sx={{
          zIndex: (theme) => theme.zIndex.drawer + 1,
          backgroundColor: "#F5F5F5",
          height: "48px", // Reduced header height
          color: "#1a1a1a",
          borderBottom: "1px solid #e0e0e0",
        }}
      >
        <Toolbar
          sx={{
            minHeight: "48px !important", // Reduced toolbar height
            px: 1,
            justifyContent: "space-between",
          }}
        >
          <Box sx={{ display: "flex" }}>
            <IconButton
              color="inherit"
              edge="start"
              onClick={toggleDrawer}
              sx={{ mr: 1, pl: 0.75 }}
            >
              <MenuIcon fontSize="small" />
            </IconButton>

            <Box sx={{ display: "flex", alignItems: "center" }}>
              <img
                src={DatabricksLogo}
                alt="logo"
                style={{ height: 24, marginRight: 0, marginLeft: -15 }} // Increased logo size
              />
              <Typography variant="h6" sx={{ fontSize: 14, fontWeight: 500 }}> 
                DQRules
              </Typography>
            </Box>
          </Box>
          <Box
            sx={{
              display: "flex",
              justifyItems: "end",
              alignItems: "center",
              gap: 2,
            }}
          >
            <Box sx={{ display: "flex", alignItems: "center", gap: 1, fontSize: 14, fontWeight: 500 }}>
              <SelectGroup />
            </Box>
            <Box>
              <UserProfile />
            </Box>
          </Box>
        </Toolbar>
      </AppBar>
    </Box>
  );
};

export default Header;