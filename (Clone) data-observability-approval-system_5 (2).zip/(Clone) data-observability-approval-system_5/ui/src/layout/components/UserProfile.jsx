import Avatar from '@mui/material/Avatar';
import Box from '@mui/material/Box';
import Tooltip, { tooltipClasses } from '@mui/material/Tooltip';
import Typography from '@mui/material/Typography';
import { styled } from '@mui/material/styles';

const LightGrayTooltip = styled(({ className, ...props }) => (
  <Tooltip {...props} classes={{ popper: className }} />
))(({ theme }) => ({
  [`& .${tooltipClasses.tooltip}`]: {
    backgroundColor: '#F7F7F7', // A very light gray shade
    color: theme.palette.text.primary,
    boxShadow: 'none', // No shadow for a flatter, modern look
    fontSize: 14,
    borderRadius: '4px', // Minimal rounding
    padding: '8px 12px', // Reduced padding for a smaller height
    border: `1px solid ${theme.palette.divider}`,
    // Removed maxWidth to allow the tooltip to auto-size
  },
  [`& .${tooltipClasses.arrow}`]: {
    color: '#E0E0E0', // A slightly darker gray for the arrow to make it visible
  },
  // Add margin to the popper to create a gap from the right edge
  [`&.${tooltipClasses.popper}[data-popper-placement*="right"]`]: {
    marginRight: '20px', 
  },
}));

function stringToColor(string) {
  let hash = 0;
  let i;

  for (i = 0; i < string.length; i += 1) {
    hash = string.charCodeAt(i) + ((hash << 5) - hash);
  }

  let color = '#';

  for (i = 0; i < 3; i += 1) {
    const value = (hash >> (i * 8)) & 0xff;
    color += `00${value.toString(16)}`.slice(-2);
  }
  return color;
}

function stringAvatar(name) {
  const parts = name.split(' ');
  let initials = '';
  if (parts.length > 1) {
    initials = `${parts[0][0]}${parts[1][0]}`;
  } else if (parts.length === 1 && name.length > 0) {
    initials = `${name[0]}`;
  }

  return {
    sx: {
      bgcolor: stringToColor(name),
      width: 40,
      height: 40,
      fontSize: '1.25rem',
    },
    children: initials.toUpperCase(),
  };
}

function UserProfile() {
  const userDataString = sessionStorage.getItem('userData');
  const userData = userDataString ? JSON.parse(userDataString) : null;

  if (!userData) {
    return null;
  }

  const userEmail = userData.email || 'N/A';
  const userName = userData.name || 'User';

  const tooltipTitle = (
    <Box>
      <Typography variant="body2" sx={{ fontWeight: 'bold' }}>
        {userName}
      </Typography>
      <Typography variant="body2" color="text.secondary">
        {userEmail}
      </Typography>
    </Box>
  );

  return (
    <Box sx={{ display: "flex", alignItems: "center" }}>
      <LightGrayTooltip title={tooltipTitle} placement="bottom-end" arrow>
        <Avatar {...stringAvatar(userName)} />
      </LightGrayTooltip>
    </Box>
  );
}

export default UserProfile;
// import Avatar from '@mui/material/Avatar';
// import Box from '@mui/material/Box';
// import Tooltip, { tooltipClasses } from '@mui/material/Tooltip';
// import Typography from '@mui/material/Typography';
// import { styled } from '@mui/material/styles';

// const LightGrayTooltip = styled(({ className, ...props }) => (
//   <Tooltip {...props} classes={{ popper: className }} />
// ))(({ theme }) => ({
//   [`& .${tooltipClasses.tooltip}`]: {
//     backgroundColor: '#F7F7F7', // A very light gray shade
//     color: theme.palette.text.primary,
//     boxShadow: 'none', // No shadow for a flatter, modern look
//     fontSize: 14,
//     borderRadius: '4px', // Minimal rounding
//     padding: '8px 12px', // Reduced padding for a smaller height
//     border: `1px solid ${theme.palette.divider}`,
//     maxWidth: 250,
//   },
//   [`& .${tooltipClasses.arrow}`]: {
//     color: '#E0E0E0', // A slightly darker gray for the arrow to make it visible
//   },
//   // Add margin to the popper to create a gap from the right edge
//   [`&.${tooltipClasses.popper}[data-popper-placement*="right"]`]: {
//     marginRight: '20px', 
//   },
// }));

// function stringToColor(string) {
//   let hash = 0;
//   let i;

//   for (i = 0; i < string.length; i += 1) {
//     hash = string.charCodeAt(i) + ((hash << 5) - hash);
//   }

//   let color = '#';

//   for (i = 0; i < 3; i += 1) {
//     const value = (hash >> (i * 8)) & 0xff;
//     color += `00${value.toString(16)}`.slice(-2);
//   }
//   return color;
// }

// function stringAvatar(name) {
//   const parts = name.split(' ');
//   let initials = '';
//   if (parts.length > 1) {
//     initials = `${parts[0][0]}${parts[1][0]}`;
//   } else if (parts.length === 1 && name.length > 0) {
//     initials = `${name[0]}`;
//   }

//   return {
//     sx: {
//       bgcolor: stringToColor(name),
//       width: 40,
//       height: 40,
//       fontSize: '1.25rem',
//     },
//     children: initials.toUpperCase(),
//   };
// }

// function UserProfile() {
//   const userDataString = sessionStorage.getItem('userData');
//   const userData = userDataString ? JSON.parse(userDataString) : null;

//   if (!userData) {
//     return null;
//   }

//   const userEmail = userData.email || 'N/A';
//   const userName = userData.name || 'User';

//   const tooltipTitle = (
//     <Box>
//       <Typography variant="body2" sx={{ fontWeight: 'bold' }}>
//         {userName}
//       </Typography>
//       <Typography variant="body2" color="text.secondary">
//         {userEmail}
//       </Typography>
//     </Box>
//   );

//   return (
//     <Box sx={{ display: "flex", alignItems: "center" }}>
//       <LightGrayTooltip title={tooltipTitle} placement="bottom-end" arrow>
//         <Avatar {...stringAvatar(userName)} />
//       </LightGrayTooltip>
//     </Box>
//   );
// }

// export default UserProfile;
// import Avatar from '@mui/material/Avatar';
// import Box from '@mui/material/Box';

// function stringToColor(string) {
//     let hash = 0;
//     let i;

//     for (i = 0; i < string.length; i += 1) {
//         hash = string.charCodeAt(i) + ((hash << 5) - hash);
//     }

//     let color = '#';

//     for (i = 0; i < 3; i += 1) {
//         const value = (hash >> (i * 8)) & 0xff;
//         color += `00${value.toString(16)}`.slice(-2);
//     }
//     return color;
// }

// function stringAvatar(name) {
//     return {
//         sx: {
//             bgcolor: stringToColor(name),
//         },
//         children: `${name.split(' ')[0][0]}${name.split(' ')[1][0]}`,
//     };
// }

// function UserProfile() {

//     return (
//         <Box sx={{ display: "flex", alignItems: "center" }}>
//             {sessionStorage.getItem('userData') && <Avatar {...stringAvatar(JSON.parse(sessionStorage.getItem('userData'))['name'] || 'User')} />}

//         </Box>
//     );
// }


// export default UserProfile;