// import React from "react";
// import { NavLink, useLocation } from "react-router-dom";
// import DashboardIcon from "@mui/icons-material/Dashboard";
// import AddCircleOutlineIcon from "@mui/icons-material/AddCircleOutline";
// import GroupsIcon from '@mui/icons-material/Groups';
// import CheckCircleOutlineIcon from "@mui/icons-material/CheckCircleOutline";
// import NotificationsNoneIcon from "@mui/icons-material/NotificationsNone";
// import "./SideNavBar.css";

// import { useAuth } from "../../shared/context/AuthContext";

// const SideNavBar = ({ isOpen }) => {
//   const { user } = useAuth();
//   const { pathname } = useLocation();

 
//   const isCreateActive = pathname.startsWith("/rule-management/create");
//   const isApprovalActive = pathname.startsWith("/rule-management/approval");


//   const isRuleMgmtActive =
//     pathname === "/rule-management" ||
//     (pathname.startsWith("/rule-management/") &&
//       !isCreateActive &&
//       !isApprovalActive);

//   const isAlertsActive = pathname === "/alerts" || pathname.startsWith("/alerts/");
//   const isGroupsActive = pathname === "/groups" || pathname.startsWith("/groups/");

//   return (
//     <div className={`sidebar ${!isOpen ? "collapsed" : ""}`}>

//       {/* Parent: Rule Management */}
//       <NavLink
//         to="/rule-management"
//         end
//         className={() =>
//           `sidebar-link parent-link ${isRuleMgmtActive ? "active" : ""}`
//         }
//       >
//         <span className="icon-wrapper">
//           <DashboardIcon fontSize="small" />
//         </span>
//         {isOpen && <span>Defined Rules</span>}
//       </NavLink>

    
//       <NavLink
//         to="/rule-management/create"
//         end
//         className={() =>
//           `sidebar-link sub-link ${isCreateActive ? "active" : ""}`
//         }
//       >
//         <span className="icon-wrapper">
//           <AddCircleOutlineIcon fontSize="small" />
//         </span>
//         {isOpen && <span>Add Rules</span>}
//       </NavLink>

      
//       {user?.role === 'data-engineer' && (
//         <NavLink
//           to="/rule-management/approval"
//           end
//           className={() =>
//             `sidebar-link sub-link ${isApprovalActive ? "active" : ""}`
//           }
//         >
//           <span className="icon-wrapper">
//             <CheckCircleOutlineIcon fontSize="small" />
//           </span>
//           {isOpen && <span>Approval</span>}
//         </NavLink>
//       )}

//       <NavLink
//         to="/alerts"
//         end
//         className={() =>
//           `sidebar-link ${isAlertsActive ? "active" : ""}`
//         }
//       >
//         <span className="icon-wrapper">
//           <NotificationsNoneIcon fontSize="small" />
//         </span>
//         {isOpen && <span>Alerts</span>}
//       </NavLink>


//       <NavLink
//         to="/groups"
//         end
//         className={() =>
//           `sidebar-link ${isGroupsActive ? "active" : ""}`
//         }
//       >
//         <GroupsIcon fontSize="small" />
//         {isOpen && <span>Groups</span>}
//       </NavLink>
//     </div>
//   );
// };

import React from "react";
import { NavLink, useLocation } from "react-router-dom";
import DashboardIcon from "@mui/icons-material/Dashboard";
import AddCircleOutlineIcon from "@mui/icons-material/AddCircleOutline";
import GroupsIcon from '@mui/icons-material/Groups';
import CheckCircleOutlineIcon from "@mui/icons-material/CheckCircleOutline";
import NotificationsNoneIcon from "@mui/icons-material/NotificationsNone";

// 1. ADDED: Import a Material UI icon for the AI Recommendations
import AutoAwesomeIcon from "@mui/icons-material/AutoAwesome"; 

import "./SideNavBar.css";
import { useAuth } from "../../shared/context/AuthContext";

const SideNavBar = ({ isOpen }) => {
  const { user } = useAuth(); // Keeping this for reference/basic checks
  const { pathname } = useLocation();

  // --- FIX: Retrieve subscribedGroups from sessionStorage ---
  const userData = JSON.parse(sessionStorage.getItem("userData")) || {};
  const subscribedGroups = userData.subscribedGroups || [];

  // Logic: Check if the user is subscribed to the 'Approvers' group
  const isApproverSubscriber = subscribedGroups.includes('Approvers');
  // --- END FIX ---

  const isCreateActive = pathname.startsWith("/rule-management/create");
  const isApprovalActive = pathname.startsWith("/rule-management/approval");
  
  // 2. ADDED: Logic to check if the LLM Recommendation page is currently active
  // const isLlmRecActive = pathname.startsWith("/llm_recommendation");

  const isRuleMgmtActive =
    pathname === "/rule-management" ||
    (pathname.startsWith("/rule-management/") &&
      !isCreateActive &&
      !isApprovalActive);

  const isAlertsActive = pathname === "/alerts" || pathname.startsWith("/alerts/");
  const isGroupsActive = pathname === "/groups" || pathname.startsWith("/groups/");

  return (
    <div className={`sidebar ${!isOpen ? "collapsed" : ""}`}>

      {/* Parent: Defined Rules */}
      <NavLink
        to="/rule-management"
        end
        className={() =>
          `sidebar-link parent-link ${isRuleMgmtActive ? "active" : ""}`
        }
      >
        <span className="icon-wrapper">
          <DashboardIcon fontSize="small" />
        </span>
        {isOpen && <span>Defined Rules</span>}
      </NavLink>

      {/* Sub-link: Add Rules */}
      <NavLink
        to="/rule-management/create"
        end
        className={() =>
          `sidebar-link sub-link ${isCreateActive ? "active" : ""}`
        }
      >
        <span className="icon-wrapper">
          <AddCircleOutlineIcon fontSize="small" />
        </span>
        {isOpen && <span>Add Rules</span>}
      </NavLink>

      
      {/* Sub-link: Approval (Conditional Visibility using sessionStorage) */}
      {isApproverSubscriber && (
        <NavLink
          to="/rule-management/approval"
          end
          className={() =>
            `sidebar-link sub-link ${isApprovalActive ? "active" : ""}`
          }
        >
          <span className="icon-wrapper">
            <CheckCircleOutlineIcon fontSize="small" />
          </span>
          {isOpen && <span>Approval</span>}
        </NavLink>
      )}

      {/* 3. ADDED: Sub-link for LLM Recommendation
      <NavLink
        to="/llm_recommendation"
        end
        className={() =>
          `sidebar-link sub-link ${isLlmRecActive ? "active" : ""}`
        }
      >
        <span className="icon-wrapper">
          <AutoAwesomeIcon fontSize="small" />
        </span>
        {isOpen && <span>LLM Recommendation</span>}
      </NavLink> */}

      {/* Alerts Link */}
      <NavLink
        to="/alerts"
        end
        className={() =>
          `sidebar-link ${isAlertsActive ? "active" : ""}`
        }
      >
        <span className="icon-wrapper">
          <NotificationsNoneIcon fontSize="small" />
        </span>
        {isOpen && <span>Alerts</span>}
      </NavLink>


      {/* Groups Link */}
      <NavLink
        to="/groups"
        end
        className={() =>
          `sidebar-link ${isGroupsActive ? "active" : ""}`
        }
      >
        <GroupsIcon fontSize="small" />
        {isOpen && <span>Groups</span>}
      </NavLink>
    </div>
  );
};

export default SideNavBar;