// src/layout/Layout.jsx
import React, { useEffect, useState } from "react";
import { Box } from "@mui/material";
import Header from "./components/Header";
import SideNavBar from "./components/SideNavBar";
import { Divider } from "@mui/material";
import { useAuth } from '../shared/context/AuthContext';
import Grid from '@mui/material/Grid';

const Layout = ({ children }) => {
  const [isDrawerOpen, setIsDrawerOpen] = useState(true);

  const toggleDrawer = () => {
    setIsDrawerOpen((prev) => !prev);
  };

  const headerHeight = 48;
  const footerHeight = 40;
  const sidebarWidth = isDrawerOpen ? 190 : 40;

  return (
    <>
      <Header toggleDrawer={toggleDrawer} />
      <Grid container spacing={0} >
        <Grid size={isDrawerOpen ? 1.5 : 0.5}>
          <SideNavBar isOpen={isDrawerOpen} />
        </Grid>
        <Grid size={isDrawerOpen ? 10.5 : 11.5}>
          <Box
            component="main"
            sx={{
              backgroundColor: "#ffffffff",
              maxHeight: "calc(100vh - 60px)",
              overflowY: "auto",
              marginLeft: 3
            }}
          >
            {children}</Box>
        </Grid>
      </Grid >
    </>
  );

  return (
    <Box>
      {/* <Box sx={{ display: "flex", height: "100vh", overflow: "hidden" }}> */}
      <Header toggleDrawer={toggleDrawer} />
      {/* Side Navigation Bar */}


      {/* Right Content Area */}
      <Box
        sx={{
          flexGrow: 1,
          display: "flex",
          flexDirection: "row",
          transition: "margin-left 0.3s ease",
        }}
      >
        {/* Top Header */}

        {/* <Divider sx={{ height: "0px", backgroundColor: "#ccc" }} /> */}
        <SideNavBar isOpen={isDrawerOpen} />
        {/* Main Page Content */}
        <Box
          component="main"
          sx={{
            flexGrow: 1,
            backgroundColor: "#ffffff",
            p: 2,
            overflowY: "auto", 
            border: "1px solid #ddd",
            height: "100%",
          }}
        >
          {children}
        </Box>
      </Box>

      {/* Fixed Footer */}
      <Box
        sx={{
          height: `${footerHeight}px`,
          position: "fixed",
          bottom: -15,
          left: 0,
          right: 0,
          zIndex: 10,
        }}
      >
        <Footer />
      </Box>
    </Box>
  );
};

export default Layout;
