import React, { useState, useEffect, useRef } from "react";
import { Box, TextField, MenuItem, Typography, Grid } from "@mui/material";
import AutoGrowTextarea from "../auto-grow-textarea/AutoGrowTextarea";

// Mirrors classify_data_type() / DATA_TYPE_CATEGORIES in
// server/app/LLMRecommendation/llm_recommendation_logic.py so the manual
// rule-creation form gives the same type-aware guidance as the LLM
// recommendations. Covers every Databricks/Spark column type we've seen
// (string, short/smallint, byte/tinyint, integer/bigint, decimal/float/
// double, boolean, timestamp/date, binary), with an "other" fallback so an
// unrecognized type never breaks rendering.
const DATA_TYPE_CATEGORY_PREFIXES = [
  ["string", ["STRING", "VARCHAR", "CHAR", "TEXT"]],
  ["byte", ["TINYINT", "BYTE"]],
  ["short", ["SMALLINT", "SHORT"]],
  ["integer", ["INT", "INTEGER", "BIGINT", "LONG"]],
  ["decimal", ["DECIMAL", "NUMERIC", "FLOAT", "DOUBLE", "REAL"]],
  ["boolean", ["BOOLEAN", "BOOL"]],
  ["temporal", ["TIMESTAMP", "DATE"]],
  ["binary", ["BINARY"]],
];

const classifyDataType = (dataType) => {
  if (!dataType) return "other";
  const t = String(dataType).trim().toUpperCase();
  for (const [category, prefixes] of DATA_TYPE_CATEGORY_PREFIXES) {
    if (prefixes.some((p) => t.startsWith(p))) return category;
  }
  return "other";
};

// Condition types that are typically meaningful for each category. This is
// advisory only — every condition type stays selectable regardless of the
// chosen column's data type; nothing here removes or blocks an option.
const CATEGORY_CONDITION_HINTS = {
  string: ["REGEX_MATCH", "LENGTH_CHECK", "FORMAT_CHECK", "MAPPING_CHECK", "CASE_STANDARDIZATION", "REFERENCE_CHECK", "REFERENCE_CHECK_CUSTOM"],
  byte: ["MUST_HAVE_VALUE", "MAPPING_CHECK", "REFERENCE_CHECK"],
  boolean: ["MUST_HAVE_VALUE", "MAPPING_CHECK"],
  short: ["RANGE_CHECK", "VALUE_THRESHOLD", "MAPPING_CHECK", "OUTLIER_DETECTION", "REFERENCE_CHECK"],
  integer: ["RANGE_CHECK", "VALUE_THRESHOLD", "OUTLIER_DETECTION", "REFERENCE_CHECK"],
  decimal: ["RANGE_CHECK", "VALUE_THRESHOLD", "OUTLIER_DETECTION", "KPI_CHECK"],
  temporal: ["DATE_RANGE", "TIME_STAMP_CHECK", "ROW_COUNT_TREND"],
  binary: [],
  other: [],
};

// Condition types that are type-agnostic and always considered a fit,
// regardless of the selected column(s) data type.
const TYPE_AGNOSTIC_CONDITIONS = new Set([
  "NOT_NULL",
  "BLANK",
  "NOT_NULL_LENGTH_CHECK",
  "UNIQUE",
  "DUPLICATE",
  "CUSTOM_RULE",
  "KPI_CHECK",
]);

const conditionConfig = {
  NOT_NULL: {},
  BLANK: {},
  MUST_HAVE_VALUE: {
    fields: [{ name: "value", label: "Must Have Values (comma separated)", type: "array" }],
  },
  NOT_NULL_LENGTH_CHECK: {
    fields: [{ name: "value", label: "Minimum Length", type: "number" }],
  },
  REGEX_MATCH: {
    fields: [{ name: "regex_pattern", label: "Regex Pattern", type: "text" }],
  },
  LENGTH_CHECK: {
    fields: [{ name: "value", label: "Expected Length", type: "number" }],
  },
  FORMAT_CHECK: {
    fields: [{ name: "regex_pattern", label: "Format Regex", type: "text" }],
  },
  RANGE_CHECK: {
    fields: [
      { name: "min_value", label: "Minimum Value", type: "number" },
      { name: "max_value", label: "Maximum Value", type: "number" },
    ],
  },
  VALUE_THRESHOLD: {
    fields: [
      { name: "operator", label: "Operator", type: "select", options: [">", "<", ">=", "<=", "==", "!="] },
      { name: "value_threshold", label: "Threshold Value", type: "number" },
    ],
  },
  DATE_RANGE: {
    fields: [
      { name: "start_date", label: "Start Date", type: "date" },
      { name: "end_date", label: "End Date", type: "date" },
    ],
  },
  UNIQUE: {
    fields: [{ name: "identifier_column", label: "Identifier Column", type: "select", dynamicOptions: true }],
  },
  DUPLICATE: {},
  CUSTOM_RULE: {
    fields: [{ name: "custom_query", label: "Custom SQL Expression", type: "text" }],
  },
  CASE_STANDARDIZATION: {
    fields: [{ name: "case", label: "Standardization", type: "select", options: ["UPPER", "LOWER"] }],
  },
  MAPPING_CHECK: {
    fields: [{ name: "value", label: "Allowed Values (comma separated)", type: "array" }],
  },
  OUTLIER_DETECTION: {
    fields: [{ name: "value", label: "Sensitivity Level", type: "number" }],
  },
  TIME_STAMP_CHECK: {
    fields: [{ name: "condition", label: "Timestamp Condition", type: "text" }],
  },
  ROW_COUNT_TREND: {
    fields: [{ name: "interval", label: "Interval", type: "number" }],
  },
  KPI_CHECK: {
    fields: [
      { name: "custom_query", label: "Custom KPI Expression", type: "text" },
      { name: "lower_threshold", label: "Lower Threshold", type: "number" },
      { name: "upper_threshold", label: "Upper Threshold", type: "number" },
      { name: "interval", label: "Interval", type: "number" },
    ],
  },
  // Cross-table "must have value" check: the selected column's values must
  // appear among the DISTINCT values of a column in a DIFFERENT table.
  // condition_criteria shape matches construct_reference_check_query in
  // dq_framework/generic_rules.py exactly: {catalog, schema, table_name,
  // targeted_column}.
  REFERENCE_CHECK: {
    fields: [
      { name: "catalog", label: "Reference Catalog", type: "text" },
      { name: "schema", label: "Reference Schema", type: "text" },
      { name: "table_name", label: "Reference Table", type: "text" },
      { name: "targeted_column", label: "Reference Column", type: "text" },
    ],
  },
  // Cross-table check comparing only a TRANSFORMED PORTION of the column's
  // value (a prefix, suffix, fixed substring, or text before/after a
  // delimiter) against the reference table's distinct values — e.g. first
  // 15 characters of a code, last 10 of an account number, or the domain
  // after '@' in an email. condition_criteria shape matches
  // construct_reference_check_custom_query in dq_framework/generic_rules.py.
  REFERENCE_CHECK_CUSTOM: {
    fields: [
      { name: "catalog", label: "Reference Catalog", type: "text" },
      { name: "schema", label: "Reference Schema", type: "text" },
      { name: "table_name", label: "Reference Table", type: "text" },
      { name: "targeted_column", label: "Reference Column", type: "text" },
      {
        name: "transform",
        label: "Compare Using",
        type: "select",
        options: ["FIRST_N", "LAST_N", "MIDDLE", "AFTER_DELIMITER", "BEFORE_DELIMITER"],
      },
      // Used by FIRST_N, LAST_N, MIDDLE
      { name: "length", label: "Length (# chars)", type: "number" },
      // Used by MIDDLE only (1-based)
      { name: "start", label: "Start Position (MIDDLE)", type: "number" },
      // Used by AFTER_DELIMITER / BEFORE_DELIMITER
      { name: "delimiter", label: "Delimiter (e.g. @)", type: "text" },
    ],
  },
};

const DynamicConditionFields = ({
  category,
  type,
  columns = [],
  criteria = {},
  onCriteriaChange,
  // Optional: { [column_name]: data_type } for the current table (all data
  // types — string, short, byte, decimal, timestamp, etc.). When provided
  // alongside selectedColumns, shows a small advisory note if the chosen
  // condition type isn't a typical fit for the selected column(s) type —
  // purely informational, never disables or removes a condition type option.
  columnDataTypes = {},
  selectedColumns = [],
}) => {
  const [formState, setFormState] = useState(criteria || {});
  const prevTypeRef = React.useRef(type);

  useEffect(() => {
    if (prevTypeRef.current !== type) {
      // User changed the condition type — clear fields
      prevTypeRef.current = type;
      setFormState({});
      onCriteriaChange?.({});
    } else {
      // Same type but criteria prop updated (e.g. LLM rule added,
      // or form opened with existing rule data) — populate fields
      const incoming = criteria || {};
      if (Object.keys(incoming).length > 0) {
        setFormState(incoming);
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [type, criteria]);

  const handleChange = (key, value) => {
    const updated = { ...formState, [key]: value };
    setFormState(updated);
    onCriteriaChange?.(updated);
  };

  const getFormattedValue = (fieldType, rawValue) => {
    if (rawValue === "" || rawValue === null) return fieldType === "number" ? null : rawValue;
    if (fieldType === "number") return Number(rawValue);
    if (fieldType === "array") return rawValue.split(",").map((v) => v.trim());
    return rawValue;
  };

  if (!category || !type) return null;

  const config = conditionConfig[type];
  const fields = config?.fields || [];

  // Build a non-blocking "does this condition type fit the column's data
  // type?" advisory. Only shown when we actually know the column type(s) and
  // the condition type isn't type-agnostic (NOT_NULL, UNIQUE, CUSTOM_RULE...).
  const getTypeFitHint = () => {
    if (TYPE_AGNOSTIC_CONDITIONS.has(type)) return null;
    const cols = (selectedColumns || []).filter((c) => columnDataTypes[c]);
    if (cols.length === 0) return null;

    const categories = [...new Set(cols.map((c) => classifyDataType(columnDataTypes[c])))];
    const mismatched = categories.filter(
      (cat) => cat !== "other" && !(CATEGORY_CONDITION_HINTS[cat] || []).includes(type)
    );
    if (mismatched.length === 0) return null;

    const exampleCol = cols.find((c) => classifyDataType(columnDataTypes[c]) === mismatched[0]);
    return `Heads up: "${type}" isn't a typical fit for ${exampleCol} (${columnDataTypes[exampleCol]}). You can still save it — just double-check the criteria.`;
  };

  const typeFitHint = getTypeFitHint();

  if (fields.length === 0) {
    return (
      <Box>
        <Typography mt={2} color="text.secondary">
          No parameters needed for this rule type.
        </Typography>
        {typeFitHint && (
          <Typography mt={1} variant="caption" color="warning.main" display="block">
            {typeFitHint}
          </Typography>
        )}
      </Box>
    );
  }

  const isFullWidthField = (type, fieldName) => {
    if (type === "CUSTOM_RULE") return true;
    if (fieldName === "custom_query") return true;
    // FIX: regex_pattern and condition can hold long content (a full
    // regex, or a timestamp condition like "cdw_modifieddate > '2020-01-01'")
    // and were previously stuck at a fixed 145px width, same problem as
    // custom_query.
    if (fieldName === "regex_pattern" || fieldName === "condition") return true;
    return false;
  };

  // FIX: these fields can hold long, multi-line-worthy content (a full SQL
  // expression, a regex pattern, a timestamp condition) and were previously
  // forced into a single-line, fixed-height box -- even when full width,
  // long text just scrolled horizontally instead of wrapping, making it
  // impossible to see/edit the whole value at a glance.
  const isLongTextField = (fieldName) =>
    ["custom_query", "regex_pattern", "condition"].includes(fieldName);

  return (
    <Box>
    {typeFitHint && (
      <Typography mb={1} variant="caption" color="warning.main" display="block">
        {typeFitHint}
      </Typography>
    )}
    <Grid container spacing={2}>
      {fields.map((field) => {
        const raw = formState[field.name] ?? "";
        // Arrays (e.g. MUST_HAVE_VALUE / MAPPING_CHECK lists) display as
        // comma-separated text, matching how the user types them.
        const value = Array.isArray(raw) ? raw.join(", ") : raw;
        const longText = isLongTextField(field.name);

        // FIX (round 3): MUI's multiline TextField kept fighting our CSS
        // overrides no matter how specifically we targeted its internal
        // elements -- its own auto-sizing mechanism (a hidden shadow
        // textarea measuring content height) repeatedly won out, leaving
        // the visible outline mismatched with the actual content bounds.
        // Long-text fields now use a plain, manually-styled <textarea> --
        // the exact same pattern already proven to work correctly for the
        // "Enter Rule description" field in this dialog -- instead of
        // continuing to patch around MUI's internals.
        // FIX (round 4): the callback-ref auto-grow approach only measured
        // height once, at mount -- it missed content that arrives
        // asynchronously (e.g. editing an existing rule, where the real
        // SQL/regex value loads slightly after this field first renders).
        // AutoGrowTextarea (a proper useRef + useEffect keyed on value)
        // re-measures on every value change regardless of why it changed.
        if (longText) {
          return (
            <Grid size={12} key={field.name}>
              <Typography
                variant="caption"
                sx={{ color: "rgba(0, 0, 0, 0.6)", fontSize: "0.75rem", display: "block", mb: 0.5 }}
              >
                {field.label}
              </Typography>
              <AutoGrowTextarea
                value={value}
                onChange={(e) => handleChange(field.name, getFormattedValue(field.type, e.target.value))}
                rows={4}
                minHeight={84}
                style={{
                  width: "100%",
                  padding: "10px 14px",
                  fontSize: "0.85rem",
                  borderRadius: "4px",
                  border: "1px solid rgba(0, 0, 0, 0.23)",
                  backgroundColor: "#fff",
                  fontFamily: "'Segoe UI', sans-serif",
                  boxSizing: "border-box",
                  transition: "border-color 0.2s, box-shadow 0.2s",
                  outline: "none",
                  resize: "vertical",
                  lineHeight: 1.4,
                  overflow: "hidden",
                }}
                onFocus={(e) => {
                  e.target.style.border = "1px solid #1976d2";
                  e.target.style.boxShadow = "0 0 0 1px #1976d2";
                }}
                onBlur={(e) => {
                  e.target.style.border = "1px solid rgba(0, 0, 0, 0.23)";
                  e.target.style.boxShadow = "none";
                }}
              />
            </Grid>
          );
        }

        const commonProps = {
          label: field.label,
          value,
          onChange: (e) => handleChange(field.name, getFormattedValue(field.type, e.target.value)),
          size: "small",
          sx: {
            fontFamily: "'Segoe UI', sans-serif",
            fontSize: "0.85rem",
            height: 32,
            // FIX: was a cramped fixed 145px -- widened to 220px, matching
            // Severity/Violation Threshold elsewhere in this dialog. Many
            // of these fields (Reference Catalog, Reference Schema,
            // Reference Table, Reference Column) hold real catalog/schema/
            // table names that didn't comfortably fit at the old width.
            width: isFullWidthField(type, field.name) ? "100%" : 220,
          },
          InputLabelProps: field.type === "date" ? { shrink: true } : {},
        };

        if (field.type === "select") {
          const options = field.dynamicOptions ? columns : field.options || [];
          return (
            <TextField {...commonProps} select key={field.name}>
              {options.map((opt) => (
                <MenuItem key={opt} value={opt}>
                  {opt}
                </MenuItem>
              ))}
            </TextField>
          );
        }

        return <TextField key={field.name} {...commonProps} type={field.type === "number" ? "number" : "text"} />;
      })}
    </Grid>
    </Box>
  );
};

export default DynamicConditionFields;
