// import React from "react";
// import { Paper, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Typography } from "@mui/material";

// const rule_definitions = {
//   "Completeness Rules": {
//     NOT_NULL: "Ensures the field is not null.",
//     BLANK: "Checks for blank string values.",
//     MUST_HAVE_VALUE: "Field must contain a value from a valid list.",
//     NOT_NULL_LENGTH_CHECK: "Ensures value is not null and meets length constraints.",
//   },
//   "Format & Pattern Validation": {
//     REGEX_MATCH: "Validates using regular expressions.",
//     LENGTH_CHECK: "Ensures field meets length criteria.",
//     FORMAT_CHECK: "General format validation (email, phone, etc).",
//   },
//   "Range & Threshold Rules": {
//     RANGE_CHECK: "Validates values fall within a min-max range.",
//     VALUE_THRESHOLD: "Checks if values exceed defined thresholds.",
//     DATE_RANGE: "Validates if dates fall within a valid window.",
//   },
//   "Uniqueness & Duplicate Checks": {
//     UNIQUE: "Ensures field values are unique.",
//     DUPLICATE: "Detects duplicate entries.",
//   },
//   "Business Logic Rules": {
//     CUSTOM_RULE: "Implements custom SQL expressions or joins.",
//   },
//   "Consistency & Standardization Checks": {
//     CASE_STANDARDIZATION: "Ensures consistent casing (e.g., upper/lower).",
//     MAPPING_CHECK: "Verifies values match a predefined mapping.",
//   },
//   "Anomaly Detection": {
//     OUTLIER_DETECTION: "Flags statistically anomalous values.",
//   },
//   "Time-based Validations": {
//     TIME_STAMP_CHECK: "Ensures timestamp exists and is valid.",
//   },
//   "Trend Analysis": {
//     ROW_COUNT_TREND: "Monitors row count trends over time.",
//   },
//   "KPI Statistics": {
//     KPI_CHECK: "Compares KPI metrics across snapshots or thresholds.",
//   },
// };

// const GlossaryTable = () => {
//   const rows = Object.entries(rule_definitions).flatMap(([category, rules]) =>
//     Object.entries(rules).map(([type, desc]) => ({
//       category,
//       type,
//       description: desc,
//     }))
//   );

//   return (
//     <TableContainer component={Paper} sx={{ maxHeight: "55vh", overflow: "auto" }}>
//       <Table stickyHeader>
//         <TableHead>
//           <TableRow>
//             <TableCell><strong>Condition Category</strong></TableCell>
//             <TableCell><strong>Condition Type</strong></TableCell>
//             <TableCell><strong>Description</strong></TableCell>
//           </TableRow>
//         </TableHead>
//         <TableBody>
//           {rows.map((row, idx) => (
//             <TableRow key={idx}>
//               <TableCell>{row.category}</TableCell>
//               <TableCell>{row.type}</TableCell>
//               <TableCell>{row.description}</TableCell>
//             </TableRow>
//           ))}
//         </TableBody>
//       </Table>
//     </TableContainer>
//   );
// };

// export default GlossaryTable;
import React from "react";
import {
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
} from "@mui/material";

const rule_definitions = {
  "Completeness Rules": {
    NOT_NULL: "Ensures the field is not null.",
    BLANK: "Checks for blank string values.",
    MUST_HAVE_VALUE: "Field must contain a value from a valid list.",
    NOT_NULL_LENGTH_CHECK: "Ensures value is not null and meets length constraints.",
  },
  "Format & Pattern Validation": {
    REGEX_MATCH: "Validates using regular expressions.",
    LENGTH_CHECK: "Ensures field meets length criteria.",
    FORMAT_CHECK: "General format validation (email, phone, etc).",
  },
  "Range & Threshold Rules": {
    RANGE_CHECK: "Validates values fall within a min-max range.",
    VALUE_THRESHOLD: "Checks if values exceed defined thresholds.",
    DATE_RANGE: "Validates if dates fall within a valid window.",
  },
  "Uniqueness & Duplicate Checks": {
    UNIQUE: "Ensures field values are unique.",
    DUPLICATE: "Detects duplicate entries.",
  },
  "Business Logic Rules": {
    CUSTOM_RULE: "Implements custom SQL expressions or joins.",
  },
  "Consistency & Standardization Checks": {
    CASE_STANDARDIZATION: "Ensures consistent casing (e.g., upper/lower).",
    MAPPING_CHECK: "Verifies values match a predefined mapping.",
  },
  "Anomaly Detection": {
    OUTLIER_DETECTION: "Flags statistically anomalous values.",
  },
  "Time-based Validations": {
    TIME_STAMP_CHECK: "Ensures timestamp exists and is valid.",
  },
  "Trend Analysis": {
    ROW_COUNT_TREND: "Monitors row count trends over time.",
  },
  "KPI Statistics": {
    KPI_CHECK: "Compares KPI metrics across snapshots or thresholds.",
  },
};

const GlossaryTable = ({ searchTerm, categories, types }) => {
  // Flatten object into array of rows
  const rows = Object.entries(rule_definitions).flatMap(([category, rules]) =>
    Object.entries(rules).map(([type, desc]) => ({
      category,
      type,
      description: desc,
    }))
  );

  // 🔹 Apply filters & search
  const filteredRows = rows.filter((row) => {
    const matchesSearch =
      !searchTerm ||
      row.category.toLowerCase().includes(searchTerm.toLowerCase()) ||
      row.type.toLowerCase().includes(searchTerm.toLowerCase()) ||
      row.description.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesCategory =
      categories.length === 0 || categories.includes(row.category);

    const matchesType = types.length === 0 || types.includes(row.type);

    return matchesSearch && matchesCategory && matchesType;
  });

  return (
    <TableContainer component={Paper} sx={{ maxHeight: "55vh", overflow: "auto" }}>
      <Table stickyHeader>
        <TableHead>
          <TableRow>
            <TableCell><strong>Condition Category</strong></TableCell>
            <TableCell><strong>Condition Type</strong></TableCell>
            <TableCell><strong>Description</strong></TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {filteredRows.length > 0 ? (
            filteredRows.map((row, idx) => (
              <TableRow key={idx}>
                <TableCell>{row.category}</TableCell>
                <TableCell>{row.type}</TableCell>
                <TableCell>{row.description}</TableCell>
              </TableRow>
            ))
          ) : (
            <TableRow>
              <TableCell colSpan={3} align="center">
                No matching records found
              </TableCell>
            </TableRow>
          )}
        </TableBody>
      </Table>
    </TableContainer>
  );
};

export default GlossaryTable;

