import React, { useState , useEffect } from "react";
import { useAuth } from "../../../../shared/context/AuthContext";
import {
  Box,
  Card,
  CardContent,
  Typography,
  Chip,
  Grid,
  IconButton,
  Collapse,
  Tooltip,
  Divider,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  DialogContentText,
  Button,
  CircularProgress
} from "@mui/material";
import CheckCircleIcon from "@mui/icons-material/CheckCircle";
import HourglassEmptyIcon from "@mui/icons-material/HourglassEmpty";
import CancelIcon from "@mui/icons-material/Cancel";
import EditIcon from "@mui/icons-material/Edit";
import MailOutlineIcon from "@mui/icons-material/MailOutline";
import MailOffIcon from "@mui/icons-material/MailLock";
import DeleteIcon from "@mui/icons-material/Delete";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import ModifyRules from "../modify-rules/ModifyRules";
import { ruleManagementApi } from "../../../../services/ruleManagementApi";
import Snackbar from '@mui/material/Snackbar';
import MuiAlert from '@mui/material/Alert';


const severityColors = {
  Critical: "#d32f2f",
  Warning: "#f57c00",
  Info: "#1976d2",
  Low: "#388e3c",
};


const renderApprovalStatusChip = (approvalStatus) => {
  switch (approvalStatus) {
    case "Approved":
      return (
        <Chip
          icon={<CheckCircleIcon fontSize="small" />}
          label="Approved"
          color="success"
          variant="outlined"
          size="small"
          sx={{ fontWeight: "bold" }}
        />
      );
    case "Yet to Approve":
      return (
        <Chip
          icon={<HourglassEmptyIcon fontSize="small" />}
          label="Yet to Approve"
          size="small"
          sx={{
            bgcolor: "#fff3cd",
            color: "#856404",
            fontWeight: "bold",
            border: "1px solid #ffeeba",
          }}
        />
      );
    case "Rejected":
      return (
        <Chip
          icon={<CancelIcon fontSize="small" color="#d32f2f" />}
          label="Rejected"
          size="small"
          sx={{
            bgcolor: "#ffffffff",
            color: "#d32f2f",
            fontWeight: "bold",
            border: "1px solid #d32f2f",
          }}
        />
      );
    default:
      return null;
  }
};


const DetailedRuleCard = ({ rule, onModify, onDelete, tableId }) => {
  const { user } = useAuth();
  // FIX: Edit/Delete were previously shown to every user unconditionally --
  // no access check existed anywhere on this path (including when reached
  // via Alerts -> table name -> Table Rule Details). Gating on role here
  // using the app's existing (if currently under-used) permission concept.
  // NOTE: this is a role-level check, not a per-table/per-group one -- the
  // frontend has no data today identifying which group "owns" a given
  // table's rules (only alert_group_id, which controls notifications, not
  // edit rights). If per-table/group-scoped permissions are actually
  // needed, that requires a new backend field exposing table ownership,
  // not just this role check.
  const canModifyRules = ["data-engineer", "admin", "approver"].includes(
    (user?.role || "").toLowerCase()
  );
  const [editOpen, setEditOpen] = useState(false);
  const [confirmOpen, setConfirmOpen] = useState(false);
  const [snackbarOpen, setSnackbarOpen] = useState(false);
  const [snackbarMessage, setSnackbarMessage] = useState('');
  const [snackbarSeverity, setSnackbarSeverity] = useState('success');
  const [expanded, setExpanded] = useState(false);
  const [details, setDetails] = useState(null);
  const [detailsLoaded, setDetailsLoaded] = useState(false);
  const [detailsError, setDetailsError] = useState(null);
  const [detailsLoading, setDetailsLoading] = useState(false);


  const [isEditing, setIsEditing] = useState(false);
  const [tableColumns, setTableColumns] = useState([]);
  // { [column_name]: data_type } for every column of the rule's table
  // (string, short, byte, decimal, timestamp, etc.)
  const [tableColumnDataTypes, setTableColumnDataTypes] = useState({});
  const [columnsLoading, setColumnsLoading] = useState(false);


  const handleSaveEdit = (updatedRule) => {
    onModify(updatedRule);
    setIsEditing(false);
  };


  const handleConfirmDelete = async () => {
    if (!rule?.Rule_id) return;


    try {
      const response = await fetch(`${import.meta.env.VITE_API_URL}/api/rules/${rule.Rule_id}`, {
        method: 'DELETE'
      });
      const result = await response.json();


      if (response.ok) {
        // NEW: deleting now submits a request requiring approval instead of
        // deleting immediately -- the rule stays ACTIVE until an approver
        // reviews it, so it must not be removed from the visible list here
        // (that used to happen via onDelete?.() below, which implied the
        // rule was already gone).
        setSnackbarMessage(result.message || 'Delete request submitted -- awaiting approval.');
        setSnackbarSeverity('info');
        setSnackbarOpen(true);
      } else {
        setSnackbarMessage(result.error || 'Failed to submit delete request.');
        setSnackbarSeverity('error');
        setSnackbarOpen(true);
      }
    } catch (error) {
      setSnackbarMessage(`Error: ${error.message}`);
      setSnackbarSeverity('error');
      setSnackbarOpen(true);
    } finally {
      setConfirmOpen(false);
    }
  };


  const handleCardClick = () => {
    if (!isEditing) {
      setExpanded(!expanded);
    }
  };


  const handleEditClick = async (e) => {
    e.stopPropagation();
    setIsEditing(true);
    setEditOpen(true);


    if (tableColumns.length === 0) {
      setColumnsLoading(true);
      try {
        const columns = await ruleManagementApi.getTableColumns(rule.Rule_id);
        // Backend returns [{column_name, data_type}, ...] covering every
        // column type. Keep a plain name list for existing UI code, plus a
        // name -> data_type map for type-aware hints.
        const columnNames = columns.map((c) => (typeof c === "string" ? c : c.column_name));
        const dataTypes = Object.fromEntries(
          columns
            .filter((c) => c && typeof c === "object")
            .map((c) => [c.column_name, c.data_type])
        );
        setTableColumns(columnNames);
        setTableColumnDataTypes(dataTypes);
        setEditOpen(true);
      } catch (error) {
        console.error('Failed to fetch columns:', error);
        setTableColumns([]);
        setTableColumnDataTypes({});
        setEditOpen(true);
      } finally {
        setColumnsLoading(false);
      }
    } else {
      setEditOpen(true);
    }
  };


  const handleEditClose = () => {
    setEditOpen(false);
    setIsEditing(false);
  };


  useEffect(() => {
    const loadDetails = async () => {
      if (!expanded || detailsLoaded || !rule?.Rule_id) return;
     
      setDetailsLoading(true);
      try {
        const d = await ruleManagementApi.getRuleDetails(String(rule.Rule_id).trim());
        setDetails({
          condition_category: (d.condition_category ?? "").trim(),
          condition_criteria: d.condition_criteria ?? null,
          created_at: d.created_at ?? null,
          created_by: d.created_by ?? null,
          reviewed_at: d.reviewed_at ?? null,
          reviewed_by: d.reviewed_by ?? null,
          updated_at: d.updated_at ?? null,
        });
      } catch (e) {
        setDetailsError("Failed to load rule details");
      } finally {
        setDetailsLoaded(true);
        setDetailsLoading(false);
      }
    };
    loadDetails();
  }, [expanded, detailsLoaded, rule?.Rule_id]);


  const columns = rule.columns || [rule.column];
  const allColumnsStr = columns.join(", ");
 
  const conditionCategoryDisplay =
    (details?.condition_category ?? rule.conditionCategory ?? "N/A");


  const conditionCriteriaDisplay =
    (details?.condition_criteria ?? rule.conditionCriteria ?? "N/A");


  const createdByDisplay =
    (details?.created_by ?? rule.created_by ?? "N/A");


  const reviewedByDisplay =
    (details?.reviewed_by ?? rule.reviewed_by ?? "N/A");


  const createdDateDisplay =
    details?.created_at
      ? new Date(details.created_at).toLocaleDateString()
      : (rule.createdDate || "N/A");


  const reviewedDateDisplay =
    details?.reviewed_at
      ? new Date(details.reviewed_at).toLocaleDateString()
      : (rule.reviewed_at || "N/A");


  return (
<Card
  sx={{
    width: "100%",
    mb: 2,
    boxShadow: 3,
    borderRadius: 2,
    transition: "box-shadow 0.3s ease",
    "&:hover": { boxShadow: 6, cursor: "pointer" },
  }}
  onClick={handleCardClick}
>
  <CardContent sx={{ pb: 1 }}>
    <Grid container alignItems="center" justifyContent="space-between">
      <Grid item xs={12} md={5}>
        <Box display="flex" gap={1} flexWrap="wrap">
          <Typography fontWeight="bold" sx={{ fontSize: 15 }}>
            {rule.conditionType}
          </Typography>


          {(() => {
            const color = severityColors[rule.severity] || "#616161";
            return (
              <Chip
                label={rule.severity}
                variant="outlined"
                size="small"
                sx={{
                  color,
                  borderColor: color,
                  backgroundColor: "transparent",
                  fontWeight: "bold",
                  height: 24,
                }}
              />
            );
          })()}


          {rule.status === "Active" &&
            renderApprovalStatusChip(rule.approvalStatus)}

          <Chip
            label={rule.enforcementAction === "AUDIT_ONLY" ? "Audit only" : "Filter & audit"}
            variant="outlined"
            size="small"
            sx={{ fontWeight: 500, height: 24 }}
          />
          <Chip
            icon={rule.emailAlertEnabled === false ? <MailOffIcon fontSize="small" /> : <MailOutlineIcon fontSize="small" />}
            label={rule.emailAlertEnabled === false ? "Alert off" : "Alert on"}
            variant="outlined"
            size="small"
            sx={{ fontWeight: 500, height: 24 }}
          />
        </Box>
 
        <Box sx={{ flex: 1 , mt:1 }}>
          <Typography sx={{ fontSize: 12, mb: 1 }}>
            <strong>Columns:</strong>{" "}
            {allColumnsStr.length > 100 ? (
              <Tooltip title={allColumnsStr} arrow placement="bottom">
                <span style={{ cursor: "pointer" }}>
                  {allColumnsStr.slice(0, 60)}...
                </span>
              </Tooltip>
            ) : (
              allColumnsStr
            )}
          </Typography>

          <Typography sx={{ fontSize: 12, mb: 1 }}>
            <strong>Violation Threshold:</strong> {rule.violationThreshold}%
          </Typography>

          <Typography sx={{ fontSize: 12 }}>
            <strong>Description:</strong>{" "}
            {(rule.description || "").length > 120 ? (
              <Tooltip title={rule.description} arrow placement="bottom">
                <span style={{ cursor: "pointer" }}>
                  {(rule.description || "").slice(0, 50)}...
                </span>
              </Tooltip>
            ) : (
              rule.description || "N/A"
            )}
          </Typography>
        </Box>
      </Grid>


      <Grid item xs={12} md={3}>
        <Box display="flex" justifyContent="flex-end" gap={1}>
          {rule.status === "Active" && canModifyRules && (
            <>
              <Tooltip title="Modify">
                <IconButton
                  size="small"
                  color="primary"
                  onClick={handleEditClick}
                >
                  <EditIcon fontSize="small" />
                </IconButton>
              </Tooltip>
              <Tooltip title="Delete">
                <IconButton
                  size="small"
                  color="error"
                  onClick={(e) => {
                    e.stopPropagation();
                    setConfirmOpen(true);
                  }}
                >
                  <DeleteIcon fontSize="small" />
                </IconButton>
              </Tooltip>
            </>
          )}


          <Tooltip title={expanded ? "Collapse" : "Expand"}>
            <IconButton
              size="medium"
              onClick={(e) => {
                e.stopPropagation();
                setExpanded(!expanded);
              }}
              sx={{
                transform: expanded ? "rotate(180deg)" : "rotate(0deg)",
                transition: "transform 0.2s ease",
              }}
            >
              <ExpandMoreIcon />
            </IconButton>
          </Tooltip>
        </Box>
      </Grid>
    </Grid>
  </CardContent>


<ModifyRules
  open={editOpen}
  rule={rule}
  allColumns={tableColumns}
  allColumnDataTypes={tableColumnDataTypes}
  onClose={handleEditClose}
  onSave={handleSaveEdit}
  columnsLoading={columnsLoading}
/>
     
      <Dialog
        open={confirmOpen}
        onClose={() => setConfirmOpen(false)}
        maxWidth="xs"
        fullWidth
      >
        <DialogTitle>Confirm Delete Request</DialogTitle>
        <DialogContent>
          <DialogContentText>
            This will submit a request to delete rule <strong>{rule.conditionType}</strong>.
            The rule will remain active and enforced until an approver reviews and approves
            this request.
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setConfirmOpen(false)} color="inherit">
            Cancel
          </Button>
          <Button onClick={handleConfirmDelete} color="error" variant="contained">
            Submit Delete Request
          </Button>
        </DialogActions>
      </Dialog>


  <Collapse in={expanded} timeout="auto" unmountOnExit>
    <CardContent sx={{ pt: 0 }}>
      <Divider />


      {detailsLoading ? (
        <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', py: 4 }}>
          <CircularProgress size={24} />
          <Typography sx={{ ml: 2, fontSize: 12, color: 'text.secondary' }}>
            Loading details...
          </Typography>
        </Box>
      ) : detailsError ? (
        <Typography color="error" sx={{ textAlign: 'center', py: 2, fontSize: 12 }}>
          {detailsError}
        </Typography>
      ) : (
        <Grid container columns={12} spacing={20} mt={1}>
          <Grid size xs={12} md={6}>
            <Box sx={{ textAlign: "left" }}>
              <Typography color="text.secondary" sx={{ fontSize: 12 }}>
                <strong>Condition Category:</strong> {conditionCategoryDisplay}
              </Typography>


              <Typography color="text.secondary" sx={{ fontSize: 12 }}>
                <strong>Created By:</strong> {createdByDisplay}
              </Typography>


              <Typography color="text.secondary" sx={{ fontSize: 12 }}>
                <strong>Reviewed By:</strong> {reviewedByDisplay}
              </Typography>
            </Box>
          </Grid>


          <Grid size xs={12} md={6}>
            <Box sx={{ textAlign: "left" }}>
              <Typography color="text.secondary" sx={{ 
                fontSize: 12,
                wordBreak: 'break-all',
                overflowWrap: 'anywhere',
                maxWidth: '410px',
                whiteSpace: 'normal',
                lineHeight: 1.4
              }}>
                <strong>Condition Criteria:</strong> {conditionCriteriaDisplay}
              </Typography>


              <Typography color="text.secondary" sx={{ fontSize: 12 }}>
                <strong>Created Date:</strong> {createdDateDisplay}
              </Typography>


              <Typography color="text.secondary" sx={{ fontSize: 12 }}>
                <strong>Reviewed Date:</strong> {reviewedDateDisplay}
              </Typography>


            </Box>
          </Grid>
        </Grid>
      )}


      {!detailsLoading && !detailsError && rule.rejectedReason && (
        <Typography color="text.secondary" sx={{ fontSize: 12, color: "error.main", mt: 2 }}>
          <strong>Rejected Reason:</strong> {rule.rejectedReason}
        </Typography>
      )}
     
    </CardContent>
  </Collapse>
      <Snackbar
        open={snackbarOpen}
        autoHideDuration={3000}
        onClose={() => setSnackbarOpen(false)}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}
      >
        <MuiAlert
          onClose={() => setSnackbarOpen(false)}
          severity={snackbarSeverity}
          elevation={6}
          variant="filled"
          sx={{ width: '100%' }}
        >
          {snackbarMessage}
        </MuiAlert>
      </Snackbar>
</Card>
  );
};


export default DetailedRuleCard;



