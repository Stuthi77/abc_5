import React, { useState, useEffect, useRef , useMemo } from "react";
import {
  Box, Container, Typography, Divider, Button, Tabs, Tab, Grid , CircularProgress ,Skeleton , Stack,
  TextField, Checkbox, FormControlLabel, InputAdornment,
} from "@mui/material";
import SearchIcon from '@mui/icons-material/Search';
import MuiPagination from '../../../Shared/Components/Pagination/Pagination';
import DetailedRuleCard from '../../components/detailed-rule-card/DetailedRuleCard';
import Breadcrumbs from '@mui/material/Breadcrumbs';
import Link from '@mui/material/Link';
import { useNavigate, useParams, useLocation } from 'react-router-dom';
import TableChartIcon from '@mui/icons-material/TableChart';
import Search from '../../../Shared/Components/Search/Search-Feature';
import { ruleManagementApi } from "../../../../services/ruleManagementApi";
import ArrowDropDownIcon from '@mui/icons-material/ArrowDropDown';


const CONTROL_H = 36;
const itemsPerPage = 5;


const TableRuleDetails = () => {
  const navigate = useNavigate();
  const { table } = useParams();
   
  const location = useLocation();
  const tableName = location.state?.tableName || table;
  const catalogName = location.state?.catalogName || "integration";
  const schemaName = location.state?.schemaName || "marketing_lakehouse_silver";
 
const catalogSchemaLabel = (
  typeof schemaName === "string" && schemaName.startsWith(`${catalogName}.`)
) ? schemaName : `${catalogName}.${schemaName}`;


  const [searchTerm, setSearchTerm] = useState("");
  const [activeTab, setActiveTab] = useState(0);
  const [openFilter, setOpenFilter] = useState(null);


  // Filter search states
  const [conditionTypeSearch, setConditionTypeSearch] = useState('');
  const [severitySearch, setSeveritySearch] = useState('');


  const [rules, setRules] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);


  const handleModify = () => {};




  const handleDelete = (id) => setRules(rules.filter((rule) => rule.id !== id));


  const [selectedCategories, setSelectedCategories] = useState([]);
  const [selectedTypes, setSelectedTypes] = useState([]);
  const [selectedSeverity, setSelectedSeverity] = useState([]);
  const [selectedEnforcementAction, setSelectedEnforcementAction] = useState([]);
  const [selectedOwner, setSelectedOwner] = useState([]);
  const [dynamicFilters, setDynamicFilters] = useState({});
  const [filtersLoading, setFiltersLoading] = useState(true);


  // Filter options with search and sorting
  const getFilteredAndSortedOptions = (options, selected, searchTerm) => {
    const filtered = options
      .filter(option => option != null && option !== '')
      .filter(option =>
        option.toLowerCase().includes(searchTerm.toLowerCase())
      );
   
    return filtered.sort((a, b) => {
      const aSelected = selected.includes(a);
      const bSelected = selected.includes(b);
     
      if (aSelected && !bSelected) return -1;
      if (!aSelected && bSelected) return 1;
      return a.localeCompare(b);
    });
  };


  // Display text for filter buttons
  const getDisplayText = (label, selected) => {
    if (selected.length === 0) return label;
    if (selected.length <= 2) {
      return selected.join(', ');
    }
    return `${selected.length} selected`;
  };


  // Filter component
  const FilterDropdown = ({ label, options, selected, onToggle, searchValue, onSearchChange }) => {
    const isOpen = openFilter === label;
    const dropdownRef = useRef(null);

    useEffect(() => {
      const handleClickOutside = (event) => {
        if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
          handleClose();
        }
      };

      if (isOpen) {
        document.addEventListener('mousedown', handleClickOutside);
      }

      return () => {
        document.removeEventListener('mousedown', handleClickOutside);
      };
    }, [isOpen]);


 


    const handleClick = (event) => {
      setOpenFilter(openFilter === label ? null : label);
    };


    const handleClose = () => {
      setOpenFilter(null);
      onSearchChange('');
    };


    const handleSearchChange = (e) => {
      e.stopPropagation();
      onSearchChange(e.target.value);
    };


    const handleToggle = (option) => {
      onToggle(option);
    };


    const filteredOptions = getFilteredAndSortedOptions(options, selected, searchValue);


    return (
      <Box ref={dropdownRef} sx={{ position: 'relative' }}>
        <Button
          className="filter-btn"
          onClick={handleClick}
          sx={{
            textTransform: 'none',
            fontWeight: 400,
            justifyContent: 'space-between',
            padding: '6px 12px',
            borderRadius: '4px',
            border: '1px solid rgba(0, 0, 0, 0.23)',
            backgroundColor: selected.length > 0 ? '#e3f2fd' : '#fff',
            color: selected.length > 0 ? '#1976d2' : '#333',
            '&:hover': {
              backgroundColor: selected.length > 0 ? '#bbdefb' : '#f5f5f5',
            },
            minWidth: '120px',
            maxWidth: '200px',
            overflow: 'hidden',
            whiteSpace: 'nowrap',
            textOverflow: 'ellipsis',
            height: 35,
          }}
        >
          <span style={{ overflow: 'hidden', textOverflow: 'ellipsis' }}>
            {getDisplayText(label, selected)}
          </span>
          {/* <span style={{ marginLeft: '4px' }}>▼</span> */}
          <ArrowDropDownIcon sx={{ fontSize: 18, ml: 0.5 }} />
        </Button>


        {isOpen && (
          <Box
            sx={{
              position: 'absolute',
              top: '100%',
              left: 0,
              zIndex: 1000,
              mt: 0.5,
              width: '120px',
              maxHeight: '280px',
              backgroundColor: 'white',
              border: '1px solid #d0d0d0',
              borderRadius: '6px',
              boxShadow: '0px 4px 16px rgba(0, 0, 0, 0.08)',
              p: 1,
            }}
          >
            {/* Search Input */}
            <TextField
              autoFocus
              size="small"
              placeholder="Search..."
              value={searchValue}
              onChange={handleSearchChange}
              onKeyDown={(e) => e.stopPropagation()}
              sx={{
                width: '100%',
                mb: 1,
                '& .MuiOutlinedInput-root': {
                  height: '28px',
                  fontSize: '0.75rem',
                  borderRadius: '4px',
                  backgroundColor: '#f8f9fa',
                  border: '1px solid #e9ecef',
                  '&:hover': {
                    borderColor: '#ced4da',
                  },
                  '&.Mui-focused': {
                    borderColor: '#1976d2',
                    backgroundColor: 'white',
                  },
                },
                '& .MuiOutlinedInput-input': {
                  padding: '4px 8px',
                }
              }}
              InputProps={{
                startAdornment: (
                  <InputAdornment position="start">
                    <SearchIcon sx={{ fontSize: '14px', color: '#6c757d' }} />
                  </InputAdornment>
                ),
              }}
            />


            {/* Options List */}
            <Box sx={{ maxHeight: 180, overflowY: 'auto' }}>
              {filteredOptions.length === 0 ? (
                <Typography variant="body2" sx={{ p: 1, color: '#6c757d', fontSize: '0.75rem', textAlign: 'center' }}>
                  No options
                </Typography>
              ) : (
                filteredOptions.map((option) => (
                  <FormControlLabel
                    key={option}
                    control={
                      <Checkbox
                        checked={selected.includes(option)}
                        onChange={() => handleToggle(option)}
                        size="small"
                        sx={{
                          padding: '4px',
                          '& .MuiSvgIcon-root': {
                            fontSize: '16px',
                            color: selected.includes(option) ? '#1976d2' : '#6c757d'
                          }
                        }}
                      />
                    }
                    label={option}
                    sx={{
                      display: 'flex',
                      width: '100%',
                      margin: 0,
                      padding: '4px 6px',
                      borderRadius: '4px',
                      cursor: 'pointer',
                      transition: 'all 0.15s ease',
                      '&:hover': {
                        backgroundColor: '#f8f9fa',
                      },
                      '& .MuiFormControlLabel-label': {
                        fontSize: '0.8rem',
                        overflow: 'hidden',
                        textOverflow: 'ellipsis',
                        whiteSpace: 'nowrap',
                        lineHeight: 1.3,
                        color: selected.includes(option) ? '#1976d2' : '#495057',
                        fontWeight: selected.includes(option) ? 500 : 400,
                      },
                      backgroundColor: selected.includes(option)
                        ? 'rgba(25, 118, 210, 0.04)'
                        : 'transparent',
                      borderLeft: selected.includes(option) ? '2px solid #1976d2' : '2px solid transparent',
                    }}
                  />
                ))
              )}
            </Box>


            {/* Clear All Button */}
            {selected.length > 0 && (
              <Box sx={{ mt: 1, pt: 1, borderTop: '1px solid #e9ecef' }}>
                <Button
                  size="small"
                  onClick={() => {
                    selected.forEach(option => handleToggle(option));
                  }}
                  sx={{
                    textTransform: 'none',
                    fontSize: '0.7rem',
                    minHeight: '24px',
                    padding: '2px 8px',
                    borderRadius: '4px',
                    color: '#6c757d',
                    '&:hover': {
                      backgroundColor: '#f8f9fa',
                      color: '#495057',
                    },
                  }}
                >
                  Clear All
                </Button>
              </Box>
            )}
          </Box>
        )}
      </Box>
    );
  };
 
// Initial load - fetch filters first
// Load filters and initial rules in parallel
useEffect(() => {
  if (!table) return;
 
  const loadAllData = async () => {
    try {
      setFiltersLoading(true);
      setLoading(true);
     
      const params = { status: activeTab === 0 ? 'active' : 'inactive' };
     
      // Load both in parallel
      const [filters, rulesData] = await Promise.all([
        ruleManagementApi.getTableFilters(table),
        ruleManagementApi.getRuleStatus(table, params)
      ]);
     
      // Clean filters
      const cleanFilters = {
        condition_category: [...new Set((filters.condition_category || [])
          .filter(item => item !== null)
          .map(item => item.trim())
          .filter(item => item.length > 0))],
        condition_type: [...new Set((filters.condition_type || [])
          .filter(item => item !== null)
          .map(item => item.trim())
          .filter(item => item.length > 0))],
        severity: [...new Set((filters.severity || [])
          .filter(item => item !== null)
          .map(item => item.trim())
          .filter(item => item.length > 0))],
        status: [...new Set((filters.status || [])
          .filter(item => item !== null)
          .map(item => item.trim())
          .filter(item => item.length > 0))],
        enforcement_action: ['BLOCK_AND_AUDIT', 'AUDIT_ONLY']
      };


      // Transform rules
      const transformedRules = rulesData.map(rule => ({
        Rule_id: String(rule.rule_id).trim(),
        column: (rule.column_name || '').trim(),
        conditionCategory: rule.condition_category ? rule.condition_category.trim() : undefined,
        conditionType: (rule.condition_type || '').trim(),                  
        description: (rule.rule_description || '').trim(),                  
        severity: (rule.severity || 'Warning').trim(),                      
        status: (String(rule.computed_status).toLowerCase() === 'active') ? 'Active' : 'Inactive',
        violationThreshold: String(rule.violation_threshold ?? '').trim(),    
        approvalStatus: 'Approved',
        createdBy: 'System',
        createdDate: rule.created_at ? new Date(rule.created_at).toLocaleDateString() : undefined,
        updatedDate: rule.updated_at ? new Date(rule.updated_at).toLocaleDateString() : undefined,
        conditionCriteria: rule.condition_criteria ? rule.condition_criteria.trim() : undefined,
        enforcementAction: rule.enforcement_action || "BLOCK_AND_AUDIT",
        emailAlertEnabled: rule.email_alert_enabled !== false,
        alertGroupId: rule.alert_group_id || "",
      }));


      setDynamicFilters(cleanFilters);
      setRules(transformedRules);
     
    } catch (err) {
      console.error('Failed to load data:', err);
      setError('Failed to load data');
    } finally {
      setFiltersLoading(false);
      setLoading(false);
    }
  };


  loadAllData();
}, [table, activeTab]);


// Handle filter changes only

 
  const conditionCategories = dynamicFilters.condition_category?.length > 0
    ? dynamicFilters.condition_category
    : [
      "Completeness Rules",
      "Format & Pattern Validation",
      "Range & Threshold Rules",
      "Uniqueness & Duplicate Checks",
      "Business Logic Rules",
      "Consistency & Standardization Checks",
      "Anomaly Detection",
      "Time-based Validations",
      "Trend Analysis",
      "KPI Statistics"
    ];


  const conditionTypes = dynamicFilters.condition_type?.length > 0
    ? dynamicFilters.condition_type
    : [
      "NOT_NULL", "BLANK", "MUST_HAVE_VALUE", "NOT_NULL_LENGTH_CHECK",
      "REGEX_MATCH", "LENGTH_CHECK", "FORMAT_CHECK", "RANGE_CHECK",
      "VALUE_THRESHOLD", "DATE_RANGE", "UNIQUE", "DUPLICATE",
      "CUSTOM_RULE", "CASE_STANDARDIZATION", "MAPPING_CHECK",
      "OUTLIER_DETECTION", "TIME_STAMP_CHECK", "ROW_COUNT_TREND", "KPI_CHECK"
    ];


  const severityTypes = dynamicFilters.severity?.length > 0
    ? dynamicFilters.severity
    : ["Warning", "Critical"];

  const enforcementActionTypes = dynamicFilters.enforcement_action?.length > 0
    ? dynamicFilters.enforcement_action
    : ["BLOCK_AND_AUDIT", "AUDIT_ONLY"];


 
  const approvalStatus = dynamicFilters.status?.length > 0
    ? dynamicFilters.status.map(status => {
        if (status === 'APPROVED') return 'Approved';
        if (status === 'PENDING' || status === 'pending') return 'Yet to Approve';
        if (status === 'REJECTED') return 'Rejected';
        return status;
      })
    : ["Approved", "Yet to Approve", "Rejected"];


  const toggleCategory  = (o) => setSelectedCategories(p => p.includes(o) ? p.filter(x=>x!==o) : [...p,o]);
  const toggleType      = (o) => setSelectedTypes(p => p.includes(o) ? p.filter(x=>x!==o) : [...p,o]);
  const toggleSeverity  = (o) => setSelectedSeverity(p => p.includes(o) ? p.filter(x=>x!==o) : [...p,o]);
  const toggleEnforcementAction = (o) => setSelectedEnforcementAction(p => p.includes(o) ? p.filter(x=>x!==o) : [...p,o]);
  const toggleOwner     = (o) => setSelectedOwner(p => p.includes(o) ? p.filter(x=>x!==o) : [...p,o]);


  const clearAllFilters = () => {
    setSelectedTypes([]);
    setSelectedOwner([]);
    setSelectedSeverity([]);
    setSelectedEnforcementAction([]);
  };


  const filteredRules = useMemo(() => {
    return rules
      .filter((rule) => rule.status === (activeTab === 0 ? "Active" : "Inactive"))
      .filter((rule) => {
        // Search filter
        if (searchTerm) {
          const searchMatch = [rule.column, rule.description, rule.conditionCategory, rule.conditionType]
            .filter(Boolean)
            .some((field) => field.toLowerCase().includes(searchTerm.toLowerCase()));
          if (!searchMatch) return false;
        }
        
        // Condition Type filter
        if (selectedTypes.length > 0 && !selectedTypes.includes(rule.conditionType)) {
          return false;
        }
        
        // Severity filter
        if (selectedSeverity.length > 0 && !selectedSeverity.includes(rule.severity)) {
          return false;
        }

        // Enforcement action filter
        if (selectedEnforcementAction.length > 0 &&
            !selectedEnforcementAction.includes(rule.enforcementAction || "BLOCK_AND_AUDIT")) {
          return false;
        }

        return true;
      });
  }, [rules, activeTab, searchTerm, selectedTypes, selectedSeverity, selectedEnforcementAction]);


  const [currentPage, setCurrentPage] = useState(1);

  // Calculate pagination based on filtered results
  const totalPages = Math.max(1, Math.ceil(filteredRules.length / itemsPerPage));
  const startIndex = (currentPage - 1) * itemsPerPage;
  const pagedRules = filteredRules.slice(startIndex, startIndex + itemsPerPage);

  // Reset to first page if current page exceeds total pages
  useEffect(() => {
    if (currentPage > totalPages) setCurrentPage(totalPages);
  }, [currentPage, totalPages]);

  // Reset to first page when filters change
  useEffect(() => {
    setCurrentPage(1);
  }, [searchTerm, selectedTypes, selectedSeverity, selectedEnforcementAction]);


  return (
    <>
      <Box sx={{ mt: 2 }}>
        <Container maxWidth="lg" sx={{ overflowX: 'hidden' }}>
          <Breadcrumbs mb={2} aria-label="breadcrumb">
            <Link underline="hover" color="inherit" sx={{ "&:hover": { cursor: 'pointer' } }} onClick={() => navigate('/rule-management')}>
              <Typography>Rules</Typography>
            </Link>
            <Typography sx={{ "&:hover": { cursor: 'not-allowed' } }}>Table</Typography>
            <Typography sx={{ color: 'text.primary' }}>{tableName}</Typography>
          </Breadcrumbs>


          <Box display="flex" alignItems="center" gap={0.5}>
            <TableChartIcon sx={{ color: '#1e3a8a70' }} />
            <Typography variant="h6">{tableName}</Typography>
          </Box>


          <Typography variant="subtitle2" color="text.secondary" sx={{ mb: 1 }}>
            {catalogSchemaLabel}
          </Typography>


          <Tabs
            value={activeTab}
            onChange={(e, v) => setActiveTab(v)}
            sx={{
              mb: 1,
              minHeight: 28,
              '& .MuiTab-root': { minHeight: 28, px: 1.5, py: 0.25, textTransform: 'none' },
              '& .MuiTab-root:not(.Mui-selected):hover': { color: '#000' },
              '& .MuiTabs-indicator': { height: 2 },
            }}
          >
            <Tab label="Active" />
            <Tab label="Inactive" />
          </Tabs>


          <Divider sx={{ mb: 2 }} />


          <Box>
            <Grid container spacing={1.5}>
              <Grid size={{ xs: 12, md: 3 }}>
                {filtersLoading ? (
                  <Skeleton variant="rectangular" width="100%" height={33} sx={{ borderRadius: 1 }} />
                ) : (
                  <Search
                    placeholder="Search Rules"
                    searchTerm={searchTerm}
                    setSearchTerm={setSearchTerm}
                    width="100%"
                    inputSx={{ height: "33px" }}
                  />
                )}
              </Grid>
             
              <Grid size={{ xs: 12, md: 9 }}>
                {filtersLoading ? (
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, py: 1 }}>
                    <Skeleton variant="rectangular" width={120} height={35} sx={{ borderRadius: 1 }} />
                    <Skeleton variant="rectangular" width={100} height={35} sx={{ borderRadius: 1 }} />
                    <Skeleton variant="rectangular" width={70} height={35} sx={{ borderRadius: 1 }} />
                  </Box>
                ) : (
                  <Box display="flex" alignItems="center" sx={{ gap: 2, flexWrap: 'nowrap' }}>
                    <Box sx={{ whiteSpace: 'nowrap' }}>
                      <FilterDropdown
                        label="Condition Type"
                        options={conditionTypes}
                        selected={selectedTypes}
                        onToggle={toggleType}
                        searchValue={conditionTypeSearch}
                        onSearchChange={setConditionTypeSearch}
                      />
                    </Box>


                    <Box sx={{ whiteSpace: 'nowrap' }}>
                      <FilterDropdown
                        label="Severity"
                        options={severityTypes}
                        selected={selectedSeverity}
                        onToggle={toggleSeverity}
                        searchValue={severitySearch}
                        onSearchChange={setSeveritySearch}
                      />
                    </Box>

                    <Box sx={{ whiteSpace: 'nowrap' }}>
                      <FilterDropdown
                        label="Enforcement Action"
                        options={enforcementActionTypes}
                        selected={selectedEnforcementAction}
                        onToggle={toggleEnforcementAction}
                        searchValue=""
                        onSearchChange={() => {}}
                      />
                    </Box>


                    <Button
                      sx={{
                        textTransform: 'none',
                        minWidth: '70px',
                        fontWeight: 400,
                        justifyContent: 'center',
                        padding: '6px 12px',
                        borderRadius: '4px',
                        height: 35,
                        border: '1px solid rgba(0, 0, 0, 0.23)',
                        backgroundColor: '#e0e0e0',
                        color: '#333',
                        '&:hover': { backgroundColor: '#616161', color: '#fff' },
                        '&.Mui-disabled': {
                          backgroundColor: '#f0f0f0',
                          color: '#9e9e9e',
                          border: '1px solid #e0e0e0',
                          cursor: 'not-allowed',
                        },
                      }}
                      onClick={clearAllFilters}
                      disabled={
                        selectedTypes.length === 0 &&
                        selectedSeverity.length === 0 &&
                        selectedEnforcementAction.length === 0
                      }
                    >
                      Reset
                    </Button>
                  </Box>
                )}
              </Grid>
            </Grid>
          </Box>
         
          <Box sx={{mt : 3}}>
            {loading ? (
              <Stack spacing={2} sx={{ py: 2 }}>
                {[...Array(4)].map((_, index) => (
                  <Box key={index} sx={{ p: 3, border: '1px solid #e0e0e0', borderRadius: 2 }}>
                    <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', mb: 2 }}>
                      <Box sx={{ flex: 1 }}>
                        <Skeleton variant="rectangular" width={120} height={24} sx={{ mb: 1, borderRadius: 1 }} />
                        <Skeleton variant="text" width="90%" height={20} sx={{ mb: 1 }} />
                        <Skeleton variant="text" width="70%" height={20} />
                      </Box>
                      <Box sx={{ display: 'flex', gap: 1 }}>
                        <Skeleton variant="circular" width={32} height={32} />
                        <Skeleton variant="circular" width={32} height={32} />
                      </Box>
                    </Box>
                    <Box sx={{ display: 'flex', gap: 1 }}>
                      <Skeleton variant="rectangular" width={80} height={24} sx={{ borderRadius: 12 }} />
                      <Skeleton variant="rectangular" width={70} height={24} sx={{ borderRadius: 12 }} />
                    </Box>
                  </Box>
                ))}
              </Stack>
            ) : error ? (
              <Typography color="error" sx={{ textAlign: 'center', py: 4 }}>
                {error}
              </Typography>
            ) : pagedRules.length === 0 ? (
              <Typography sx={{ textAlign: 'center', py: 4 }}>
                No rules found for the selected filters
              </Typography>
            ) : (
              pagedRules.map((rule) => (
                <DetailedRuleCard
                  key={rule.Rule_id}
                  rule={rule}
                  onModify={handleModify}
                  onDelete={handleDelete}
                  tableId={table}
                />
              ))
            )}
          </Box>


          <MuiPagination
            currentPage={currentPage}
            totalPages={totalPages}
            onPageChange={setCurrentPage}
          />
        </Container>
      </Box>
    </>
  );
};


export default TableRuleDetails;

