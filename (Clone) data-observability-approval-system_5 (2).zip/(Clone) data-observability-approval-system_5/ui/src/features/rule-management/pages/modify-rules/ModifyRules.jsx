import React from "react";
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  Box,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  OutlinedInput,
  Checkbox,
  ListItemText,
  TextField,
  Grid,
  CircularProgress
} from "@mui/material";
import DynamicConditionFields from "../../components/dynamic-condition-fields/DynamicConditionFields";
import { ruleManagementApi } from "../../../../services/ruleManagementApi";
import Snackbar from '@mui/material/Snackbar';
import MuiAlert from '@mui/material/Alert';




const Alert = React.forwardRef(function Alert(props, ref) {
  return <MuiAlert elevation={6} ref={ref} variant="filled" {...props} />;
});


const ModifyRules = ({ open, rule, allColumns, allColumnDataTypes = {}, onClose, onSave, columnsLoading })=> {
  const [editedRule, setEditedRule] = React.useState(rule || {});
  const [saving, setSaving] = React.useState(false);
  const [snackbarOpen, setSnackbarOpen] = React.useState(false);
  const [snackbarMessage, setSnackbarMessage] = React.useState('');
  const [snackbarSeverity, setSnackbarSeverity] = React.useState('success');


  React.useEffect(() => {
    if (rule) {
      setEditedRule({
        ...rule,
        rule_id: rule.rule_id || rule.Rule_id || rule.id, // handle naming mismatch
        columns: rule.column_name ? rule.column_name.split(", ") : [],
        // FIX: the backend returns this field as violation_threshold
        // (snake_case). Everywhere else in this component reads/writes
        // violationThreshold (camelCase), and the plain `...rule` spread
        // above never bridges the two — so without this line the Threshold
        // field opened blank for every rule, and saving without touching it
        // sent an empty string to the backend's unguarded float() call.
        violationThreshold: rule.violationThreshold ?? rule.violation_threshold ?? "",
    });
  }
}, [rule]);

  const handleChange = (field, value) => {
    setEditedRule({ ...editedRule, [field]: value });
  };

  const handleSnackbarClose = (event, reason) => {
        if (reason === 'clickaway') {
            return;
        }
        setSnackbarOpen(false);
    };

const handleSave = async () => {
  if (!editedRule || !editedRule.rule_id) { return; }

  // FIX: condition_criteria values are sent as their real JS types (numbers
  // stay numbers). A previous version of this function wrapped every
  // numeric criteria value in a "__NUMBER__<value>__" placeholder string
  // before sending, but nothing anywhere in the backend ever unwrapped it —
  // so it silently corrupted rule criteria (e.g. VALUE_THRESHOLD's actual
  // threshold number) into a literal string on every save.
  const criteriaToSave = JSON.parse(JSON.stringify(editedRule.conditionCriteria || {}));

  const payload = {
    column_name: (editedRule.columns || []).join(", "),
    rule_description: editedRule.description || "",
    severity: editedRule.severity,
    violation_threshold: editedRule.violationThreshold,
    condition_criteria: criteriaToSave,
  };

  setSaving(true);
  try {
    const response = await fetch(`${import.meta.env.VITE_API_URL}/api/rules/${editedRule.rule_id}/save_request`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    const result = await response.json();
    if (response.ok) {
      onSave();
      onClose();
    } else {
      console.error("Failed to save:", result.error);
    }
  } catch (error) {
    console.error("An error occurred during save:", error);
  } finally {
    setSaving(false);
  }
};

  return (


<Box p={1}>
<Dialog
  open={open}
  onClose={onClose}
  maxWidth="md"
  fullWidth
>
      <DialogTitle>Edit Rule - {editedRule.conditionType}</DialogTitle>
      <DialogContent dividers>
        <Box display="flex" flexDirection="column" gap={2}>
          {/* Columns */}


          <Box>


          <FormControl fullWidth>
            <InputLabel>Columns</InputLabel>
            <Select
              multiple
              value={editedRule.columns || []}
              onChange={(e) => handleChange("columns", e.target.value)}
              input={<OutlinedInput label="Columns" />}
              renderValue={(selected) => selected.join(", ")}
              disabled={columnsLoading}
            >
              {columnsLoading ? (
                <MenuItem disabled>Loading columns...</MenuItem>
              ) : (
                allColumns.map((col) => (
                  <MenuItem key={col} value={col}>
                    <Checkbox checked={editedRule.columns?.includes(col)} />
                    <ListItemText primary={col} />
                  </MenuItem>
                ))
              )}
            </Select>
          </FormControl>
         
          </Box>


          <Box>
          <textarea
            ref={(el) => {
              if (!el) return;
              el.style.height = "auto";
              el.style.height = `${Math.min(Math.max(el.scrollHeight, 96), 480)}px`;
            }}
            value={editedRule.description || ""}
            onChange={(e) => {
              handleChange("description", e.target.value);
              e.target.style.height = "auto";
              e.target.style.height = `${Math.min(Math.max(e.target.scrollHeight, 96), 480)}px`;
            }}
            placeholder="Enter Rule description"
            rows={4}
            style={{
              width: '100%',
              padding: '10px 14px',
              fontSize: '0.95rem',
              borderRadius: '4px',
              border: '1px solid rgba(0, 0, 0, 0.23)',
              backgroundColor: '#fff',
              fontFamily: 'Segeo-UI, Helvetica, Arial, sans-serif',
              boxSizing: 'border-box',
              transition: 'border-color 0.2s, box-shadow 0.2s',
              outline: 'none',
              resize: 'vertical',
              lineHeight: 1.4,
              overflow: 'hidden',
            }}
            onFocus={(e) => {
              e.target.style.border = '1px solid #1976d2';
              e.target.style.boxShadow = '0 0 0 1px #1976d2';
            }}
            onBlur={(e) => {
              e.target.style.border = '1px solid rgba(0, 0, 0, 0.23)';
              e.target.style.boxShadow = 'none';
            }}
          />
        </Box>


          {/* Condition Parameters (Dynamic Fields) */}
          <DynamicConditionFields
            category={editedRule.conditionCategory}
            type={editedRule.conditionType}
            columns={editedRule.columns}
            columnDataTypes={allColumnDataTypes}
            selectedColumns={editedRule.columns}
            onCriteriaChange={(updated) => handleChange("conditionCriteria", updated)}
          />


    <Grid container spacing={2} mt={1} justifyContent={"space-between"}>


        <Grid size={{ xs: 12, md: 6 }} justifyContent={"space-between"}>
            <Box>
          {/* Severity */}
          <FormControl sx={{width: 220}}>
            <InputLabel>Severity</InputLabel>
            <Select
              value={editedRule.severity || ""}
              onChange={(e) => handleChange("severity", e.target.value)}
              label="Severity"
            >
              <MenuItem value="Warning">Warning</MenuItem>
              <MenuItem value="Critical">Critical</MenuItem>
            </Select>
          </FormControl>
                         
            </Box>
        </Grid>


        <Grid size={{ xs: 12, md: 6 }} justifyContent={"space-between"}>
        <Box>
          {/* Threshold */}
          <TextField
            label="Violation Threshold (%)"
            type="number"
            value={editedRule.violationThreshold || ""}
            onChange={(e) => handleChange("violationThreshold", e.target.value)}
            sx={{width: 220}}
          />
          </Box>
          </Grid>
          </Grid>
          </Box>
      </DialogContent>
      <DialogActions>
        <Button onClick={onClose} color="inherit" disabled={saving}>
          Cancel
        </Button>
        <Button
          onClick={handleSave}
          variant="contained"
          color="primary"
          disabled={saving}
        >
          {saving ? <CircularProgress size={20} /> : 'Save'}
        </Button>
      </DialogActions>
    </Dialog>
    <Snackbar
      open={snackbarOpen}
      autoHideDuration={3000}
      onClose={() => setSnackbarOpen(false)}
      anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}
    >
      <Alert
        onClose={() => setSnackbarOpen(false)}
        severity={snackbarSeverity}
        sx={{ width: '100%' }}
      >
        {snackbarMessage}
      </Alert>
    </Snackbar>
    </Box>
   
  );
};


export default ModifyRules;

