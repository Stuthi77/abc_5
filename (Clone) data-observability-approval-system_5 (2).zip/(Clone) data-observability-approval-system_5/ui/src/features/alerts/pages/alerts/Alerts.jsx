import React, { useState, useMemo, useEffect, useRef } from "react";

import AlertCard from "../../components/AlertCard";
import MuiPagination from "../../../Shared/Components/Pagination/Pagination";
import Search from '../../../Shared/Components/Search/Search-Feature';

import ArrowDropDownIcon from '@mui/icons-material/ArrowDropDown';

import {
  Box,
  Button,
  Typography,
  Container,
  Skeleton,
  Stack,
  TextField,
  Checkbox,
  FormControlLabel,
  InputAdornment,
} from '@mui/material';
import SearchIcon from '@mui/icons-material/Search';


const normalize = (v) => (v ?? "").toString().trim().toLowerCase();


const inSelected = (selected, value) => {
  if (!selected || selected.length === 0) return true;
  const set = new Set(selected.map(normalize));
  return set.has(normalize(value));
};


const matchesDateRange = (modifiedDate, selectedRange) => {
  if (!selectedRange) return true;
  const d = new Date(modifiedDate);
  if (isNaN(d.getTime())) return true;


  const now = new Date();
  const startOfToday = new Date(now);
  startOfToday.setHours(0, 0, 0, 0);


  const daysAgo = (n) => {
    const t = new Date(now);
    t.setDate(t.getDate() - n);
    t.setHours(0, 0, 0, 0);
    return t;
  };


  switch (selectedRange) {
    case "Today": {
      const endOfToday = new Date(now);
      endOfToday.setHours(23, 59, 59, 999);
      return d >= startOfToday && d <= endOfToday;
    }
    case "Last 7 Days":
      return d >= daysAgo(7);
    case "Last 30 Days":
      return d >= daysAgo(30);
    case "Last 90 Days":
      return d >= daysAgo(90);
    default:
      return true;
  }
};


const CONTROL_H = 35;
const SEARCH_W = 284;


const Alerts = () => {
  const [searchTerm, setSearchTerm] = useState("");
  const [filters, setFilters] = useState({
    condition_type: [],
    table: [],
    owner: [],
    date_range: null,
  });
  const [openFilter, setOpenFilter] = useState(null);

  // Filter search states
  const [conditionTypeSearch, setConditionTypeSearch] = useState('');
  const [tableSearch, setTableSearch] = useState('');
  const [ownerSearch, setOwnerSearch] = useState('');
  const [dateRangeSearch, setDateRangeSearch] = useState('');


  const [selectedConditionType, setSelectedConditionType] = useState([]);
  const [selectedOwner, setSelectedOwner] = useState([]);
  const [selectedDateRange, setSelectedDateRange] = useState(null);
  const [selectedTables, setSelectedTables] = useState([]);

  const [tableOptions, setTableOptions] = useState([]);
  const [ownerOptions, setOwnerOptions] = useState([]);
  const [conditionTypesOptions, setConditionTypes] = useState([]);
  const [dateRangeOptions, setDateRange] = useState([]);

  const [alertsArray, setAlertsArray] = useState([]);
  const [loading, setLoading] = useState(false);
  const [filtersLoading, setFiltersLoading] = useState(true);
  const [isFilterUpdating, setIsFilterUpdating] = useState(false);
  const [filtersLoadedCount, setFiltersLoadedCount] = useState(0);

  // Get userData from sessionStorage
  const userData = JSON.parse(sessionStorage.getItem("userData")) || {};
  const group_id = userData?.selectedGroupId || "";

  // Filter options with search and sorting
  const getFilteredAndSortedOptions = (options=[], selected=[], searchTerm='') => {
    if (options) {
      const filtered = options
        .filter(option => option != null && option !== '') // Remove null/undefined/empty values
        .filter(option =>
          option.toLowerCase().includes(searchTerm.toLowerCase())
        );


      return filtered.sort((a, b) => {
        const aSelected = selected.includes(a);
        const bSelected = selected.includes(b);


        if (aSelected && !bSelected) return -1;
        if (!aSelected && bSelected) return 1;
        return a.localeCompare(b);
      });
    }
  };


  // Display text for filter buttons
  const getDisplayText = (label, selected) => {
    if (Array.isArray(selected)) {
      if (selected.length === 0) return label;
      if (selected.length <= 2) {
        return selected.join(', ');
      }
      return `${selected.length} selected`;
    } else {
      return selected || label;
    }
  };
 
  // Filter component
  const FilterDropdown = ({ label, options, selected, onToggle, searchValue, onSearchChange, isFilterUpdating, isDateRange = false }) => {
    const isOpen = openFilter === label;
    
    const dropdownRef = useRef(null);

    // Add click outside handler
    useEffect(() => {
      const handleClickOutside = (event) => {
        if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
          handleClose();
        }
      };

      if (isOpen) {
        document.addEventListener('mousedown', handleClickOutside);
      }

      return () => {
        document.removeEventListener('mousedown', handleClickOutside);
      };
    }, [isOpen]);

    <Box sx={{ position: 'relative' }} ref={dropdownRef}></Box>
    
    const handleClick = (event) => {
      setOpenFilter(openFilter === label ? null : label);
    };


    const handleClose = () => {
      setOpenFilter(null);
      onSearchChange('');
    };


    const handleSearchChange = (e) => {
      e.stopPropagation();
      onSearchChange(e.target.value);
    };


    const handleToggle = (option) => {
      onToggle(option);
    };

    useEffect(() => {
    const handleClickOutside = (event) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        handleClose();
        }
      };

      if (isOpen) {
        document.addEventListener('mousedown', handleClickOutside);
      }

      return () => {
        document.removeEventListener('mousedown', handleClickOutside);
      };
    }, [isOpen]);

    const filteredOptions = getFilteredAndSortedOptions(options, Array.isArray(selected) ? selected : [], searchValue);


    return (
      <Box sx={{ position: 'relative'}} ref={dropdownRef}> 
        <Button
          className="filter-btn"
          onClick={handleClick}
          disabled={isFilterUpdating}
          sx={{
            textTransform: 'none',
            fontWeight: 400,
            justifyContent: 'space-between',
            padding: '6px 12px',
            borderRadius: '4px',
            border: '1px solid rgba(0, 0, 0, 0.23)',
            backgroundColor: (Array.isArray(selected) ? selected.length > 0 : selected) ? '#e3f2fd' : '#fff',
            color: (Array.isArray(selected) ? selected.length > 0 : selected) ? '#1976d2' : '#333',
            opacity: isFilterUpdating ? 0.7 : 1,
            '&:hover': {
              backgroundColor: (Array.isArray(selected) ? selected.length > 0 : selected) ? '#bbdefb' : '#f5f5f5',
            },
            minWidth: '150px',
            maxWidth: '200px',
            overflow: 'hidden',
            whiteSpace: 'nowrap',
            textOverflow: 'ellipsis',
          }}
        >
          <span style={{ overflow: 'hidden', textOverflow: 'ellipsis' }}>
            {getDisplayText(label, selected)}
          </span>

          <ArrowDropDownIcon sx={{ fontSize: 18, ml: 0.5 }} />

        </Button>

        {isOpen && (
          <Box
            sx={{
              position: 'absolute',
              top: '100%',
              left: 0,
              zIndex: 1000,
              mt: 0.5,
              width: '150px',
              maxHeight: '280px',
              backgroundColor: 'white',
              border: '1px solid #d0d0d0',
              borderRadius: '6px',
              boxShadow: '0px 4px 16px rgba(0, 0, 0, 0.08)',
              p: 1,
            }}
          >
            {/* Search Input */}
            <TextField
              autoFocus
              size="small"
              placeholder="Search..."
              value={searchValue}
              onChange={handleSearchChange}
              onKeyDown={(e) => e.stopPropagation()}
              sx={{
                width: '100%',
                mb: 1,
                '& .MuiOutlinedInput-root': {
                  height: '28px',
                  fontSize: '0.75rem',
                  borderRadius: '4px',
                  backgroundColor: '#f8f9fa',
                  border: '1px solid #e9ecef',
                  '&:hover': {
                    borderColor: '#ced4da',
                  },
                  '&.Mui-focused': {
                    borderColor: '#1976d2',
                    backgroundColor: 'white',
                  },
                },
                '& .MuiOutlinedInput-input': {
                  padding: '4px 8px',
                }
              }}
              InputProps={{
                startAdornment: (
                  <InputAdornment position="start">
                    <SearchIcon sx={{ fontSize: '14px', color: '#6c757d' }} />
                  </InputAdornment>
                ),
              }}
            />


            {/* Options List */}
            <Box sx={{ maxHeight: 180, overflowY: 'auto' }}>
              {options.length === 0 ? (
                <Typography variant="body2" sx={{ p: 1, color: '#6c757d', fontSize: '0.75rem', textAlign: 'center' }}>
                  No Options
                </Typography>
              ) : (
                options.map((option) => (
                  <FormControlLabel
                    key={option}
                    control={
                      isDateRange ? (
                        <Checkbox
                          checked={selected === option}
                          onChange={() => handleToggle(option)}
                          size="small"
                          sx={{
                            padding: '4px',
                            '& .MuiSvgIcon-root': {
                              fontSize: '16px',
                              color: selected === option ? '#1976d2' : '#6c757d'
                            }
                          }}
                        />
                      ) : (
                        <Checkbox
                          checked={selected.includes(option)}
                          onChange={() => handleToggle(option)}
                          size="small"
                          sx={{
                            padding: '4px',
                            '& .MuiSvgIcon-root': {
                              fontSize: '16px',
                              color: selected.includes(option) ? '#1976d2' : '#6c757d'
                            }
                          }}
                        />
                      )
                    }
                    label={option}
                    sx={{
                      display: 'flex',
                      width: '100%',
                      margin: 0,
                      padding: '4px 6px',
                      borderRadius: '4px',
                      cursor: 'pointer',
                      transition: 'all 0.15s ease',
                      '&:hover': {
                        backgroundColor: '#f8f9fa',
                      },
                      '& .MuiFormControlLabel-label': {
                        fontSize: '0.8rem',
                        overflow: 'hidden',
                        textOverflow: 'ellipsis',
                        whiteSpace: 'nowrap',
                        lineHeight: 1.3,
                        color: (isDateRange ? selected === option : selected.includes(option)) ? '#1976d2' : '#495057',
                        fontWeight: (isDateRange ? selected === option : selected.includes(option)) ? 500 : 400,
                      },
                      backgroundColor: (isDateRange ? selected === option : selected.includes(option))
                        ? 'rgba(25, 118, 210, 0.04)'
                        : 'transparent',
                      borderLeft: (isDateRange ? selected === option : selected.includes(option)) ? '2px solid #1976d2' : '2px solid transparent',
                    }}
                  />
                ))
              )}
            </Box>


            {/* Clear All Button */}
            {(Array.isArray(selected) ? selected.length > 0 : selected) && (
              <Box sx={{ mt: 1, pt: 1, borderTop: '1px solid #e9ecef' }}>
                <Button
                  size="small"
                  onClick={() => {
                    if (isDateRange) {
                      handleToggle(null);
                    } else {
                      selected.forEach(option => handleToggle(option));
                    }
                  }}
                  sx={{
                    textTransform: 'none',
                    fontSize: '0.7rem',
                    minHeight: '24px',
                    padding: '2px 8px',
                    borderRadius: '4px',
                    color: '#6c757d',
                    '&:hover': {
                      backgroundColor: '#f8f9fa',
                      color: '#495057',
                    },
                  }}
                >
                  Clear All
                </Button>
              </Box>
            )}
          </Box>
        )}
      </Box>
    );
  };

// Tables
useEffect(() => {
  if (!group_id) return;
  if (selectedTables.length > 0 && selectedConditionType.length > 0) return;

  const fetchTables = async () => {
    // Only show skeleton loading on the very first load
    if (filtersLoading) {
      // Keep it as is for initial load
    } else {
      setIsFilterUpdating(true);
    }
    
    try {
      const params = new URLSearchParams({ group_id });
      if (selectedConditionType.length > 0) {
        selectedConditionType.forEach(ct => params.append("condition_type", ct));
      }
      if (selectedOwner.length > 0) {
        selectedOwner.forEach(o => params.append("owner", o));
      }
      if (selectedDateRange) {
        params.append("date_range", selectedDateRange);
      }

      const res = await fetch(`${import.meta.env.VITE_API_URL}/api/alerts/filters?${params.toString()}`);
      const data = await res.json();
      setTableOptions(data.table || []);
    } catch (e) {
      console.error("Failed to fetch tables", e);
      setTableOptions([]);
    } finally {
      setIsFilterUpdating(false);
      setFiltersLoadedCount(prev => prev + 1);
    }
  };


  fetchTables();
}, [group_id,selectedConditionType,selectedOwner,selectedDateRange]);


// Owners
useEffect(() => {
  if (!group_id ) return;


  const fetchOwners = async () => {
    // Only show skeleton loading on the very first load
    if (filtersLoading) {
      // Keep it as is for initial load
    } else {
      setIsFilterUpdating(true);
    }
    
    try {
      const params = new URLSearchParams({ group_id });
      if (selectedTables.length >0){
        selectedTables.forEach(t => params.append("table", t));
      }
      if (selectedConditionType.length > 0) selectedConditionType.forEach(ct => params.append("condition_type", ct));
      if (selectedDateRange) {
        params.append("date_range", selectedDateRange);
      }

      const res = await fetch(`${import.meta.env.VITE_API_URL}/api/alerts/filters?${params.toString()}`);
      const data = await res.json();
      setOwnerOptions(data.owner || []);
    } catch (e) {
      console.error("Failed to fetch owners", e);
      setOwnerOptions([]);
    } finally {
      setIsFilterUpdating(false);
      setFiltersLoadedCount(prev => prev + 1);
    }
  };


  fetchOwners();
}, [group_id, selectedTables,selectedConditionType,selectedDateRange]);


// Condition Types
useEffect(() => {
  if (!group_id) return;


  const fetchConditionTypes = async () => {
    // Only show skeleton loading on the very first load
    if (filtersLoading) {
      // Keep it as is for initial load
    } else {
      setIsFilterUpdating(true);
    }
    
    try {
      const params = new URLSearchParams({ group_id });
      if (selectedTables.length > 0) {
        selectedTables.forEach(t => params.append("table", t));
      }


      // Owners (only if selected)
      if (selectedOwner.length > 0) {
        selectedOwner.forEach(o => params.append("owner", o));
      }


      // Condition Types (only if selected)
      if (selectedConditionType.length > 0) {
        selectedConditionType.forEach(ct => params.append("condition_type", ct));
      }
      if (selectedDateRange) {
        params.append("date_range", selectedDateRange);
      }
      const res = await fetch(`${import.meta.env.VITE_API_URL}/api/alerts/filters?${params.toString()}`);
      const data = await res.json();
      setConditionTypes(data.condition_type || []);
    } catch (e) {
      console.error("Failed to fetch condition types", e);
      setConditionTypes([]);
    } finally {
      setIsFilterUpdating(false);
      setFiltersLoadedCount(prev => prev + 1);
    }
  };


  fetchConditionTypes();
}, [group_id, selectedTables, selectedOwner,selectedDateRange]);


// Date Range
useEffect(() => {
  if (!group_id) return;


  const fetchDateRange = async () => {
    // Only show skeleton loading on the very first load
    if (filtersLoading) {
      // Keep it as is for initial load
    } else {
      setIsFilterUpdating(true);
    }
    
    try {
      const params = new URLSearchParams({ group_id });
      selectedTables.forEach(t => params.append("table", t));
      selectedOwner.forEach(o => params.append("owner", o));
      selectedConditionType.forEach(ct => params.append("condition_type", ct));
      const res = await fetch(`${import.meta.env.VITE_API_URL}/api/alerts/filters?${params.toString()}`);
      const data = await res.json();
      setDateRange(data.date_range || []);
    } catch (e) {
      console.error("Failed to fetch date ranges", e);
      setDateRange([]);
    } finally {
      setIsFilterUpdating(false);
      setFiltersLoadedCount(prev => prev + 1);
    }
  };


  fetchDateRange();
}, [group_id]);

// Hide skeleton when all 4 filters have loaded
useEffect(() => {
  if (filtersLoadedCount >= 4) {
    setFiltersLoading(false);
  }
}, [filtersLoadedCount]);

  useEffect(() => {
    setFilters({
      table: selectedTables,
      condition_type: selectedConditionType,
      owner: selectedOwner,
      date_range: selectedDateRange,
    });
  }, [selectedTables, selectedConditionType, selectedOwner, selectedDateRange]);


  const toggleOwner = (o) => setSelectedOwner(p => p.includes(o) ? p.filter(x => x !== o) : [...p, o]);
  const toggleDateRange = (o) => setSelectedDateRange(prev => prev === o ? null : o);
  const toggleTable = (o) => setSelectedTables(p => p.includes(o) ? p.filter(x => x !== o) : [...p, o]);
  const toggleType = (o) => setSelectedConditionType(p => p.includes(o) ? p.filter(x => x !== o) : [...p, o]);


  const clearAllFilters = () => {
    setSelectedConditionType([]); setSelectedTables([]); setSelectedOwner([]); setSelectedDateRange(null);
  };


  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 5;
  // Get userData from sessionStorage




  useEffect(() => {
  const fetchAlerts = async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams();
      selectedTables.forEach(table => params.append("table", table));
      selectedOwner.forEach(owner => params.append("owner", owner));
      selectedConditionType.forEach(type => params.append("condition_type", type));
      if (selectedDateRange) params.append("dateRange", selectedDateRange);


      if (searchTerm) params.append("search", searchTerm);
      if (group_id) params.append("group_id", group_id);


      console.log("Query Params:", params.toString());


      const response = await fetch(`${import.meta.env.VITE_API_URL}/api/alerts?${params.toString()}`);
      const data = await response.json();


      const mappedData = data.map((item) => ({
        ruleId: item.rule_id,
        tableName: item.table_name,
        catalog: item.catalog,
        schema: item.schema,
        owner: item.owner || "test-user",
        modifiedDate: item.modified_date,
        severity: item.severity,
        columns: item.columns,
        effectiveDateFrom: item.effective_date_from,
        conditionType: item.condition_type,
        updatedBy: item.updated_by
      }));


      setAlertsArray(mappedData);
    } catch (error) {
      console.error("Failed to fetch alerts:", error);
      setAlertsArray([]);
    } finally {
      setLoading(false);
    }
  };


  fetchAlerts();
}, [
  selectedTables,
  selectedOwner,
  selectedConditionType,
  selectedDateRange,
  searchTerm,
  group_id, // ✅ added
]);






  const filteredAlerts = useMemo(() => {
    const s = normalize(searchTerm);
    return alertsArray.filter((a) => {
      const tn = normalize(a.tableName);
      const matchesSearch = !s || tn.includes(s);
      const matchesTable = inSelected(filters.table, a.tableName);
      const matchesDate = matchesDateRange(a.effective_date_from, filters.date_range);
      return matchesSearch && matchesTable && matchesDate;
    });
  }, [alertsArray, searchTerm, filters]);


  const totalPages = Math.max(1, Math.ceil(filteredAlerts.length / itemsPerPage));
  const startIndex = (currentPage - 1) * itemsPerPage;
  const pagedItems = filteredAlerts.slice(startIndex, startIndex + itemsPerPage);


  useEffect(() => {
    if (currentPage > totalPages) setCurrentPage(totalPages);
  }, [currentPage, totalPages]);


  useEffect(() => {
    setCurrentPage(1);
  }, [searchTerm, filters]);




  return (
    <Container maxWidth="lg" sx={{ py: 2 }}>
      <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
        <Typography variant='h6' mb={1}>Alerts</Typography>
      </Box>


      {/* Filters Row */}
      {filtersLoading ? (
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 2, flexWrap: 'nowrap', width: '100%' }}>
          <Skeleton variant="rectangular" width={SEARCH_W} height={CONTROL_H} sx={{ borderRadius: 1 }} />
          <Skeleton variant="rectangular" width={150} height={CONTROL_H} sx={{ borderRadius: 1 }} />
          <Skeleton variant="rectangular" width={150} height={CONTROL_H} sx={{ borderRadius: 1 }} />
          <Skeleton variant="rectangular" width={150} height={CONTROL_H} sx={{ borderRadius: 1 }} />
          <Skeleton variant="rectangular" width={150} height={CONTROL_H} sx={{ borderRadius: 1 }} />
          <Skeleton variant="rectangular" width={70} height={CONTROL_H} sx={{ borderRadius: 1 }} />
        </Box>
      ) : (
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 2, flexWrap: 'nowrap', width: '100%' }}>
       
        <Search
          placeholder="Search Alerts"
          searchTerm={searchTerm}
          setSearchTerm={setSearchTerm}
          width="300px"
        />


        <FilterDropdown
          label="Condition Type"
          options={conditionTypesOptions}
          selected={selectedConditionType}
          onToggle={toggleType}
          searchValue={conditionTypeSearch}
          onSearchChange={setConditionTypeSearch}
          isFilterUpdating={isFilterUpdating}
        />


        <FilterDropdown
          label="Table"
          options={tableOptions}
          selected={selectedTables}
          onToggle={toggleTable}
          searchValue={tableSearch}
          onSearchChange={setTableSearch}
          isFilterUpdating={isFilterUpdating}
        />


        <FilterDropdown
          label="Owner"
          options={ownerOptions}
          selected={selectedOwner}
          onToggle={toggleOwner}
          searchValue={ownerSearch}
          onSearchChange={setOwnerSearch}
          isFilterUpdating={isFilterUpdating}
        />


        <FilterDropdown
          label="Date Range"
          options={dateRangeOptions}
          selected={selectedDateRange}
          onToggle={toggleDateRange}
          searchValue={dateRangeSearch}
          onSearchChange={setDateRangeSearch}
          isFilterUpdating={isFilterUpdating}
          isDateRange={true}
        />


        <Button
          sx={{
            textTransform: 'none',
            minWidth: '70px',
            fontWeight: 400,
            justifyContent: 'center',
            padding: '6px 12px',
            borderRadius: '4px',
            border: '1px solid rgba(0, 0, 0, 0.23)',
            backgroundColor: '#e0e0e0',
            color: '#333',
            '&:hover': { backgroundColor: '#616161', color: '#fff' },
            '&.Mui-disabled': {
              backgroundColor: '#f0f0f0',
              color: '#9e9e9e',
              border: '1px solid #e0e0e0',
              cursor: 'not-allowed',
            },
          }}
          onClick={clearAllFilters}
          disabled={
            !selectedDateRange &&
            selectedConditionType.length === 0 &&
            selectedTables.length === 0 &&
            selectedOwner.length === 0
          }
        >
          Reset
        </Button>
        </Box>
      )}


      {/* Alerts List */}
      <Box sx={{ minHeight: '55vh' }}>
        { loading ? (
          // 🔄 Show skeletons only when filtersLoading is true
          <Stack spacing={2}>
            {[...Array(3)].map((_, index) => (
              <Box key={index} sx={{ p: 2, border: '1px solid #e0e0e0', borderRadius: 1 }}>
                <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 2 }}>
                  <Skeleton variant="text" width={200} height={24} />
                  <Skeleton variant="rectangular" width={100} height={32} />
                </Box>
                <Skeleton variant="text" width="60%" height={20} sx={{ mb: 1 }} />
                <Skeleton variant="text" width="80%" height={20} sx={{ mb: 2 }} />
                <Box sx={{ display: 'flex', gap: 1 }}>
                  <Skeleton variant="rectangular" width={80} height={24} />
                  <Skeleton variant="rectangular" width={60} height={24} />
                  <Skeleton variant="rectangular" width={70} height={24} />
                </Box>
              </Box>
            ))}
          </Stack>
        ) : pagedItems.length > 0 ? (
          // ✅ Show actual alert cards when filters are done loading
          <Stack spacing={2}>
            {pagedItems.map((alert, i) => (
              <AlertCard key={`${alert.ruleId}-${alert.modifiedDate}-${i}`} {...alert}
              selectedDateRange={selectedDateRange}
            />
            ) )}


          </Stack>
        ):   (
              <Typography variant="body2" sx={{ mt: 2 }}>
                No Alerts
               
              </Typography>
           
            )
         
        }
      </Box>
      <Box sx={{ display: "flex", justifyContent: "center", mt: 3 }}>
        <MuiPagination currentPage={currentPage} totalPages={totalPages} onPageChange={setCurrentPage} />
      </Box>


    </Container>
  );
}

export default Alerts;