// src/data/alertsData.js
export const alertsData = [
  {
    ruleName: "Length Check",
    ruleId: "R-1234",
    ruleDescription: "Checks for length check in customer table.",
    tableName: "customer",
    catalog: "customer_catalog",
    schema: "customer_schema",
    owner: "Alice",
    severity: 'Warning',
    modifiedDate: "2025-07-28",
    previousData: {
      columns: ["c_phone"],
      severity: "Warning",
      condition: { value: 12 },
    },
    currentData: {
      columns: ["c_phone"],
      severity: "Critical",
      condition: { value: 11 },
    },
  },
  {
    ruleName: "Null Check",
    ruleId: "R-5678",
    ruleDescription: "Checks for null values in order table.",
    tableName: "orders",
    catalog: "order_catalog",
    schema: "order_schema",
    owner: "Bob",
    modifiedDate: "2025-07-30",
    severity: 'Critical',
    previousData: {
      columns: ["order_date"],
      severity: "Critical",
      condition: { allowNull: false },
    },
    currentData: {
      columns: ["order_date", "delivery_date"],
      severity: "Warning",
      condition: { allowNull: false },
    },
  },
];

