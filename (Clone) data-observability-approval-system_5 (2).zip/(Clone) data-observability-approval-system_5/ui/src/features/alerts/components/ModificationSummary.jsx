import React from "react";
import {
  Box,
  Typography,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableRow,
  TableHead, // 💡 IMPORTED TableHead
  Dialog,
  DialogTitle,
  DialogContent,
  IconButton,
  CircularProgress,
} from "@mui/material";
import CloseIcon from "@mui/icons-material/Close";

const normalizeValue = (val) => {
  if (typeof val === "string") {
    try {
      const parsed = JSON.parse(val);
      return parsed;
    } catch {
      return val;
    }
  }
  return val;
};

const formatValue = (val) => {
  if (typeof val === "string") {
    try {
      const parsed = JSON.parse(val);
      return formatValue(parsed);
    } catch {
      return val;
    }
  }

  if (Array.isArray(val)) {
    return val.join(", ");
  }

  if (typeof val === "object" && val !== null) {
    return (
      "{ " +
      Object.entries(val)
        .map(([k, v]) => `${k}: ${Array.isArray(v) ? `[${v.join(", ")}]` : v}`)
        .join(", ") +
      " }"
    );
  }

  return String(val);
};

const ModificationSummary = ({
  previousData,
  currentData,
  modifiedDate,
  open,
  onClose,
  loading,
}) => {
  if (
    !previousData ||
    !currentData ||
    JSON.stringify(previousData) === JSON.stringify(currentData)
  )
    return null;

  const changedKeys = Object.keys(previousData).filter(
    (key) => JSON.stringify(previousData[key]) !== JSON.stringify(currentData[key])
  );

  if (changedKeys.length === 0) return null;

  return (
  <Dialog
    open={open}
    onClose={onClose}
    maxWidth="md" 
    fullWidth
    scroll="paper"
  >
    <DialogTitle>
      Rule Modification Summary
      <IconButton
        onClick={onClose}
        sx={{
          position: "absolute",
          right: 8,
          top: 8,
          color: (theme) => theme.palette.grey[500],
        }}
      >
        <CloseIcon />
      </IconButton>
    </DialogTitle>
    <DialogContent
      dividers
      sx={{
        maxHeight: "400px",
        overflowY: "auto",
      }}
    >
      {loading || !previousData || !currentData ? (
        <Box display="flex" justifyContent="center" alignItems="center" minHeight="150px">
          <CircularProgress />
        </Box>
      ) : (
        <Box>
          <TableContainer>
            <Table size="small">
              {/* 💡 ADDED TableHead FOR COLUMN HEADERS */}
              <TableHead>
                <TableRow>
                  <TableCell sx={{ fontWeight: "bold", width: "25%" }}>Attribute</TableCell>
                  <TableCell sx={{ fontWeight: "bold" }}>Old</TableCell>
                  <TableCell sx={{ fontWeight: "bold" }}>New</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {Object.keys(previousData).map((key) => {
                  const prev = normalizeValue(previousData[key]);
                  const curr = normalizeValue(currentData[key]);

                  const displayPrevious = formatValue(prev);
                  const displayCurrent = formatValue(curr);
                    
                    // Highlight the row if values are different
                    const isChanged = JSON.stringify(prev) !== JSON.stringify(curr);

                  const formattedKey = key
                    .replace(/_/g, " ")
                    .replace(/\b\w/g, (char) => char.toUpperCase());

                  return (
                    <TableRow 
                        key={key}
                        sx={{
                            backgroundColor: isChanged ? '#fff3e0' : 'inherit', // Light orange background for changed rows
                        }}
                    >
                      {/* Attribute Name */}
                      <TableCell sx={{ fontWeight: "bold", width: "25%" }}>
                        {formattedKey}
                      </TableCell>
                      
                      {/* Old Value */}
                      <TableCell>
                        <Typography variant="body2" sx={{ color: isChanged ? '#d32f2f' : 'inherit' }}>
                            {displayPrevious}
                        </Typography>
                      </TableCell>

                      {/* New Value */}
                      <TableCell>
                        <Typography variant="body2" sx={{ color: isChanged ? '#388e3c' : '#555' }}>
                            {displayCurrent}
                        </Typography>
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </TableContainer>

          <Typography variant="caption" sx={{ mt: 2, display: "block", color: "#555" }}>
            Modified Date: {modifiedDate}
          </Typography>
        </Box>
      )}
    </DialogContent>
  </Dialog>
);

}
export default ModificationSummary;

// import React from "react";
// import {
//   Box,
//   Typography,
//   Table,
//   TableBody,
//   TableCell,
//   TableContainer,
//   TableRow,
//   Tooltip,
//   Dialog,
//   DialogTitle,
//   DialogContent,
//   IconButton,
// } from "@mui/material";
// import CloseIcon from "@mui/icons-material/Close";

// const normalizeValue = (val) => {
//   if (typeof val === "string") {
//     try {
//       const parsed = JSON.parse(val);
//       return parsed;
//     } catch {
//       return val;
//     }
//   }
//   return val;
// };

// const formatValue = (val) => {
//   if (typeof val === "string") {
//     try {
//       const parsed = JSON.parse(val);
//       return formatValue(parsed);
//     } catch {
//       return val;
//     }
//   }

//   if (Array.isArray(val)) {
//     return val.join(", ");
//   }

//   if (typeof val === "object" && val !== null) {
//     return (
//       "{ " +
//       Object.entries(val)
//         .map(([k, v]) => `${k}: ${Array.isArray(v) ? `[${v.join(", ")}]` : v}`)
//         .join(", ") +
//       " }"
//     );
//   }

//   return String(val);
// };

// const ModificationSummary = ({
//   previousData,
//   currentData,
//   modifiedDate,
//   open,
//   onClose,
//   loading,
// }) => {
//   if (
//     !previousData ||
//     !currentData ||
//     JSON.stringify(previousData) === JSON.stringify(currentData)
//   )
//     return null;

//   const changedKeys = Object.keys(previousData).filter(
//     (key) => JSON.stringify(previousData[key]) !== JSON.stringify(currentData[key])
//   );

//   if (changedKeys.length === 0) return null;

//   return (
//   <Dialog
//     open={open}
//     onClose={onClose}
//     maxWidth="sm" // Make the dialog smaller
//     fullWidth
//     scroll="paper" // Allow scrolling inside the DialogContent
//   >
//     <DialogTitle>Rule Modification Summary</DialogTitle>
//     <DialogContent
//       dividers
//       sx={{
//         maxHeight: "200px", // Limit height
//         overflowY: "auto",  // Enable vertical scroll if content overflows
//       }}
//     >
//       {loading || !previousData || !currentData ? (
//         <Box display="flex" justifyContent="center" alignItems="center" minHeight="150px">
//           <CircularProgress />
//         </Box>
//       ) : (
//         <Box>
//           <TableContainer>
//             <Table size="small">
//               <TableBody>
//                 {Object.keys(previousData).map((key) => {
//                   const prev = normalizeValue(previousData[key]);
//                   const curr = normalizeValue(currentData[key]);

//                   const displayPrevious = formatValue(prev);
//                   const displayCurrent = formatValue(curr);

//                   const formattedKey = key
//                     .replace(/_/g, " ")
//                     .replace(/\b\w/g, (char) => char.toUpperCase());

//                   return (
//                     <TableRow key={key}>
//                       <TableCell sx={{ fontWeight: "bold", width: "25%" }}>
//                         {formattedKey}
//                       </TableCell>
//                       <TableCell>
//                         <Typography variant="body2">Old: {displayPrevious}</Typography>
//                       </TableCell>
//                       <TableCell>
//                         <Typography variant="body2" color="#555">New: {displayCurrent}</Typography>

//                       </TableCell>
//                     </TableRow>
//                   );
//                 })}
//               </TableBody>
//             </Table>
//           </TableContainer>

//           <Typography variant="caption" sx={{ mt: 2, display: "block", color: "#555" }}>
//             Modified Date: {modifiedDate}
//           </Typography>
//         </Box>
//       )}
//     </DialogContent>
//   </Dialog>
// );

// }
// export default ModificationSummary;
// import React from "react";
// import {
//   Box,
//   Typography,
//   Table,
//   TableBody,
//   TableCell,
//   TableContainer,
//   TableRow,
//   Tooltip,
//   Dialog,
//   DialogTitle,
//   DialogContent,
//   IconButton,
//   CircularProgress, // Added to resolve the error for CircularProgress
// } from "@mui/material";
// import CloseIcon from "@mui/icons-material/Close";

// const normalizeValue = (val) => {
//   if (typeof val === "string") {
//     try {
//       const parsed = JSON.parse(val);
//       return parsed;
//     } catch {
//       return val;
//     }
//   }
//   return val;
// };

// const formatValue = (val) => {
//   if (typeof val === "string") {
//     try {
//       const parsed = JSON.parse(val);
//       return formatValue(parsed);
//     } catch {
//       return val;
//     }
//   }

//   if (Array.isArray(val)) {
//     return val.join(", ");
//   }

//   if (typeof val === "object" && val !== null) {
//     return (
//       "{ " +
//       Object.entries(val)
//         .map(([k, v]) => `${k}: ${Array.isArray(v) ? `[${v.join(", ")}]` : v}`)
//         .join(", ") +
//       " }"
//     );
//   }

//   return String(val);
// };

// const ModificationSummary = ({
//   previousData,
//   currentData,
//   modifiedDate,
//   open,
//   onClose,
//   loading,
// }) => {
//   if (
//     !previousData ||
//     !currentData ||
//     JSON.stringify(previousData) === JSON.stringify(currentData)
//   )
//     return null;

//   const changedKeys = Object.keys(previousData).filter(
//     (key) => JSON.stringify(previousData[key]) !== JSON.stringify(currentData[key])
//   );

//   if (changedKeys.length === 0) return null;

//   return (
//   <Dialog
//     open={open}
//     onClose={onClose}
//     maxWidth="md" // ⬅️ Changed from "sm" to "md" for increased width
//     fullWidth
//     scroll="paper"
//   >
//     <DialogTitle>
//       Rule Modification Summary
//       <IconButton
//         onClick={onClose}
//         sx={{
//           position: "absolute",
//           right: 8,
//           top: 8,
//           color: (theme) => theme.palette.grey[500],
//         }}
//       >
//         <CloseIcon />
//       </IconButton>
//     </DialogTitle>
//     <DialogContent
//       dividers
//       sx={{
//         maxHeight: "400px", // ⬅️ Increased height from "200px" to "400px"
//         overflowY: "auto",
//       }}
//     >
//       {loading || !previousData || !currentData ? (
//         <Box display="flex" justifyContent="center" alignItems="center" minHeight="150px">
//           <CircularProgress />
//         </Box>
//       ) : (
//         <Box>
//           <TableContainer>
//             <Table size="small">
//               <TableBody>
//                 {Object.keys(previousData).map((key) => {
//                   const prev = normalizeValue(previousData[key]);
//                   const curr = normalizeValue(currentData[key]);

//                   const displayPrevious = formatValue(prev);
//                   const displayCurrent = formatValue(curr);

//                   const formattedKey = key
//                     .replace(/_/g, " ")
//                     .replace(/\b\w/g, (char) => char.toUpperCase());

//                   return (
//                     <TableRow key={key}>
//                       <TableCell sx={{ fontWeight: "bold", width: "25%" }}>
//                         {formattedKey}
//                       </TableCell>
//                       <TableCell>
//                         <Typography variant="body2">Old: {displayPrevious}</Typography>
//                       </TableCell>
//                       <TableCell>
//                         <Typography variant="body2" color="#555">New: {displayCurrent}</Typography>

//                       </TableCell>
//                     </TableRow>
//                   );
//                 })}
//               </TableBody>
//             </Table>
//           </TableContainer>

//           <Typography variant="caption" sx={{ mt: 2, display: "block", color: "#555" }}>
//             Modified Date: {modifiedDate}
//           </Typography>
//         </Box>
//       )}
//     </DialogContent>
//   </Dialog>
// );

// }
// export default ModificationSummary;