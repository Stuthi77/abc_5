import React from "react";
import { Box, Stack, Typography, Tooltip, Dialog, DialogTitle, DialogContent, IconButton } from "@mui/material";
import CloseIcon from '@mui/icons-material/Close';

// Helper to safely parse stringified JSON
const normalizeValue = (val) => {
  if (typeof val === "string") {
    try {
      return JSON.parse(val);
    } catch {
      return val;
    }
  }
  return val;
};

const RuleSummary = ({ currentData, open, onClose }) => {
  if (!currentData || typeof currentData !== "object") return null;

  const { created_at, column_name, condition } = currentData;
  const normalizedCondition = normalizeValue(condition);

  const hasCondition =
    normalizedCondition !== undefined &&
    normalizedCondition !== null &&
    normalizedCondition !== "";

  const displayCondition =
    typeof normalizedCondition === "object"
      ? JSON.stringify(normalizedCondition)
      : String(normalizedCondition);

  return (
    <Dialog open={open} onClose={onClose} maxWidth="sm" fullWidth>
      <DialogTitle sx={{ m: 0, p: 2 }}>
        Rule Summary
        {onClose ? (
          <IconButton
            aria-label="close"
            onClick={onClose}
            sx={{
              position: "absolute",
              right: 8,
              top: 8,
              color: (theme) => theme.palette.grey[500],
            }}
          >
            <CloseIcon />
          </IconButton>
        ) : null}
      </DialogTitle>
      <DialogContent dividers>
        <Box
          sx={{
            p: 1,
            borderRadius: 2,
            backgroundColor: "#fff",
            width: "100%",
            boxSizing: "border-box",
            boxShadow: 1,
            border: "1px solid #e0e0e0",
          }}
        >
          <Stack
            direction="row"
            spacing={2}
            sx={{ alignItems: "center", flexWrap: "wrap" }}
          >
            <Typography
              variant="body2"
              sx={{
                fontWeight: "bold",
                color: "#7f8c8d",
                whiteSpace: "nowrap",
                flexShrink: 0,
              }}
            >
              Column Name:
            </Typography>

            <Tooltip title={column_name}>
              <Typography
                variant="body2"
                sx={{
                  color: "#145a32",
                  maxWidth: 200,
                  whiteSpace: "nowrap",
                  overflow: "hidden",
                  textOverflow: "ellipsis",
                }}
              >
                {column_name}
              </Typography>
            </Tooltip>

            {hasCondition && (
              <>
                <Typography
                  variant="body2"
                  sx={{
                    fontWeight: "bold",
                    color: "#7f8c8d",
                    whiteSpace: "nowrap",
                    flexShrink: 0,
                  }}
                >
                  Condition:
                </Typography>

                <Tooltip title={displayCondition}>
                  <Typography
                    variant="body2"
                    sx={{
                      color: "#145a32",
                      maxWidth: 300,
                      whiteSpace: "nowrap",
                      overflow: "hidden",
                      textOverflow: "ellipsis",
                      wordBreak: "break-word",
                    }}
                  >
                    {displayCondition}
                  </Typography>
                </Tooltip>
              </>
            )}
          </Stack>
        </Box>
      </DialogContent>
    </Dialog>
  );
};

export default RuleSummary;
