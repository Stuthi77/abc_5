import React, { useState, useRef, useEffect } from 'react';
import KeyboardArrowDownIcon from '@mui/icons-material/KeyboardArrowDown';
import KeyboardArrowUpIcon from '@mui/icons-material/KeyboardArrowUp';

const MultiSelectDropdown = ({ placeholder, options, selected, onChange }) => {
  const [isOpen, setIsOpen] = useState(false);
  const dropdownRef = useRef(null);

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleOptionClick = (value) => {
    const newSelected = selected.includes(value)
      ? selected.filter((item) => item !== value)
      : [...selected, value];
    onChange(newSelected);
  };

  const getDisplayText = () => {
    if (selected.length === 0) return placeholder;
    if (selected.length === 1) return selected[0];
    return `${selected.length} selected`;
  };

  const inputStyle = {
    padding: '8px 12px',
    border: '1px solid #d1d5db',
    borderRadius: '6px',
    fontSize: '14px',
    backgroundColor: 'white',
    height: '33px',
    boxSizing: 'border-box',
    cursor: 'pointer',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'space-between',
    minWidth: '120px',
    fontFamily: "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif",
  };

  return (
    <div style={{ position: 'relative', flex: '0 0 auto' }} ref={dropdownRef}>
      <div onClick={() => setIsOpen(!isOpen)} style={inputStyle}>
        <span style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', fontSize: '14px' }}>
          {getDisplayText()}
        </span>
        <span
          style={{
            marginLeft: '8px',
            // transform: isOpen ? 'rotate(180deg)' : 'rotate(0deg)',
            // transition: 'transform 0.2s',
          }}
        >
          {isOpen ? <KeyboardArrowUpIcon /> : <KeyboardArrowDownIcon />}
        </span>
      </div>

      {isOpen && (
        <div
          style={{
            position: 'absolute',
            top: '100%',
            fontSize: '14px',
            left: 0,
            right: 0,
            backgroundColor: 'white',
            border: '1px solid #d1d5db',
            borderRadius: '6px',
            marginTop: '2px',
            maxHeight: '200px',
            overflowY: 'auto',
            zIndex: 1000,
            boxShadow: '0 4px 6px -1px rgba(0,0,0,0.1)',
          }}
        >
          {options.map((option) => (
            <label
              key={option}
              style={{
                display: 'flex',
                alignItems: 'center',
                padding: '8px 12px',
                cursor: 'pointer',
                fontSize: '13px',
                borderBottom: '1px solid #f3f4f6',
              }}
              onMouseEnter={(e) => (e.currentTarget.style.backgroundColor = '#d7dbdeff')}
              onMouseLeave={(e) => (e.currentTarget.style.backgroundColor = 'white')}
            >
              <input
                type="checkbox"
                checked={selected.includes(option)}
                onChange={() => handleOptionClick(option)}
                style={{ marginRight: '8px' }}
              />
              {option}
            </label>
          ))}
        </div>
      )}
    </div>
  );
};


const RulesFilter = ({ filters, onFilterChange, onClearFilters }) => {
  return (
    <div
      style={{
        display: 'flex',
        alignItems: 'center',
        width: '100%',
        gap: '12px',
        flexWrap: 'nowrap',
        minHeight: '36px',
      }}
    >
      <MultiSelectDropdown
        placeholder="Rule Type"
        options={['NULL', 'UNIQUE', 'RANGE', 'LENGTH', 'PATTERN', 'CUSTOM']}
        selected={filters.rule_type}
        onChange={(values) => onFilterChange('rule_type', values)}
      />
      <MultiSelectDropdown
        placeholder="Severity"
        options={['Critical', 'Warning', 'Info', 'Low']}
        selected={filters.severity}
        onChange={(values) => onFilterChange('severity', values)}
      />
      <MultiSelectDropdown
        placeholder="Table"
        options={['customers', 'orders', 'lineitem', 'products', 'transactions']}
        selected={filters.table_name}
        onChange={(values) => onFilterChange('table_name', values)}
      />
      <MultiSelectDropdown
        placeholder="Status"
        options={['Active', 'Inactive', 'Pending']}
        selected={filters.status}
        onChange={(values) => onFilterChange('status', values)}
      />

      <MultiSelectDropdown
        placeholder="Schema"
        options={['Schema1', 'Schema2', 'Schema3']}
        selected={filters.schema_name || []}
        onChange={(values) => onFilterChange('schema_name', values)}
      />


      <button
        onClick={onClearFilters}
        style={{
          marginLeft: 'auto',
          height: '33px',
          padding: '8px 12px',
          backgroundColor: '#6b7280',
          color: 'white',
          border: 'none',
          borderRadius: '6px',
          cursor: 'pointer',
          fontSize: '13px',
          fontWeight: '500',
          minWidth: '90px',
        }}
      >
        Clear All
      </button>
    </div>
  );
};

export default RulesFilter;
