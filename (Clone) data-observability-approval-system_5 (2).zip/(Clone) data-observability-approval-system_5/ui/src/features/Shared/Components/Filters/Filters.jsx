import React, { useEffect, useRef, useState } from "react";
import KeyboardArrowDownIcon from '@mui/icons-material/KeyboardArrowDown';
import KeyboardArrowUpIcon from '@mui/icons-material/KeyboardArrowUp';

const Filter = ({
  label,
  options,
  selectedOptions = [],
  onToggleOption,
  isOpen,
  onToggleOpen,
  onClose
}) => {
  const wrapperRef = useRef(null);
  const btnRef = useRef(null);
  const menuRef = useRef(null);
  const [menuPos, setMenuPos] = useState({ top: 0, left: 0, width: 220 });


  const isActive = (selectedOptions?.length || 0) > 0;
  const isSelected = (option) => selectedOptions.includes(option);

  const computeMenuPos = () => {
    const btn = btnRef.current;
    if (!btn) return;
    const r = btn.getBoundingClientRect();
    const GAP = 4;
    const desiredLeft = Math.min(r.left, Math.max(0, window.innerWidth - 260));
    setMenuPos({
      top: r.bottom + GAP,
      left: desiredLeft,
      width: Math.max(r.width, 220),
    });
  };

  const handleOpen = () => {
    computeMenuPos();
    onToggleOpen?.();
  };

  
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (!isOpen) return;
      const clickedInsideButton = wrapperRef.current?.contains(event.target);
      const clickedInsideMenu = menuRef.current?.contains(event.target);
      if (!clickedInsideButton && !clickedInsideMenu) {
        onClose?.();
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, [isOpen, onClose]);


  useEffect(() => {
    if (!isOpen) return;
    const onScrollOrResize = () => computeMenuPos();
    window.addEventListener("scroll", onScrollOrResize, true);
    window.addEventListener("resize", onScrollOrResize, true);
    computeMenuPos();
    return () => {
      window.removeEventListener("scroll", onScrollOrResize, true);
      window.removeEventListener("resize", onScrollOrResize, true);
    };
  }, [isOpen]);

  return (
    <>
      <style>{`
        .filter-btn {
          background-color: #fff;
          border: 1px solid #ccc;
          border-radius: 4px;
          padding: 0.3rem 0.5rem;
          min-width: 150px;
          font-size: 0.85rem;
          display: flex;
          align-items: center;
          justify-content: space-between;
          cursor: pointer;
          height: 35px;
          font-family: 'Segoe UI', sans-serif;
          white-space: nowrap; /* keep label one line */
          transition: background-color .15s ease, border-color .15s ease, box-shadow .15s ease;
        }
        .filter-btn:hover { background-color: #f5f5f5; }           /* hover: light grey */
        .filter-btn.active {
          background-color: #e6f0ff;                               /* active when selected */
          border-color: #a8c6ff;
          color: #1f2d4d;
          font-weight: 500;
        }
        .filter-btn:focus {
          outline: none;
          box-shadow: 0 0 0 3px rgba(33,150,243,0.2);
          border-color: #90b8ff;
        }

        .dropdown-content-fixed {
          position: fixed;  /* avoids clipping */
          background-color: #fff;
          border: 1px solid #ccc;
          border-radius: 6px;
          box-shadow: 0 4px 10px rgba(0,0,0,0.1);
          z-index: 9999;
          max-height: 240px;
          overflow-y: auto;
          overflow-x: hidden;
          white-space: nowrap;
        }

        .dropdown-item {
          padding: 0.35rem 0.5rem;
          display: flex;
          gap: 8px;
          align-items: center;
          font-size: 13px;
          font-family: 'Segoe UI', sans-serif;
          transition: background-color .12s ease;
        }
        .dropdown-item:hover { background-color: #f5f5f5; }        /* item hover: light grey */
        .dropdown-item:has(input:checked) {
          background-color: #e6f0ff;                               /* item selected: light blue */
        }

        .dropdown-item label { white-space: nowrap; flex: 1; cursor: pointer; }
        .dropdown-item input[type='checkbox'] { width: 14px; height: 14px; margin: 0; }

        .arrow { margin-left: 5px; transition: transform .2s ease; }
        .arrow.open { transform: rotate(180deg); }
      `}</style>

      <div ref={wrapperRef} style={{ position: "relative" }}>
        <button
          ref={btnRef}
          className={`filter-btn ${isActive ? "active" : ""}`}
          onClick={handleOpen}
        >
          {label}{selectedOptions?.length ? ` (${selectedOptions.length})` : ""}
          <span className={`arrow ${isOpen ? "open" : ""}`}>
            {isOpen ? <KeyboardArrowUpIcon /> : <KeyboardArrowDownIcon />}
          </span>
        </button>
      </div>

      {isOpen && (
        <div
          ref={menuRef}
          className="dropdown-content-fixed"
          style={{ top: menuPos.top, left: menuPos.left, width: menuPos.width }}
          
          onMouseDown={(e) => e.stopPropagation()}
          onClick={(e) => e.stopPropagation()}
        >
          {options.map((option) => (
            <div key={option} className="dropdown-item">
              <input
                type="checkbox"
                id={`${label}-${option}`}
                checked={isSelected(option)}
                onChange={() => onToggleOption(option)}
              />
              <label htmlFor={`${label}-${option}`}>{option}</label>
            </div>
          ))}
        </div>
      )}
    </>
  );
};

export default Filter;
