import React, { useState, useRef, useEffect } from 'react';


const MultiSelectDropdown = ({ placeholder, options, selected, onChange }) => {
  const [isOpen, setIsOpen] = useState(false);
  const dropdownRef = useRef(null);

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleOptionClick = (value) => {
    const newSelected = selected.includes(value)
      ? selected.filter(item => item !== value)
      : [...selected, value];
    onChange(newSelected);
  };

  const getDisplayText = () => {
    if (selected.length === 0) return placeholder;
    if (selected.length === 1) return selected[0];
    return `${selected.length} selected`;
  };

  const inputStyle = {
    padding: '8px 12px',
    border: '1px solid #d1d5db',
    borderRadius: '6px',
    fontSize: '14px',
    backgroundColor: 'white',
    height: '36px',
    boxSizing: 'border-box',
    flex: '1',
    cursor: 'pointer',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'space-between',
    minWidth: '120px',
    fontFamily: "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif"
  };

  return (
    <div style={{ position: 'relative', flex: '1' }} ref={dropdownRef}>
      <div onClick={() => setIsOpen(!isOpen)} style={inputStyle}>
        <span style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
          {getDisplayText()}
        </span>
        <span style={{ marginLeft: '8px', transform: isOpen ? 'rotate(180deg)' : 'rotate(0deg)', transition: 'transform 0.2s' }}>
          ▼
        </span>
      </div>

      {isOpen && (
        <div style={{
          position: 'absolute',
          top: '100%',
          left: 0,
          right: 0,
          backgroundColor: 'white',
          border: '1px solid #d1d5db',
          borderRadius: '6px',
          marginTop: '2px',
          maxHeight: '200px',
          overflowY: 'auto',
          zIndex: 1000,
          boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)'
        }}>
          {options.map((option) => {
            const isSelected = selected.includes(option);
            return (
              <label
                key={option}
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  padding: '8px 12px',
                  cursor: 'pointer',
                  fontSize: '14px',
                  borderBottom: '1px solid #f3f4f6',
                  backgroundColor: isSelected ? '#bfdbfe' : 'white', 
                  transition: 'background-color 0.2s'
                }}
                onMouseEnter={(e) => {
                  if (!isSelected) e.currentTarget.style.backgroundColor = '#f3f4f6'; 
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.backgroundColor = isSelected ? '#bfdbfe' : 'white';
                }}
              >
                <input
                  type="checkbox"
                  checked={isSelected}
                  onChange={() => handleOptionClick(option)}
                  style={{ marginRight: '8px' }}
                />
                {option}
              </label>
            );
          })}
        </div>
      )}
    </div>
  );
};


const AlertsFilter = ({ filters, onFilterChange, onClearFilters }) => {
  return (
    <>
      <MultiSelectDropdown
        placeholder="Table"
        options={['Customer', 'Orders']}
        selected={filters.table_name}
        onChange={(values) => onFilterChange('table_name', values)}
      />
      <MultiSelectDropdown
        placeholder="Rule Type"
        options={['Type 1', 'Type 2', 'Type 3', 'Type 4', 'Type 5']}
        selected={filters.rule_id}
        onChange={(values) => onFilterChange('rule_id', values)}
      />
      <MultiSelectDropdown
        placeholder="Date Range"
        options={['Today', 'Last 7 Days', 'Last 30 Days', 'Last 90 Days']}
        selected={filters.date_range}
        onChange={(values) => onFilterChange('date_range', values)}
      />
      <button
        onClick={onClearFilters}
        style={{
          padding: '8px 16px',
          backgroundColor: '#6b7280',
          color: 'white',
          border: 'none',
          borderRadius: '6px',
          cursor: 'pointer',
          fontSize: '14px',
          fontWeight: '500',
          minWidth: '80px'
        }}
      >
        Clear All
      </button>
    </>
  );
};

export default AlertsFilter;
