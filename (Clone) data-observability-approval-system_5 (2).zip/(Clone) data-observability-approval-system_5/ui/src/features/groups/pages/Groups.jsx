// import React, { useMemo, useState, useEffect } from 'react';
// import Box from '@mui/material/Box';
// import Container from '@mui/material/Container';
// import { DataGrid } from '@mui/x-data-grid';
// import GroupIcon from '@mui/icons-material/Group';
// import TocIcon from '@mui/icons-material/Toc';
// import RuleIcon from '@mui/icons-material/Rule';
// import Button from '@mui/material/Button';
// import Typography from '@mui/material/Typography';
// import Skeleton from '@mui/material/Skeleton';
// import { useNavigate } from 'react-router-dom';

// import Search from '../../Shared/Components/Search/Search-Feature';

// const DataGridSkeleton = ({ rowCount = 10, columnWidths = [1, 1, 1, 1, 1, 1, 1] }) => {
//   return (
//     <Box sx={{ height: '70vh', width: '100%', border: '1px solid #e0e0e0', borderRadius: '4px' }}>
//       <Box sx={{ display: 'flex', alignItems: 'center', height: '40px', backgroundColor: '#f5f5f5', padding: '0 16px' }}>
//         {columnWidths.map((flex, index) => (
//           <Skeleton key={index} variant="text" sx={{ flex, height: '20px', margin: '0 8px' }} />
//         ))}
//       </Box>
//       {Array.from({ length: rowCount }).map((_, rowIndex) => (
//         <Box
//           key={rowIndex}
//           sx={{
//             display: 'flex',
//             alignItems: 'center',
//             height: '50px',
//             padding: '0 16px',
//             borderBottom: '1px solid #e0e0e0',
//           }}
//         >
//           {columnWidths.map((flex, colIndex) => (
//             <Skeleton
//               key={colIndex}
//               variant="text"
//               width="80%"
//               height="20px"
//               sx={{ flex, margin: '0 8px' }}
//             />
//           ))}
//         </Box>
//       ))}
//     </Box>
//   );
// };

// function Groups() {
//   const navigate = useNavigate();
//   const [groups, setGroups] = useState([]);
//   const [totalGroups, setTotalGroups] = useState(0);
//   const [loading, setLoading] = useState(true);
//   const [error, setError] = useState(null);
//   const [paginationModel, setPaginationModel] = useState({
//     page: 0,
//     pageSize: 10,
//   });
//   const [searchTerm, setSearchTerm] = useState('');
//   const [isProcessing, setIsProcessing] = useState({});

//   const userData = JSON.parse(sessionStorage.getItem("userData")) || {};
//   const userId = userData.userId;

//   const navigateTOCreateGroup = () => {
//     navigate('/groups/create');
//   };

//   const fetchGroups = async () => {
//     setLoading(true);
//     setError(null);
//     try {
//       const url = new URL(`${import.meta.env.VITE_API_URL}/api/groups`, window.location.origin);
//       url.searchParams.append('page', paginationModel.page + 1);
//       url.searchParams.append('limit', paginationModel.pageSize);

//       if (userId) {
//         url.searchParams.append('user_id', userId);
//       }

//       const response = await fetch(url.toString());
//       if (!response.ok) {
//         throw new Error('Failed to fetch groups.');
//       }

//       const data = await response.json();
//       const totalGroupsFromData = data.length > 0 ? parseInt(data[0].total_groups, 10) : 0;

//       const formattedData = data.map((group) => {
//         const isSubscribed = group.subscription_status === 'true';
//         return {
//           id: group.group_name,
//           rulesCount: group.rules || 0,
//           groupName: group.group_name,
//           groupSize: parseInt(group.group_size, 10),
//           tableCount: group.tables || 0,
//           owner: group.owner,
//           subscription: isSubscribed ? 'Unsubscribe' : 'Subscribe',
//           createdAt: group.created_at.split('T')[0],
//           groupId: group.group_id,
//           subscription_status: isSubscribed,
//         };
//       });

//       setGroups(formattedData);
//       setTotalGroups(totalGroupsFromData);
//     } catch (err) {
//       setError(err.message);
//     } finally {
//       setLoading(false);
//     }
//   };

//   useEffect(() => {
//     fetchGroups();
//   }, [paginationModel, userId]);

//   const handleSubscriptionChange = async (groupId, isSubscribed) => {
//     if (!userId) {
//       console.error("User not authenticated. Cannot perform action.");
//       return;
//     }

//     setIsProcessing({ ...isProcessing, [groupId]: true });

//     const endpoint = isSubscribed
//       ? `${import.meta.env.VITE_API_URL}/api/groups/${groupId}/remove_members`
//       : `${import.meta.env.VITE_API_URL}/api/groups/${groupId}/add_members`;

//     try {
//       const res = await fetch(endpoint, {
//         method: "POST",
//         headers: { "Content-Type": "application/json" },
//         body: JSON.stringify({ user_ids: [userId] }),
//       });

//       if (!res.ok) {
//         throw new Error(`Failed to update subscription: ${res.statusText}`);
//       }

//       const groupToUpdate = groups.find(group => group.groupId === groupId);

//       const updatedGroups = groups.map((group) =>
//         group.groupId === groupId
//           ? {
//               ...group,
//               subscription: isSubscribed ? 'Subscribe' : 'Unsubscribe',
//               subscription_status: !isSubscribed,
//             }
//           : group
//       );
//       setGroups(updatedGroups);

//       const storedUserData = JSON.parse(sessionStorage.getItem("userData"));
//       if (storedUserData && groupToUpdate) {
//         let updatedSubscribedGroups;
//         if (isSubscribed) {
//           updatedSubscribedGroups = storedUserData.subscribedGroups.filter(
//             (name) => name !== groupToUpdate.groupName
//           );
//         } else {
//           updatedSubscribedGroups = [...storedUserData.subscribedGroups, groupToUpdate.groupName];
//         }

//         const newUserData = {
//           ...storedUserData,
//           subscribedGroups: updatedSubscribedGroups,
//         };
//         sessionStorage.setItem("userData", JSON.stringify(newUserData));
//       }

//     } catch (err) {
//       console.error("Error updating subscription:", err);
//     } finally {
//       setIsProcessing({ ...isProcessing, [groupId]: false });
//     }
//   };

//   const columns = [
//     {
//       field: 'groupName',
//       headerName: 'Group',
//       flex: 1,
//       renderCell: (params) => (
//         <Box sx={{ color: '#102a44ff' }}>
//           <Box
//             sx={{ cursor: 'pointer', width: 'fit-content', '&:hover': { textDecoration: 'underline' } }}
//             onClick={() => navigate(`/groups/${params.row.groupId}`, { state: { groupName: params.row.groupName } })}
//           >
//             {params.value}
//           </Box>
//         </Box>
//       ),
//     },
//     {
//       field: 'groupSize',
//       headerName: 'Group Size',
//       type: 'number',
//       minWidth: 10,
//       align: 'left',
//       headerAlign: 'left',
//       renderCell: (params) => (
//         <Box
//           sx={{ display: 'flex', alignItems: 'center', gap: '8px', cursor: 'pointer', '&:hover': { color: 'blue' } }}
//           onClick={() => navigate(`/groups/${params.row.groupId}?tab=members`, { state: { groupName: params.row.groupName } })}
//         >
//           <GroupIcon />{params.value}
//         </Box>
//       ),
//     },
//     {
//       field: 'tableCount',
//       headerName: 'Tables',
//       type: 'number',
//       minWidth: 10,
//       align: 'left',
//       headerAlign: 'left',
//       renderCell: (params) => (
//         <Box
//           sx={{ display: 'flex', alignItems: 'center', gap: '8px', cursor: 'pointer', '&:hover': { color: 'blue' } }}
//           onClick={() => navigate(`/groups/${params.row.groupId}?tab=tables`, { state: { groupName: params.row.groupName } })}
//         >
//           <TocIcon />{params.value}
//         </Box>
//       ),
//     },
//     // {
//     //   field: 'rulesCount',
//     //   headerName: 'Rules',
//     //   type: 'number',
//     //   minWidth: 10,
//     //   align: 'left',
//     //   headerAlign: 'left',
//     //   renderCell: (params) => (
//     //     <Box sx={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
//     //       <RuleIcon />{params.value}
//     //     </Box>
//     //   ),
//     // },
//     {
//       field: 'rulesCount',
//       headerName: 'Rules',
//       type: 'number',
//       minWidth: 10,
//       align: 'left',
//       headerAlign: 'left',
//       renderCell: (params) => {
//         const isSubscribed = params.row.subscription_status;

//         const handleClick = () => {
//           if (!isSubscribed) {
//             alert('You must subscribe to this group to view its rules.');
//             return;
//           }

//           // ✅ Read current session storage
//           const storedUserData = JSON.parse(sessionStorage.getItem("userData")) || {};

//           // ✅ Overwrite selected group and group ID
//           const updatedUserData = {
//             ...storedUserData,
//             selectedGroup: params.row.groupName,     // Overwrite selected group name
//             selectedGroupId: params.row.groupId,     // Overwrite selected group ID
//           };

//           // ✅ Save back to session storage
//           sessionStorage.setItem("userData", JSON.stringify(updatedUserData));

//           // ✅ Navigate to rule management page
//           navigate('/rule-management');
//         };

//         return (
//           <Box
//             sx={{
//               display: 'flex',
//               alignItems: 'center',
//               gap: '8px',
//               cursor: isSubscribed ? 'pointer' : 'not-allowed',
//               color: isSubscribed ? 'inherit' : 'grey',
//               '&:hover': {
//                 color: isSubscribed ? 'blue' : 'grey',
//               },
//             }}
//             onClick={handleClick}
//           >
//             <RuleIcon />{params.value}
//           </Box>
//         );
//       },
//     },

//     {
//       field: 'owner',
//       headerName: 'Owner',
//       flex: 1
//     },
//     {
//       field: 'createdAt',
//       headerName: 'Created At',
//       flex: 1
//     },
//     {
//       field: 'subscription',
//       headerName: 'Subscription',
//       flex: 1,
//       renderCell: (params) => {
//         const isSubscribed = params.row.subscription_status;
//         const isCurrentlyProcessing = isProcessing[params.row.groupId];

//         return (
//           <Box sx={{ display: 'flex', alignContent: 'center' }}>
//             <Button
//               size="small"
//               color={isSubscribed ? "error" : "success"}
//               sx={{
//                 ...(isCurrentlyProcessing && {
//                   color: 'text.disabled',
//                   borderColor: 'grey.300',
//                   backgroundColor: 'grey.100',
//                   '&:hover': {
//                     backgroundColor: 'grey.100',
//                     cursor: 'default',
//                   }
//                 }),
//               }}
//               onClick={() => handleSubscriptionChange(params.row.groupId, isSubscribed)}
//               disabled={isCurrentlyProcessing || !userId}
//             >
//               {params.value}
//             </Button>
//           </Box>
//         );
//       },
//     },
//   ];

//   const filteredGroups = useMemo(() => {
//     if (!searchTerm) return groups;
//     const normalizedSearch = searchTerm.toLowerCase();
//     return groups.filter((group) =>
//       group.groupName.toLowerCase().includes(normalizedSearch) ||
//       group.owner.toLowerCase().includes(normalizedSearch)
//     );
//   }, [groups, searchTerm]);

//   return (
//     <Box>
//       <Container maxWidth="lg">
//         <Box sx={{ mt: 2, mb: 2, display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 1 }}>
//           <Typography variant="h6">Groups</Typography>
//           <Box sx={{ display: 'flex', alignContent: 'center', gap: 1 }}>
//             <Button
//               variant="outlined"
//               color="secondary"
//               size='small'
//               sx={{
//                 color: '#29537cff',
//                 borderColor: '#29537cff',
//                 fontWeight: 'bold',
//                 '&:hover': {
//                   backgroundColor: '#f7f7faff',
//                   borderColor: '#102a44ff'
//                 }
//               }}
//               onClick={navigateTOCreateGroup}
//             >
//               Create Group
//             </Button>
//           </Box>
//         </Box>
//         <Box sx={{ display: 'flex', justifyContent: 'space-between', height: '100%', width: '100%' }}>
//           <Search
//             placeholder="Search "
//             searchTerm={searchTerm}
//             setSearchTerm={setSearchTerm}
//             onSearch={setSearchTerm}
//             width={500}
//           />
//           <Box sx={{ display: 'flex', alignItems: 'center' }}>
//             <Typography variant="subtitle2" gutterBottom>
//               Total Groups : <b>{filteredGroups.length}</b>
//             </Typography>
//           </Box>
//         </Box>
//         <Box sx={{ mt: 1, height: '100%', width: '100%' }}>
//           {loading ? (
//             <DataGridSkeleton rowCount={paginationModel.pageSize} columnWidths={[1, 1, 1, 1, 1, 1, 1]} />
//           ) : error ? (
//             <Typography color="error" sx={{ textAlign: 'center', mt: 4 }}>
//               Error: {error}
//             </Typography>
//           ) : (
//             // <DataGrid
//             //   sx={{
//             //     height: '70vh',
//             //     backgroundColor: 'unset',
//             //     border: 'none',
//             //     width: '100%',
//             //     '& .MuiDataGrid-row:hover': {
//             //       backgroundColor: '#f7f7faff',
//             //     },
//             //     '& .MuiDataGrid-columnHeaders': {
//             //       backgroundColor: 'black',
//             //       height: '40px'
//             //     },
//             //     '& .MuiDataGrid-cell[data-field="subscription"]': {
//             //       alignContent: 'center'
//             //     },
//             //     // === THE IMPORTANT PART: hide the "1-10 of 100" displayed rows text ===
//             //     '& .MuiTablePagination-displayedRows': {
//             //       display: 'none',
//             //     },
//             //     // fallback (more specific) selector in case the structure differs
//             //     '& .MuiDataGrid-footerContainer .MuiTablePagination-root .MuiTablePagination-displayedRows': {
//             //       display: 'none',
//             //     },
//             //   }}
//             <DataGrid
//               sx={{
//                 height: '70vh',
//                 border: 'none',
//                 width: '100%',
//                 '& .MuiDataGrid-row:hover': { backgroundColor: '#f7f7faff' },
//                 '& .MuiDataGrid-columnHeaders': { backgroundColor: 'black', height: '40px' },
//                 '& .MuiDataGrid-cell[data-field="subscription"]': { alignContent: 'center' },

//                 // Footer adjustments
//                 '& .MuiDataGrid-footerContainer': {
//                   display: 'flex',
//                   justifyContent: 'flex-end',
//                   padding: '0 8px', // optional: tiny padding on sides
//                 },
//                 '& .MuiTablePagination-root': {
//                   display: 'flex',
//                   justifyContent: 'flex-end',
//                   gap: '4px', // reduce spacing between children
//                   minHeight: '36px', // compact height
//                   padding: 0,
//                 },
//                 '& .MuiTablePagination-actions': {
//                   margin: 0, // remove default margin around pagination arrows
//                 },
//                 '& .MuiTablePagination-selectLabel, & .MuiTablePagination-select': {
//                   margin: 0, // remove extra space around rows-per-page dropdown
//                   padding: 0,
//                 },
//                 '& .MuiTablePagination-displayedRows': {
//                   display: 'none', // hide 1-5 of 10
//                   margin: 0,
//                 },
//               }}
//               rowHeight={50}
//               rows={filteredGroups}
//               rowCount={filteredGroups.length}
//               columns={columns}
//               pagination
//               paginationMode="client"
//               paginationModel={paginationModel}
//               onPaginationModelChange={setPaginationModel}
//               pageSizeOptions={[10, 20, 50]}
//               disableRowSelectionOnClick


//               // <DataGrid
//               // sx={{
//               //   height: '70vh',
//               //   backgroundColor: 'unset',
//               //   border: 'none',
//               //   width: '100%',
//               //   '& .MuiDataGrid-row:hover': {
//               //     backgroundColor: '#f7f7faff',
//               //   },
//               //   '& .MuiDataGrid-columnHeaders': {
//               //     backgroundColor: 'black',
//               //     height: '40px'
//               //   },
//               //   '& .MuiDataGrid-cell[data-field="subscription"]': {
//               //     alignContent: 'center'
//               //   },
//               //   '& .MuiTablePagination-displayedRows': {
//               //     display: 'none',
//               //     margin: 0
//               //   },
//               //   '& .MuiDataGrid-footerContainer': {
//               //     justifyContent: 'flex-end !important', // align everything to the right
//               //     gap: 0, // remove extra spacing
//               //   },
//               //   '& .MuiTablePagination-toolbar': {
//               //     gap: 0, // remove space between selector and arrows
//               //     minHeight: '40px', // keeps footer compact
//               //   },
//               // }}
//               // rowHeight={50}
//               // rows={filteredGroups}
//               // rowCount={filteredGroups.length}
//               // columns={columns}
//               // pagination
//               // paginationMode="client"
//               // paginationModel={paginationModel}
//               // onPaginationModelChange={setPaginationModel}
//               // pageSizeOptions={[10, 20, 50]}
//               // disableRowSelectionOnClick
//               // localeText={{
//               //   pagination: {
//               //     labelDisplayedRows: () => '',
//               //   },
//               // }}
//             />

//             //   rowHeight={50}
//             //   rows={filteredGroups}
//             //   rowCount={filteredGroups.length}
//             //   columns={columns}
//             //   pagination
//             //   paginationMode="client"
//             //   paginationModel={paginationModel}
//             //   onPaginationModelChange={setPaginationModel}
//             //   pageSizeOptions={[10, 20, 50]}
//             //   disableRowSelectionOnClick
//             //   // fallback localeText override (keeps it empty if the CSS doesn't catch it)
//             //   localeText={{
//             //     pagination: {
//             //       labelDisplayedRows: () => '',
//             //     },
//             //   }}
//             // />
//           )}
//         </Box>
//       </Container>
//     </Box>
//   );
// }

// export default Groups;

import React, { useMemo, useState, useEffect } from 'react';
import Box from '@mui/material/Box';
import Container from '@mui/material/Container';
import { DataGrid } from '@mui/x-data-grid';
import GroupIcon from '@mui/icons-material/Group';
import TocIcon from '@mui/icons-material/Toc';
import RuleIcon from '@mui/icons-material/Rule';
import Button from '@mui/material/Button';
import Typography from '@mui/material/Typography';
import Skeleton from '@mui/material/Skeleton';
import { useNavigate } from 'react-router-dom';

import Search from '../../Shared/Components/Search/Search-Feature';

// ... (DataGridSkeleton remains unchanged) ...
const DataGridSkeleton = ({ rowCount = 10, columnWidths = [1, 1, 1, 1, 1, 1, 1] }) => {
  return (
    <Box sx={{ height: '70vh', width: '100%', border: '1px solid #e0e0e0', borderRadius: '4px' }}>
      <Box sx={{ display: 'flex', alignItems: 'center', height: '40px', backgroundColor: '#f5f5f5', padding: '0 16px' }}>
        {columnWidths.map((flex, index) => (
          <Skeleton key={index} variant="text" sx={{ flex, height: '20px', margin: '0 8px' }} />
        ))}
      </Box>
      {Array.from({ length: rowCount }).map((_, rowIndex) => (
        <Box
          key={rowIndex}
          sx={{
            display: 'flex',
            alignItems: 'center',
            height: '50px',
            padding: '0 16px',
            borderBottom: '1px solid #e0e0e0',
          }}
        >
          {columnWidths.map((flex, colIndex) => (
            <Skeleton
              key={colIndex}
              variant="text"
              width="80%"
              height="20px"
              sx={{ flex, margin: '0 8px' }}
            />
          ))}
        </Box>
      ))}
    </Box>
  );
};


function Groups() {
  const navigate = useNavigate();
  const [groups, setGroups] = useState([]);
  const [totalGroups, setTotalGroups] = useState(0);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [paginationModel, setPaginationModel] = useState({
    page: 0,
    pageSize: 10,
  });
  const [searchTerm, setSearchTerm] = useState('');
  const [isProcessing, setIsProcessing] = useState({});

  const userData = JSON.parse(sessionStorage.getItem("userData")) || {};
  const userId = userData.userId;
  // 1. ADD: Determine if the user is an approver. 
  // We assume 'subscribedGroups' contains 'Approvers' if the user is a member.
  const isUserApprover = userData.subscribedGroups?.includes('Approvers') || false;

  const navigateTOCreateGroup = () => {
    navigate('/groups/create');
  };

  const fetchGroups = async () => {
    setLoading(true);
    setError(null);
    try {
      const url = new URL(`${import.meta.env.VITE_API_URL}/api/groups`, window.location.origin);
      url.searchParams.append('page', paginationModel.page + 1);
      url.searchParams.append('limit', paginationModel.pageSize);

      if (userId) {
        url.searchParams.append('user_id', userId);
      }

      const response = await fetch(url.toString());
      if (!response.ok) {
        // FIX: read the backend's actual error body -- it returns
        // {"error": "<real reason>"} on failure, but this was being
        // discarded in favor of a generic message that hid the cause on
        // every single failure.
        let detail = `HTTP ${response.status}`;
        try {
          const errBody = await response.json();
          if (errBody?.error) detail = errBody.error;
        } catch (_) { /* body wasn't JSON, keep the status-only detail */ }
        throw new Error(`Failed to fetch groups: ${detail}`);
      }

      const data = await response.json();
      const totalGroupsFromData = data.length > 0 ? parseInt(data[0].total_groups, 10) : 0;

      const formattedData = data.map((group) => {
        const isSubscribed = group.subscription_status === 'true';
        return {
          id: group.group_name,
          rulesCount: group.rules || 0,
          groupName: group.group_name,
          groupSize: parseInt(group.group_size, 10),
          tableCount: group.tables || 0,
          owner: group.owner,
          subscription: isSubscribed ? 'Unsubscribe' : 'Subscribe',
          createdAt: group.created_at.split('T')[0],
          groupId: group.group_id,
          subscription_status: isSubscribed,
        };
      });

      setGroups(formattedData);
      setTotalGroups(totalGroupsFromData);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchGroups();
  }, [paginationModel, userId]);

  const handleSubscriptionChange = async (groupId, isSubscribed, groupName) => {
    // 3. ADD: Prevent subscription/unsubscription if group is 'Approvers' AND user is not an Approver
    if (groupName === 'Approvers' && !isUserApprover) {
      alert("You are not authorized to manage subscriptions for the 'Approvers' group.");
      return;
    }

    if (!userId) {
      console.error("User not authenticated. Cannot perform action.");
      return;
    }

    setIsProcessing({ ...isProcessing, [groupId]: true });

    const endpoint = isSubscribed
      ? `${import.meta.env.VITE_API_URL}/api/groups/${groupId}/remove_members`
      : `${import.meta.env.VITE_API_URL}/api/groups/${groupId}/add_members`;

    try {
      const res = await fetch(endpoint, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ user_ids: [userId] }),
      });

      if (!res.ok) {
        throw new Error(`Failed to update subscription: ${res.statusText}`);
      }

      const groupToUpdate = groups.find(group => group.groupId === groupId);

      const updatedGroups = groups.map((group) =>
        group.groupId === groupId
          ? {
              ...group,
              subscription: isSubscribed ? 'Subscribe' : 'Unsubscribe',
              subscription_status: !isSubscribed,
            }
          : group
      );
      setGroups(updatedGroups);

      const storedUserData = JSON.parse(sessionStorage.getItem("userData"));
      if (storedUserData && groupToUpdate) {
        let updatedSubscribedGroups;
        if (isSubscribed) {
          updatedSubscribedGroups = storedUserData.subscribedGroups.filter(
            (name) => name !== groupToUpdate.groupName
          );
        } else {
          updatedSubscribedGroups = [...storedUserData.subscribedGroups, groupToUpdate.groupName];
        }

        const newUserData = {
          ...storedUserData,
          subscribedGroups: updatedSubscribedGroups,
        };
        sessionStorage.setItem("userData", JSON.stringify(newUserData));
      }

    } catch (err) {
      console.error("Error updating subscription:", err);
    } finally {
      setIsProcessing({ ...isProcessing, [groupId]: false });
    }
  };

  const columns = [
    // {
    //   field: 'groupName',
    //   headerName: 'Group',
    //   flex: 1,
    //   renderCell: (params) => (
    //     <Box sx={{ color: '#102a44ff' }}>
    //       <Box
    //         sx={{ cursor: 'pointer', width: 'fit-content', '&:hover': { textDecoration: 'underline' } }}
    //         onClick={() => navigate(`/groups/${params.row.groupId}`, { state: { groupName: params.row.groupName } })}
    //       >
    //         {params.value}
    //       </Box>
    //     </Box>
    //   ),
    // },
    {
      field: 'groupName',
      headerName: 'Group',
      flex: 1,
      renderCell: (params) => (
        <Box sx={{ color: '#102a44ff' }}>
          <Box
            sx={{ cursor: 'pointer', width: 'fit-content', '&:hover': { textDecoration: 'underline' } }}
            onClick={() => navigate(`/groups/${params.row.groupId}`, { state: { groupName: params.row.groupName } })}
          >
            {params.value
              .replace(/([A-Z])/g, ' $1')
              .toLowerCase()
              .replace(/\b\w/g, char => char.toUpperCase())
              .trim()
            }
          </Box>
        </Box>
      ),
    },
    {
      field: 'groupSize',
      headerName: 'Group Size',
      type: 'number',
      minWidth: 10,
      align: 'left',
      headerAlign: 'left',
      renderCell: (params) => (
        <Box
          sx={{ display: 'flex', alignItems: 'center', gap: '8px', cursor: 'pointer', '&:hover': { color: 'blue' } }}
          onClick={() => navigate(`/groups/${params.row.groupId}?tab=members`, { state: { groupName: params.row.groupName } })}
        >
          <GroupIcon />{params.value}
        </Box>
      ),
    },
    {
      field: 'tableCount',
      headerName: 'Tables',
      type: 'number',
      minWidth: 10,
      align: 'left',
      headerAlign: 'left',
      renderCell: (params) => (
        <Box
          sx={{ display: 'flex', alignItems: 'center', gap: '8px', cursor: 'pointer', '&:hover': { color: 'blue' } }}
          onClick={() => navigate(`/groups/${params.row.groupId}?tab=tables`, { state: { groupName: params.row.groupName } })}
        >
          <TocIcon />{params.value}
        </Box>
      ),
    },
    {
      field: 'rulesCount',
      headerName: 'Rules',
      type: 'number',
      minWidth: 10,
      align: 'left',
      headerAlign: 'left',
      renderCell: (params) => {
        const isSubscribed = params.row.subscription_status;

        const handleClick = () => {
          if (!isSubscribed) {
            alert('You must subscribe to this group to view its rules.');
            return;
          }

          // ✅ Read current session storage
          const storedUserData = JSON.parse(sessionStorage.getItem("userData")) || {};

          // ✅ Overwrite selected group and group ID
          const updatedUserData = {
            ...storedUserData,
            selectedGroup: params.row.groupName,     // Overwrite selected group name
            selectedGroupId: params.row.groupId,     // Overwrite selected group ID
          };

          // ✅ Save back to session storage
          sessionStorage.setItem("userData", JSON.stringify(updatedUserData));

          // ✅ Navigate to rule management page
          navigate('/rule-management');
        };

        return (
          <Box
            sx={{
              display: 'flex',
              alignItems: 'center',
              gap: '8px',
              cursor: isSubscribed ? 'pointer' : 'not-allowed',
              color: isSubscribed ? 'inherit' : 'grey',
              '&:hover': {
                color: isSubscribed ? 'blue' : 'grey',
              },
            }}
            onClick={handleClick}
          >
            <RuleIcon />{params.value}
          </Box>
        );
      },
    },

    {
      field: 'owner',
      headerName: 'Owner',
      flex: 1
    },
    {
      field: 'createdAt',
      headerName: 'Created At',
      flex: 1
    },
    {
      field: 'subscription',
      headerName: 'Subscription',
      flex: 1,
      renderCell: (params) => {
        const isSubscribed = params.row.subscription_status;
        const isCurrentlyProcessing = isProcessing[params.row.groupId];
        const isApproversGroup = params.row.groupName === 'Approvers';

        // 3. ADD: Disable condition: 
        // If it's the 'Approvers' group, and the user is NOT already subscribed (i.e., !isSubscribed), 
        // and the user is NOT an Approver (i.e., !isUserApprover), disable the button.
        const disableSubscriptionButton = 
            isCurrentlyProcessing || 
            !userId || 
            (isApproversGroup && !isSubscribed && !isUserApprover);


        return (
          <Box sx={{ display: 'flex', alignContent: 'center' }}>
            <Button
              size="small"
              color={isSubscribed ? "error" : "success"}
              sx={{
                ...(isCurrentlyProcessing && {
                  color: 'text.disabled',
                  borderColor: 'grey.300',
                  backgroundColor: 'grey.100',
                  '&:hover': {
                    backgroundColor: 'grey.100',
                    cursor: 'default',
                  }
                }),
              }}
              // 3. UPDATE: Pass groupName to handleSubscriptionChange for conditional logic
              onClick={() => handleSubscriptionChange(params.row.groupId, isSubscribed, params.row.groupName)}
              disabled={disableSubscriptionButton}
            >
              {params.value}
            </Button>
          </Box>
        );
      },
    },
  ];

  const filteredGroups = useMemo(() => {
    if (!searchTerm) return groups;
    const normalizedSearch = searchTerm.toLowerCase();
    return groups.filter((group) =>
      group.groupName.toLowerCase().includes(normalizedSearch) ||
      group.owner.toLowerCase().includes(normalizedSearch)
    );
  }, [groups, searchTerm]);

  return (
    <Box>
      <Container maxWidth="lg">
        <Box sx={{ mt: 2, mb: 2, display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 1 }}>
          <Typography variant="h6">Groups</Typography>
          
          {/* 2. ADD: Conditional rendering for Create Group button */}
            <Box sx={{ display: 'flex', alignContent: 'center', gap: 1 }}>
              <Button
                variant="outlined"
                color="secondary"
                size='small'
                sx={{
                  color: '#29537cff',
                  borderColor: '#29537cff',
                  fontWeight: 'bold',
                  '&:hover': {
                    backgroundColor: '#f7f7faff',
                    borderColor: '#102a44ff'
                  }
                }}
                onClick={navigateTOCreateGroup}
                disabled={!isUserApprover} 


              >
                Create Group

              </Button>
            </Box>
          

        </Box>
        <Box sx={{ display: 'flex', justifyContent: 'space-between', height: '100%', width: '100%' }}>
          <Search
            placeholder="Search "
            searchTerm={searchTerm}
            setSearchTerm={setSearchTerm}
            onSearch={setSearchTerm}
            width={500}
          />
          <Box sx={{ display: 'flex', alignItems: 'center' }}>
            <Typography variant="subtitle2" gutterBottom>
              Total Groups : <b>{filteredGroups.length}</b>
            </Typography>
          </Box>
        </Box>
        <Box sx={{ mt: 1, height: '100%', width: '100%' }}>
          {loading ? (
            <DataGridSkeleton rowCount={paginationModel.pageSize} columnWidths={[1, 1, 1, 1, 1, 1, 1]} />
          ) : error ? (
            <Typography color="error" sx={{ textAlign: 'center', mt: 4 }}>
              Error: {error}
            </Typography>
          ) : (
            <DataGrid
              sx={{
                height: '70vh',
                border: 'none',
                width: '100%',
                '& .MuiDataGrid-row:hover': { backgroundColor: '#f7f7faff' },
                '& .MuiDataGrid-columnHeaders': { backgroundColor: 'black', height: '40px' },
                '& .MuiDataGrid-cell[data-field="subscription"]': { alignContent: 'center' },

                // Footer adjustments
                '& .MuiDataGrid-footerContainer': {
                  display: 'flex',
                  justifyContent: 'flex-end',
                  padding: '0 8px', 
                },
                '& .MuiTablePagination-root': {
                  display: 'flex',
                  justifyContent: 'flex-end',
                  gap: '4px',
                  minHeight: '36px',
                  padding: 0,
                },
                '& .MuiTablePagination-actions': {
                  margin: 0, 
                },
                '& .MuiTablePagination-selectLabel, & .MuiTablePagination-select': {
                  margin: 0, 
                  padding: 0,
                },
                '& .MuiTablePagination-displayedRows': {
                  display: 'none', 
                  margin: 0,
                },
              }}
              rowHeight={50}
              rows={filteredGroups}
              rowCount={filteredGroups.length}
              columns={columns}
              pagination
              paginationMode="client"
              paginationModel={paginationModel}
              onPaginationModelChange={setPaginationModel}
              pageSizeOptions={[10, 20, 50]}
              disableRowSelectionOnClick
            />
          )}
        </Box>
      </Container>
    </Box>
  );
}

export default Groups;
