import React, { useState, useEffect,useMemo,useCallback, useRef } from 'react';
import RuleCard from '../../components/rule-card/RuleCard';
import MuiPagination from '../../../Shared/Components/Pagination/Pagination';
import {
  Box,
  Button,
  Typography,
  Container,
  CircularProgress,
  Skeleton,
  Stack,
  Popover,
  TextField,
  Checkbox,
  FormControlLabel,
  InputAdornment,
} from '@mui/material';
import SearchIcon from '@mui/icons-material/Search';
import Search from '../../../Shared/Components/Search/Search-Feature';
import { ruleManagementApi } from "../../../../services/ruleManagementApi";
import ArrowDropDownIcon from '@mui/icons-material/ArrowDropDown';

const CONTROL_H = 35;

const RuleManagement = () => {
 
  const [searchTerm, setSearchTerm] = useState('');
  const [debouncedSearchTerm, setDebouncedSearchTerm] = useState('');

  useEffect(() => {
    const timer = setTimeout(() => {
      setDebouncedSearchTerm(searchTerm);
    }, 300);
   
    return () => clearTimeout(timer);
  }, [searchTerm]);

  const [openFilter, setOpenFilter] = useState(null);
  const [rules, setRules] = useState([]);
 
  const [loading, setLoading] = useState(false);
  const [filtersLoading, setFiltersLoading] = useState(true);

  // NEW: Subscription check states
  const [hasSubscribedGroups, setHasSubscribedGroups] = useState(true);
  const [checkingSubscription, setCheckingSubscription] = useState(true);

  // Filter search states
  const [schemaSearch, setSchemaSearch] = useState('');
  const [tableSearch, setTableSearch] = useState('');

  const [filterOptions, setFilterOptions] = useState({
    rule_types: [],
    severities: [],
    statuses: [],
    schemas: [],
  });

  const [selectedSchema, setSelectedSchema] = useState([]);
  const [selectedTables, setSelectedTables] = useState([]);

  const [expandedTableId, setExpandedTableId] = useState(null);
  const [approvedRulesData, setApprovedRulesData] = useState({});
  const [loadingApprovedRules, setLoadingApprovedRules] = useState({});

  const conditionTypes = filterOptions.rule_types;
  const severityTypes = filterOptions.severities;
  const approvalStatus = filterOptions.statuses;
  const schemas = filterOptions.schemas;

  const tables = useMemo(() =>
  rules.length > 0 ? [...new Set(rules.map(rule => rule.table_name))].filter(Boolean) : [],
  [rules]
);

  const toggleTable   = (o) => setSelectedTables(p => p.includes(o) ? p.filter(x=>x!==o) : [...p,o]);
  const toggleSchema  = (o) => setSelectedSchema(p => p.includes(o) ? p.filter(x=>x!==o) : [...p,o]);

  const clearAllFilters = () => {
    setSelectedSchema([]);  setSelectedTables([]);
  };

  // Filter options with search and sorting
  const getFilteredAndSortedOptions = (options, selected, searchTerm) => {
    const filtered = options.filter(option =>
      option.toLowerCase().includes(searchTerm.toLowerCase())
    );
   
    return filtered.sort((a, b) => {
      const aSelected = selected.includes(a);
      const bSelected = selected.includes(b);
     
      if (aSelected && !bSelected) return -1;
      if (!aSelected && bSelected) return 1;
      return a.localeCompare(b);
    });
  };

  // Display text for filter buttons
  const getDisplayText = (label, selected) => {
    if (selected.length === 0) return label;
    if (selected.length <= 2) {
      return selected.join(', ');
    }
    return `${selected.length} selected`;
  };

  // Filter component
  const FilterDropdown = ({ label, options, selected, onToggle, searchValue, onSearchChange }) => {
    const isOpen = openFilter === label;
    const dropdownRef = useRef(null);

    useEffect(() => {
      const handleClickOutside = (event) => {
        if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
          handleClose();
        }
      };

      if (isOpen) {
        document.addEventListener('mousedown', handleClickOutside);
      }

      return () => {
        document.removeEventListener('mousedown', handleClickOutside);
      };
    }, [isOpen]);

    const handleClick = (event) => {
      setOpenFilter(openFilter === label ? null : label);
    };

    const handleClose = () => {
      setOpenFilter(null);
      onSearchChange('');
    };

    const handleSearchChange = (e) => {
      e.stopPropagation();
      onSearchChange(e.target.value);
    };

    const handleToggle = (option) => {
      onToggle(option);
    };

    const filteredOptions = getFilteredAndSortedOptions(options, selected, searchValue);

    return (
     <Box ref={dropdownRef} sx={{ position: 'relative' }}>
        <Button
          className="filter-btn"
          onClick={handleClick}
          sx={{
            textTransform: 'none',
            fontWeight: 400,
            justifyContent: 'space-between',
            padding: '6px 12px',
            borderRadius: '4px',
            border: '1px solid rgba(0, 0, 0, 0.23)',
            backgroundColor: selected.length > 0 ? '#e3f2fd' : '#fff',
            color: selected.length > 0 ? '#1976d2' : '#333',
            '&:hover': {
              backgroundColor: selected.length > 0 ? '#bbdefb' : '#f5f5f5',
            },
            minWidth: '125px',
            maxWidth: '200px',
            overflow: 'hidden',
            whiteSpace: 'nowrap',
            textOverflow: 'ellipsis',
          }}
        >
          <span style={{ overflow: 'hidden', textOverflow: 'ellipsis' }}>
            {getDisplayText(label, selected)}
          </span>
          <ArrowDropDownIcon sx={{ fontSize: 18, ml: 0.5 }} />
        </Button>

        {isOpen && (
          <Box
            sx={{
              position: 'absolute',
              top: '100%',
              left: 0,
              zIndex: 1000,
              mt: 0.5,
              width: '125px',
              maxHeight: '280px',
              backgroundColor: 'white',
              border: '1px solid #d0d0d0',
              borderRadius: '6px',
              boxShadow: '0px 4px 16px rgba(0, 0, 0, 0.08)',
              p: 1,
            }}
          >
            {/* Search Input */}
            <TextField
              autoFocus
              size="small"
              placeholder="Search..."
              value={searchValue}
              onChange={handleSearchChange}
              onKeyDown={(e) => e.stopPropagation()}
              sx={{
                width: '100%',
                mb: 1,
                '& .MuiOutlinedInput-root': {
                  height: '28px',
                  fontSize: '0.75rem',
                  borderRadius: '4px',
                  backgroundColor: '#f8f9fa',
                  border: '1px solid #e9ecef',
                  '&:hover': {
                    borderColor: '#ced4da',
                  },
                  '&.Mui-focused': {
                    borderColor: '#1976d2',
                    backgroundColor: 'white',
                  },
                },
                '& .MuiOutlinedInput-input': {
                  padding: '4px 8px',
                }
              }}
              InputProps={{
                startAdornment: (
                  <InputAdornment position="start">
                    <SearchIcon sx={{ fontSize: '14px', color: '#6c757d' }} />
                  </InputAdornment>
                ),
              }}
            />

            {/* Options List */}
            <Box sx={{ maxHeight: 180, overflowY: 'auto' }}>
              {filteredOptions.length === 0 ? (
                <Typography variant="body2" sx={{ p: 1, color: '#6c757d', fontSize: '0.75rem', textAlign: 'center' }}>
                  No options
                </Typography>
              ) : (
                filteredOptions.map((option) => (
                  <FormControlLabel
                    key={option}
                    control={
                      <Checkbox
                        checked={selected.includes(option)}
                        onChange={() => handleToggle(option)}
                        size="small"
                        sx={{
                          padding: '4px',
                          '& .MuiSvgIcon-root': {
                            fontSize: '16px',
                            color: selected.includes(option) ? '#1976d2' : '#6c757d'
                          }
                        }}
                      />
                    }
                    label={option}
                    sx={{
                      display: 'flex',
                      width: '100%',
                      margin: 0,
                      padding: '4px 6px',
                      borderRadius: '4px',
                      cursor: 'pointer',
                      transition: 'all 0.15s ease',
                      '&:hover': {
                        backgroundColor: '#f8f9fa',
                      },
                      '& .MuiFormControlLabel-label': {
                        fontSize: '0.8rem',
                        overflow: 'hidden',
                        textOverflow: 'ellipsis',
                        whiteSpace: 'nowrap',
                        lineHeight: 1.3,
                        color: selected.includes(option) ? '#1976d2' : '#495057',
                        fontWeight: selected.includes(option) ? 500 : 400,
                      },
                      backgroundColor: selected.includes(option)
                        ? 'rgba(25, 118, 210, 0.04)'
                        : 'transparent',
                      borderLeft: selected.includes(option) ? '2px solid #1976d2' : '2px solid transparent',
                    }}
                  />
                ))
              )}
            </Box>

            {/* Clear All Button */}
            {selected.length > 0 && (
              <Box sx={{ mt: 1, pt: 1, borderTop: '1px solid #e9ecef' }}>
                <Button
                  size="small"
                  onClick={() => {
                    selected.forEach(option => handleToggle(option));
                  }}
                  sx={{
                    textTransform: 'none',
                    fontSize: '0.7rem',
                    minHeight: '24px',
                    padding: '2px 8px',
                    borderRadius: '4px',
                    color: '#6c757d',
                    '&:hover': {
                      backgroundColor: '#f8f9fa',
                      color: '#495057',
                    },
                  }}
                >
                  Clear All
                </Button>
              </Box>
            )}
          </Box>
        )}
      </Box>
    );
  };

  const handleViewApprovedRules = async (tableId) => {
 
  if (expandedTableId === tableId) {
    setExpandedTableId(null);
    return;
  }

  setExpandedTableId(tableId);

  if (approvedRulesData[tableId]) return;

  try {
    console.log('Fetching approved rules for table ID:', tableId);
    const approvedRules = await ruleManagementApi.getApprovedRules(tableId);
    setApprovedRulesData(prev => ({ ...prev, [tableId]: approvedRules }));
  } catch (error) {
    console.error('Failed to fetch approved rules:', error);
    setApprovedRulesData(prev => ({ ...prev, [tableId]: [] }));
  }
};

  const PAGE_SIZE = 20;
  const [currentPage, setCurrentPage] = useState(1);
  const paginatedTables = useMemo(
    () => tables.slice((currentPage - 1) * PAGE_SIZE, currentPage * PAGE_SIZE),
    [tables, currentPage]
  );
  const totalPages = Math.max(1, Math.ceil(tables.length / PAGE_SIZE));

 // UPDATED: Initial parallel load with subscription check
useEffect(() => {
  const loadAllData = async () => {
    try {
      setFiltersLoading(true);
      setLoading(true);
      setCheckingSubscription(true);
     
      console.time('🚀 Parallel API Load');
     
      // Load all three APIs at the same time
      const [filterOptions, tablesData, subscribedGroups] = await Promise.all([
        ruleManagementApi.getFilterOptions(),
        ruleManagementApi.getTablesData({}),
        ruleManagementApi.getSubscribedGroups().catch((err) => {
          console.error('Error fetching subscribed groups:', err);
          return [];
        })
      ]);
     
      console.timeEnd('🚀 Parallel API Load');
     
      // Check if user has subscribed groups
      const hasGroups = subscribedGroups && subscribedGroups.length > 0;
      setHasSubscribedGroups(hasGroups);
     
      console.log('📊 Subscribed groups:', subscribedGroups);
      console.log('✅ Has subscribed groups:', hasGroups);
     
      // Quick cleaning function
      const cleanArray = (arr) => [...new Set((arr || []).filter(Boolean).map(item => item.trim()).filter(item => item.length > 0))];
     
      const cleanData = {
        rule_types: cleanArray(filterOptions.rule_types),
        severities: cleanArray(filterOptions.severities),
        statuses: cleanArray(filterOptions.statuses),
        schemas: cleanArray(filterOptions.schemas),
      };
     
      setFilterOptions(cleanData);
      setRules(hasGroups ? (tablesData || []) : []); // Only set rules if user has groups
     
      console.log('✅ Data loaded:', { 
        filters: cleanData, 
        tablesCount: tablesData?.length,
        hasSubscribedGroups: hasGroups
      });
     
    } catch (error) {
      console.error('❌ Failed to load data:', error);
      setFilterOptions({ rule_types: [], severities: [], statuses: [], schemas: [] });
      setRules([]);
      setHasSubscribedGroups(false);
    } finally {
      setFiltersLoading(false);
      setLoading(false);
      setCheckingSubscription(false);
    }
  };

  loadAllData();
}, []);

useEffect(() => {
  if (!searchTerm.trim() || !hasSubscribedGroups) return;

  let active = true;
  const searchData = async () => {
    try {
      setLoading(true);
      const params = { search: searchTerm.trim() };
      console.time('🔍 Search API');
      const tablesData = await ruleManagementApi.getTablesData(params);
      console.timeEnd('🔍 Search API');
      if (active) setRules(tablesData || []);
    } catch (error) {
      console.error('Failed to search:', error);
      if (active) setRules([]);
    } finally {
      if (active) setLoading(false);
    }
  };

  searchData();
  return () => { active = false };
}, [searchTerm, hasSubscribedGroups]);

 
  const handleDelete = async (id) => {
    try {
      await ruleManagementApi.deleteRule(id);
     
      const params = {};
      if (searchTerm.trim()) params.search = searchTerm.trim();
      const tablesData = await ruleManagementApi.getTablesData(params);
      setRules(tablesData || []);
    } catch (error) {
      console.error('Failed to delete rule:', error);
    }
  };

  const filteredRules = useMemo(() => {
  return rules.filter((tableData) => {
   
    if (selectedTables.length > 0 && !selectedTables.includes(tableData.table_name)) {
      return false;
    }

    if (selectedSchema.length > 0 && !selectedSchema.includes(tableData.schema_name)) {
      return false;
    }
   
    return true;
  });
}, [rules, selectedTables, selectedSchema]);

  // NEW: Checking subscription loading state
  if (checkingSubscription) {
    return (
      <Container maxWidth="lg" sx={{ py: 2 }}>
        <Typography variant="h6" mb={1.5}>Defined Rules</Typography>
        <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', minHeight: '60vh' }}>
          <CircularProgress />
        </Box>
      </Container>
    );
  }

  // NEW: Show "not subscribed" message if user has no subscribed groups
  if (!hasSubscribedGroups) {
    return (
      <Container maxWidth="lg" sx={{ py: 2 }}>
        <Typography variant="h6" mb={1.5}>Defined Rules</Typography>
        
        <Box 
          sx={{ 
            display: 'flex', 
            flexDirection: 'column',
            justifyContent: 'center', 
            alignItems: 'center', 
            minHeight: '60vh',
            textAlign: 'center',
            gap: 2
          }}
        >
          <Typography variant="h5" color="text.secondary" fontWeight={500}>
            You are not subscribed to any group
          </Typography>
          <Typography variant="body1" color="text.secondary" sx={{ maxWidth: 500 }}>
            To view and manage rules, you need to subscribe to at least one group. 
            Please navigate to the Groups page to subscribe to a group.
          </Typography>
          <Button
            variant="contained"
            onClick={() => window.location.href = '/groups'}
            sx={{ mt: 2, textTransform: 'none' }}
          >
            Go to Groups
          </Button>
        </Box>
      </Container>
    );
  }
 
  if (filtersLoading) {
  return (
    <Container maxWidth="lg" sx={{ py: 2 }}>
      <Typography variant="h6" mb={1.5}>Defined Rules</Typography>
     
      {/* Search and Filter Skeletons */}
      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 2, flexWrap: 'nowrap' }}>
        <Skeleton variant="rectangular" width={264} height={35} sx={{ borderRadius: 1 }} />
        <Skeleton variant="rectangular" width={125} height={35} sx={{ borderRadius: 1 }} />
        <Skeleton variant="rectangular" width={125} height={35} sx={{ borderRadius: 1 }} />
        <Skeleton variant="rectangular" width={70} height={35} sx={{ borderRadius: 1 }} />
      </Box>

      {/* Content Skeletons */}
      <Stack spacing={2} sx={{ mt: 2 }}>
        {[...Array(3)].map((_, index) => (
          <Box key={index} sx={{ p: 2, border: '1px solid #e0e0e0', borderRadius: 1 }}>
            <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 2 }}>
              <Skeleton variant="text" width={200} height={24} />
              <Skeleton variant="rectangular" width={100} height={32} />
            </Box>
            <Skeleton variant="text" width="60%" height={20} sx={{ mb: 1 }} />
            <Skeleton variant="text" width="80%" height={20} sx={{ mb: 2 }} />
            <Box sx={{ display: 'flex', gap: 1 }}>
              <Skeleton variant="rectangular" width={80} height={24} />
              <Skeleton variant="rectangular" width={60} height={24} />
              <Skeleton variant="rectangular" width={70} height={24} />
            </Box>
          </Box>
        ))}
      </Stack>
    </Container>
  );
}

  return (
    <Container maxWidth="lg" sx={{ py: 2 }}>
      <Typography variant="h6" mb={1.5}>Defined Rules</Typography>

      <Box
        sx={{
          display: 'flex',
          alignItems: 'center',
          gap: 1,          
          mb: 2,
          flexWrap: 'nowrap',
          width: '100%',
        }}
      >
     
        <Box sx={{ width: 264, flexShrink: 0 }}>
          <Search
            placeholder="Search Tables"
            searchTerm={searchTerm}
            setSearchTerm={setSearchTerm}
            width="100%"
            inputSx={{
              height: `${CONTROL_H}px`,
              '& .MuiInputBase-root': { height: `${CONTROL_H}px` },
              '& .MuiOutlinedInput-input': { paddingTop: '8px', paddingBottom: '8px' },
            }}
          />
        </Box>

        <Box
          sx={{
            flex: 1,
            display: 'flex',
            alignItems: 'center',
            gap: 1,
            flexWrap: 'nowrap',
            minWidth: 0,
            '& .filter-btn':
            {
            height: `${CONTROL_H}px`,
            display: 'flex',
            alignItems: 'center',
            minWidth: '125px',  
            },
          }}
        >
          <Box sx={{ whiteSpace: 'nowrap' }}>
            <FilterDropdown
              label="Schema"
              options={schemas}
              selected={selectedSchema}
              onToggle={toggleSchema}
              searchValue={schemaSearch}
              onSearchChange={setSchemaSearch}
            />
          </Box>

          <Box sx={{ whiteSpace: 'nowrap' }}>
            <FilterDropdown
              label="Table"
              options={tables}
              selected={selectedTables}
              onToggle={toggleTable}
              searchValue={tableSearch}
              onSearchChange={setTableSearch}
            />
          </Box>

          <Button
            sx={{
              textTransform: 'none',
              minWidth: '70px',
              fontWeight: 400,
              justifyContent: 'center',
              padding: '6px 12px',
              borderRadius: '4px',
              height: CONTROL_H,
              border: '1px solid rgba(0, 0, 0, 0.23)',
              backgroundColor: '#e0e0e0',
              color: '#333',
              '&:hover': {
                backgroundColor: '#616161',
                color: '#fff',
              },
              '&.Mui-disabled': {
                backgroundColor: '#f0f0f0',
                color: '#9e9e9e',
                border: '1px solid #e0e0e0',
                cursor: 'not-allowed',
              },
            }}
            onClick={clearAllFilters}
            disabled={
              selectedSchema.length === 0 &&
              selectedTables.length === 0
            }
          >
            Reset
          </Button>
        </Box>
      </Box>

       <Box sx={{ minHeight: '55vh' }}>
        {loading ? (
          <Stack spacing={2}>
            {[...Array(3)].map((_, index) => (
              <Box key={index} sx={{ p: 2, border: '1px solid #e0e0e0', borderRadius: 1 }}>
                <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 2 }}>
                  <Skeleton variant="text" width={200} height={24} />
                  <Skeleton variant="rectangular" width={100} height={32} />
                </Box>
                <Skeleton variant="text" width="60%" height={20} sx={{ mb: 1 }} />
                <Skeleton variant="text" width="80%" height={20} sx={{ mb: 2 }} />
                <Box sx={{ display: 'flex', gap: 1 }}>
                  <Skeleton variant="rectangular" width={80} height={24} />
                  <Skeleton variant="rectangular" width={60} height={24} />
                  <Skeleton variant="rectangular" width={70} height={24} />
                </Box>
              </Box>
            ))}
          </Stack>
        ) : (
          <RuleCard
            rulesData={filteredRules}  
            onDelete={handleDelete}
            onViewApprovedRules={handleViewApprovedRules}
            expandedTableId={expandedTableId}
            setExpandedTableId={expandedTableId}
            approvedRulesData={approvedRulesData}
            loadingApprovedRules={loadingApprovedRules}
          />
        )}
      </Box>

      <Box sx={{ display: 'flex', justifyContent: 'center', mt: 3 }}>
        <MuiPagination
          currentPage={currentPage}
          totalPages={totalPages}
          onPageChange={setCurrentPage}
        />
      </Box>
    </Container>
  );
};

export default RuleManagement;