import React, { useState, useEffect } from 'react';
import {
  Box,
  Card,
  CardContent,
  Typography,
  Chip,
  Stack,
  IconButton,
  Grid,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogContentText,
  DialogActions,
  Button,
  CircularProgress,
  Skeleton,
} from '@mui/material';
import { useNavigate } from 'react-router-dom';

import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import CancelIcon from '@mui/icons-material/Cancel';
import HourglassEmptyIcon from '@mui/icons-material/HourglassEmpty';
import CloseIcon from '@mui/icons-material/Close';
import TableChartIcon from '@mui/icons-material/TableChart';
import MuiPagination from '../../../Shared/Components/Pagination/Pagination';

const CARD_SX = {
  width: '100%',
  maxWidth: '100%',
  boxShadow: 4,
  borderRadius: 2,
  transition: 'box-shadow 0.3s ease',
  '&:hover': { boxShadow: 3 },
  overflow: 'hidden',
  boxSizing: 'border-box',
};

const TITLE_SX = {
  color: '#1e3a8a',
  m: 0,
  p: 0,
};

const severityColors = {
  Critical: '#d32f2f',
  Warning: '#f57c00',
  Info: '#1976d2',
  Low: '#388e3c',
};

const renderStatusChip = (status) => {
  const s = status?.toLowerCase();
  if (s === 'approved') {
    return (
      <Chip
        size="small"
        icon={<CheckCircleIcon sx={{ color: 'green !important' }} />}
        label="Approved"
        variant="outlined"
        sx={{
          fontWeight: 'bold',
          fontSize: '11px',
          height: '22px',
          borderColor: 'green',
          color: 'green',
          '& .MuiChip-icon': { color: 'green !important' },
        }}
      />
    );
  }
  if (s === 'rejected') {
    return (
      <Chip
        size="small"
        icon={<CancelIcon sx={{ color: 'red !important' }} />}
        label="Rejected"
        variant="outlined"
        sx={{
          fontWeight: 'bold',
          fontSize: '11px',
          height: '22px',
          borderColor: 'red',
          color: 'red',
          '& .MuiChip-icon': { color: 'red !important' },
        }}
      />
    );
  }
  return (
    <Chip
      size="small"
      icon={<HourglassEmptyIcon sx={{ color: '#d97706 !important' }} />}
      label="Pending"
      variant="outlined"
      sx={{
        fontWeight: 'bold',
        fontSize: '11px',
        height: '22px',
        borderColor: '#d97706',
        color: '#d97706',
        '& .MuiChip-icon': { color: '#d97706 !important' },
      }}
    />
  );
};

const renderOperationChip = (operation) => {
  if (!operation) return null;

  let label = '';
  let color = '';

  switch (operation.toUpperCase()) {
    case 'CREATE':
      label = 'New';
      color = '#1976d2'; // Blue
      break;
    case 'UPDATE':
      label = 'Update';
      color = '#f57c00'; // Orange
      break;
    default:
      return null;
  }

  return (
    <Chip
      size="small"
      label={label}
      variant="filled"
      sx={{
        fontWeight: 'bold',
        fontSize: '11px',
        height: '22px',
        minWidth: '60px',
        borderRadius: '4px',
        backgroundColor: color,
        color: 'white',
      }}
    />
  );
};

// const ApprovalCard = ({ onStatusCountsChange, onTotalItemsChange, filters, pagination }) => {
//   const navigate = useNavigate();
//   const [rules, setRules] = useState([]);
//   const [loading, setLoading] = useState(true);
//   const [openRejectDialog, setOpenRejectDialog] = useState(false);
//   const [selectedRuleId, setSelectedRuleId] = useState(null);
//   const [rejectReason, setRejectReason] = useState('');
//   const [loadingRuleId, setLoadingRuleId] = useState(null);
//   const [selectedRuleDetails, setSelectedRuleDetails] = useState(null);

//   // New states for confirmation dialog
//   const [openConfirmDialog, setOpenConfirmDialog] = useState(false);
//   const [pendingAction, setPendingAction] = useState(null); // 'APPROVE' or 'REJECT'

//   const { searchTerm, selectedSchema, selectedTables, selectedOwner, selectedStatus, currentPage, itemsPerPage } =
//     filters;

//   const handleAction = async (id, action) => {
//     if (action !== 'APPROVED') {
//       console.log(`Action ${action} is not yet implemented.`);
//       return;
//     }
//     setLoadingRuleId(id);

//     try {
//       const endpoint = `${import.meta.env.VITE_API_URL}/api/approval/approve_rule`;
//       const userData = JSON.parse(sessionStorage.getItem('userData')) || {};
//       const approvedBy = userData.email;
//       const payload = { request_id: id, approved_by: approvedBy };

//       const response = await fetch(endpoint, {
//         method: 'POST',
//         headers: { 'Content-Type': 'application/json' },
//         body: JSON.stringify(payload),
//       });

//       if (!response.ok) {
//         const errorData = await response.json();
//         throw new Error(errorData.error || `Server error: ${response.status}`);
//       }

//       await response.json();
//       setRules((prevRules) =>
//         prevRules.map((r) => (r.request_id === id ? { ...r, status: action } : r))
//       );
      
//       // Update selectedRuleDetails if it's the same rule
//       if (selectedRuleDetails?.request_id === id) {
//         setSelectedRuleDetails(prev => ({ ...prev, status: action }));
//       }
//     } catch (error) {
//       console.error(`Failed to approve rule ID ${id}:`, error);
//     } finally {
//       setLoadingRuleId(null);
//     }
//   };

//   const handleConfirmReject = async () => {
//     if (selectedRuleId && rejectReason.trim()) {
//       setLoadingRuleId(selectedRuleId);
//       try {
//         const endpoint = `${import.meta.env.VITE_API_URL}/api/approval/reject_rule`;
//         const userData = JSON.parse(sessionStorage.getItem('userData')) || {};
//         const rejectedBy = userData.email;
//         const payload = { request_id: selectedRuleId, rejected_by: rejectedBy, reason: rejectReason };

//         const response = await fetch(endpoint, {
//           method: 'POST',
//           headers: { 'Content-Type': 'application/json' },
//           body: JSON.stringify(payload),
//         });

//         if (!response.ok) {
//           const errorData = await response.json();
//           throw new Error(errorData.error || `Server error: ${response.status}`);
//         }

//         await response.json();
//         setRules((prevRules) =>
//           prevRules.map((rule) =>
//             rule.request_id === selectedRuleId
//               ? { ...rule, status: 'REJECTED', actionBy: rejectedBy, rejectReason }
//               : rule
//           )
//         );
        
//         // Update selectedRuleDetails if it's the same rule
//         if (selectedRuleDetails?.request_id === selectedRuleId) {
//           setSelectedRuleDetails(prev => ({ 
//             ...prev, 
//             status: 'REJECTED', 
//             actionBy: rejectedBy, 
//             rejectReason 
//           }));
//         }
//       } catch (error) {
//         console.error('Failed to perform REJECT action:', error);
//       } finally {
//         setLoadingRuleId(null);
//       }
//     }
//     handleRejectDialogClose();
//   };

//   const handleRejectDialogClose = () => {
//     setOpenRejectDialog(false);
//     setRejectReason('');
//   };

//   const handleCardClick = (rule) => {
//     setSelectedRuleDetails(rule);
//   };

//   useEffect(() => {
//     const fetchRules = async () => {
//       setLoading(true);
//       try {
//         const normalizedStatus = selectedStatus.map((s) =>
//           s === 'Yet to Approve' ? 'pending' : s.toLowerCase()
//         );
//         const queryParams = new URLSearchParams();
//         if (searchTerm) queryParams.append('search', searchTerm);
//         queryParams.append('page', currentPage);
//         queryParams.append('limit', itemsPerPage);
//         selectedSchema.forEach((s) => queryParams.append('schemas', s));
//         selectedTables.forEach((t) => queryParams.append('tables', t));
//         selectedOwner.forEach((o) => queryParams.append('owners', o));
//         normalizedStatus.forEach((s) => queryParams.append('statuses', s));
//         const userData = JSON.parse(sessionStorage.getItem('userData')) || {};
//         if (userData.selectedGroupId) queryParams.append('groupId', userData.selectedGroupId);

//         const response = await fetch(`${import.meta.env.VITE_API_URL}/api/approval?${queryParams}`);
//         const data = await response.json();

//         setRules(Array.isArray(data.items) ? data.items : []);
//         onTotalItemsChange(data.totalCount || 0);

//         if (data.items && data.items.length > 0 && !selectedRuleDetails) {
//           setSelectedRuleDetails(data.items[0]);
//         }
//       } catch (error) {
//         console.error('Failed to fetch rules:', error);
//         setRules([]);
//         onTotalItemsChange(0);
//       } finally {
//         setLoading(false);
//       }
//     };
//     fetchRules();
//   }, [currentPage, itemsPerPage, searchTerm, selectedSchema, selectedTables, selectedOwner, selectedStatus, onTotalItemsChange]);

//   useEffect(() => {
//     if (rules && rules.length > 0) {
//       const pendingCount = rules.filter((r) => r.status.toLowerCase() === 'pending').length;
//       const approvedCount = rules.filter((r) => r.status.toLowerCase() === 'approved').length;
//       const rejectedCount = rules.filter((r) => r.status.toLowerCase() === 'rejected').length;
//       onStatusCountsChange({ pending: pendingCount, approved: approvedCount, rejected: rejectedCount });
//     } else {
//       onStatusCountsChange({ pending: 0, approved: 0, rejected: 0 });
//     }
//   }, [rules, onStatusCountsChange]);

 

  
//   return (
//     <Box
//       sx={{
//         width: '100%',
//         mt: 2,
//         height: '70vh',
//         display: 'grid',
//         gridTemplateColumns: selectedRuleDetails
//           ? 'minmax(0, 1fr) clamp(320px, 34%, 520px)'
//           : '1fr',
//         gap: 1,
//         overflow: 'hidden',
//         boxSizing: 'border-box',
//         position: 'relative',
//       }}
//     >
//       {/* Left Side - Cards List */}
// {/* Left Side - Cards List */}
// <Box
//   sx={{
//     gridColumn: '1 / 2',
//     minWidth: 0,
//     overflowY: 'auto',
//     overflowX: 'hidden',
//     pr: 1,
//     boxSizing: 'border-box',
//   }}
// >
//   {loading ? (
//     <Stack spacing={2}>
//       {[...Array(3)].map((_, index) => (
//         <Box key={index} sx={{ p: 2, border: '1px solid #e0e0e0', borderRadius: 1 }}>
//           <Skeleton variant="text" width={200} height={24} />
//           <Skeleton variant="text" width="60%" height={20} sx={{ mb: 1 }} />
//           <Skeleton variant="text" width="80%" height={20} sx={{ mb: 2 }} />
//         </Box>
//       ))}
//     </Stack>
//   ) : rules.length === 0 ? (
//     <Typography>No approval requests found for the selected filters.</Typography>
//   ) : (
//     rules.map((rule) => (
//       <Card
//         key={rule.request_id}
//         sx={{
//           ...CARD_SX,
//           mb: 2,
//           position: 'relative',
//           cursor: 'pointer',
//           backgroundColor:
//             selectedRuleDetails?.request_id === rule.request_id ? '#f0f8ff' : 'white',
//           border:
//             selectedRuleDetails?.request_id === rule.request_id
//               ? '2px solid #1976d2'
//               : '1px solid #e0e0e0',
//         }}
//         onClick={() => handleCardClick(rule)}
//       >
//         <CardContent sx={{ p: '8px 14px 12px 14px', position: 'relative' }}>
//           {/* Operation chip positioned at top-right of entire card */}
//           { rule.operation && rule.status?.toLowerCase() === 'pending' && (
//             <Box
//               sx={{
//                 position: 'absolute',
//                 top: 8,
//                 right: 14,
//                 zIndex: 1,
//               }}
//             >
//               {renderOperationChip(rule.operation)}
//             </Box>
//           )}
          
//           {/* Row 1: Table + chips */}
//           <Grid container spacing={1} alignItems="center" sx={{ mb: 1 }}>
//             <Grid item xs={12} sm={8} sx={{ minWidth: 0 }}>
//               <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, minWidth: 0 }}>
//                 <TableChartIcon sx={{ color: '#1e3a8a70' }} />
//                 <Typography
//                   variant="h6"
//                   sx={{ 
//                     ...TITLE_SX, 
//                     overflow: 'hidden', 
//                     textOverflow: 'ellipsis', 
//                     whiteSpace: 'nowrap',
//                     cursor: 'pointer',
//                     '&:hover': { textDecoration: 'underline' }
//                   }}
//                   onClick={(e) => {
//                     e.stopPropagation();
//                     const tableId = `${rule.catalog}-${rule.schema}-${rule.table_name}`;
//                     console.log('Navigate to table details:', tableId);
//                     navigate(`/rule-management/table/${tableId}`, {
//                       state: {
//                         tableName: rule.table_name,
//                         schemaName: `${rule.catalog}.${rule.schema}`,
//                         catalogName: rule.catalog
//                       }
//                     });
//                   }}
//                 >
//                   {rule.table_name}
//                 </Typography>
//               </Box>
//             </Grid>
//             <Grid item xs={12} sm={4} sx={{ minWidth: 0 }}>
//               <Box
//                 sx={{
//                   display: 'flex',
//                   gap: 1,
//                   flexWrap: 'wrap',
//                   justifyContent: { sm: 'flex-end', xs: 'flex-start' },
//                   overflow: 'hidden',
//                 }}
//               >
//                 {rule.condition_type && (
//                   <Chip
//                     size="small"
//                     label={rule.condition_type}
//                     variant="outlined"
//                     sx={{ fontWeight: 'bold', fontSize: '10px', borderColor: '#1976d2', color: '#1976d2' }}
//                   />
//                 )}
//                 {rule.severity && (
//                   <Chip
//                     size="small"
//                     label={rule.severity}
//                     variant="outlined"
//                     sx={{
//                       fontWeight: 'bold',
//                       fontSize: '11px',
//                       height: '22px',
//                       borderColor: severityColors[rule.severity] || '#888',
//                       color: severityColors[rule.severity] || '#888',
//                     }}
//                   />
//                 )}
//                 {rule.status && renderStatusChip(rule.status)}
//               </Box>
//             </Grid>
//           </Grid>

//           {/* Row 2: catalog.schema */}
//           <Grid container sx={{ mb: 1 }}>
//             <Grid item xs={12}>
//               <Typography variant="body2" sx={{ fontSize: 12, color: '#555', wordBreak: 'break-word' }}>
//                 {rule.catalog}.{rule.schema}
//               </Typography>
//             </Grid>
//           </Grid>

//           {/* Row 3: Column, Description, Owner - Vertical Layout */}
//           <Box sx={{ mb: 1 }}>
//             <Typography fontSize={13} sx={{ mb: 0.5, wordBreak: 'break-word' }}>
//               <b>Column:</b> {rule.column_name || 'N/A'}
//             </Typography>
//             <Typography fontSize={13} sx={{ mb: 0.5, wordBreak: 'break-word' }}>
//               <b>Description:</b> {rule.rule_description || 'N/A'}
//             </Typography>
//             <Typography fontSize={13} sx={{ wordBreak: 'break-word' }}>
//               <b>Owner:</b> {rule.created_by || 'Unknown'}
//             </Typography>
//           </Box>
//         </CardContent>
//       </Card>
//     ))
//   )}

//   {/* Pagination at bottom center of card list */}
//   <Box sx={{ display: 'flex', justifyContent: 'center', mt: 3 }}>
//     <MuiPagination
//       currentPage={pagination.currentPage}
//       totalPages={pagination.totalPages}
//       onPageChange={pagination.onPageChange}
//     />
//   </Box>
// </Box>

//       {/* Right Side - Rule Details */}
//       {selectedRuleDetails && (
//         <Box
//           sx={{
//             gridColumn: '2 / 3',
//             backgroundColor: '#f8f9fa',
//             borderRadius: 2,
//             p: 1.5,
//             display: 'flex',
//             flexDirection: 'column',
//             height: '100%',
//             maxHeight: '100%',
//             overflowY: 'auto',
//             overflowX: 'hidden',
//             minWidth: 0,
//             boxSizing: 'border-box',
//           }}
//         >
//           <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 1.5 }}>
//             <Typography variant="h6" sx={{ color: '#1e3a8a' }}>
//               {selectedRuleDetails.operation === 'CREATE'
//                 ? 'Create Rule Details'
//                 : selectedRuleDetails.operation === 'UPDATE'
//                 ? 'Update Rule Details'
//                 : 'Rule Details'}
//             </Typography>
//             <IconButton onClick={() => setSelectedRuleDetails(null)} size="small">
//               <CloseIcon />
//             </IconButton>
//           </Box>

//           <Box
//             sx={{
//               border: '1px solid #e0e0e0',
//               borderRadius: '4px',
//               p: 1.5,
//               backgroundColor: 'white',
//               mb: 1.5,
//               flex: 1,
//               overflow: 'hidden',
//               boxSizing: 'border-box',
//             }}
//           >
//             <Typography fontSize={13} sx={{ mb: 1 }}>
//               <b>Rule Name:</b> {selectedRuleDetails.condition_type}
//             </Typography>
//             <Typography fontSize={13} sx={{ mb: 1 }}>
//               <b>Condition Category:</b> {selectedRuleDetails.condition_category}
//             </Typography>
//             <Typography fontSize={13} sx={{ mb: 1 }}>
//               <b>Violation Threshold:</b> {selectedRuleDetails.violation_threshold}
//             </Typography>
//             <Typography fontSize={13} sx={{ 
//               mb: 1, 
//               wordBreak: 'break-all',
//               overflowWrap: 'break-word',
//               whiteSpace: 'pre-wrap'
//             }}>
//               <b>Condition Criteria:</b> {selectedRuleDetails.condition_criteria || 'N/A' }
//             </Typography>
//           </Box>

//           {selectedRuleDetails.status?.toLowerCase() === 'pending' && (
//             <Stack direction="row" spacing={1.5} justifyContent="flex-end">
//               <Button
//                 onClick={() => {
//                   setPendingAction('APPROVE');
//                   setOpenConfirmDialog(true);
//                 }}
//                 variant="contained"
//                 color="success"
//                 disabled={loadingRuleId === selectedRuleDetails.request_id}
//               >
//                 {loadingRuleId === selectedRuleDetails.request_id ? (
//                   <CircularProgress size={20} color="inherit" />
//                 ) : (
//                   'Approve'
//                 )}
//               </Button>
//               <Button
//                 onClick={() => {
//                   setSelectedRuleId(selectedRuleDetails.request_id);
//                   setOpenRejectDialog(true);
//                 }}
//                 variant="contained"
//                 color="error"
//                 disabled={loadingRuleId === selectedRuleDetails.request_id}
//               >
//                 Reject
//               </Button>
//             </Stack>
//           )}
//         </Box>
//       )}

//       {/* Confirm Dialog */}
//       <Dialog open={openConfirmDialog} onClose={() => setOpenConfirmDialog(false)}>
//         <DialogTitle>Confirm {pendingAction}</DialogTitle>
//         <DialogContent>
//           <DialogContentText>
//             Are you sure you want to {pendingAction === 'APPROVE' ? 'approve' : 'reject'} this rule?
//           </DialogContentText>
//         </DialogContent>
//         <DialogActions>
//           <Button onClick={() => setOpenConfirmDialog(false)}>Cancel</Button>
//           <Button
//             onClick={() => {
//               setOpenConfirmDialog(false);
//               if (pendingAction === 'APPROVE') {
//                 handleAction(selectedRuleDetails.request_id, 'APPROVED');
//               } else if (pendingAction === 'REJECT') {
//                 setSelectedRuleId(selectedRuleDetails.request_id);
//                 setOpenRejectDialog(true);
//               }
//             }}
//             variant="contained"
//             color={pendingAction === 'APPROVE' ? 'success' : 'error'}
//           >
//             Confirm
//           </Button>
//         </DialogActions>
//       </Dialog>

//       {/* Reject Reason Dialog */}
//       <Dialog
//         open={openRejectDialog}
//         onClose={handleRejectDialogClose}
//         PaperProps={{ sx: { width: 400, height: 250, p: 2 } }}
//       >
//         <DialogTitle>Reject Reason</DialogTitle>
//         <DialogContent>
//           <DialogContentText />
//           <Box mt={1}>
//             <textarea
//               value={rejectReason}
//               onChange={(e) => setRejectReason(e.target.value)}
//               placeholder="Enter reason for Rejection"
//               rows={4}
//               style={{
//                 width: '100%',
//                 padding: '18px 14px',
//                 fontSize: '0.85rem',
//                 borderRadius: '4px',
//                 border: '1px solid rgba(0, 0, 0, 0.23)',
//                 backgroundColor: '#fff',
//                 fontFamily: 'Segeo-UI, Helvetica, Arial, sans-serif',
//                 boxSizing: 'border-box',
//                 transition: 'border-color 0.2s, box-shadow 0.2s',
//                 outline: 'none',
//                 resize: 'none',
//                 lineHeight: 1.2,
//               }}
//               onFocus={(e) => {
//                 e.target.style.border = '1px solid #1976d2';
//                 e.target.style.boxShadow = '0 0 0 1px #1976d2';
//               }}
//               onBlur={(e) => {
//                 e.target.style.border = '1px solid rgba(0, 0, 0, 0.23)';
//                 e.target.style.boxShadow = 'none';
//               }}
//             />
//           </Box>
//         </DialogContent>
//         <DialogActions>
//           <Button onClick={handleRejectDialogClose}>Cancel</Button>
//           <Button
//             onClick={handleConfirmReject}
//             color="error"
//             variant="contained"
//             disabled={!rejectReason.trim() || loadingRuleId !== null}
//           >
//             {loadingRuleId !== null ? <CircularProgress size={24} color="inherit" /> : 'Reject'}
//           </Button>
//         </DialogActions>
//       </Dialog>
//     </Box>
//   );
// };

// export default ApprovalCard;

// ... (imports and helper functions remain unchanged) ...

const ApprovalCard = ({ onStatusCountsChange, onTotalItemsChange, filters, pagination }) => {
  const navigate = useNavigate();
  const [rules, setRules] = useState([]);
  const [loading, setLoading] = useState(true);
  const [openRejectDialog, setOpenRejectDialog] = useState(false);
  const [selectedRuleId, setSelectedRuleId] = useState(null);
  const [rejectReason, setRejectReason] = useState('');
  const [loadingRuleId, setLoadingRuleId] = useState(null);
  const [selectedRuleDetails, setSelectedRuleDetails] = useState(null);

  // New states for confirmation dialog
  const [openConfirmDialog, setOpenConfirmDialog] = useState(false);
  const [pendingAction, setPendingAction] = useState(null); // 'APPROVE' or 'REJECT'

  // MODIFIED DESTRUCTURING: Get groupId from filters
  const { 
    groupId, // <-- NEW: Get the mandatory groupId here
    searchTerm, 
    selectedSchema, 
    selectedTables, 
    selectedOwner, 
    selectedStatus, 
    currentPage, 
    itemsPerPage 
  } = filters;

  const handleAction = async (id, action) => {
    if (action !== 'APPROVED') {
      console.log(`Action ${action} is not yet implemented.`);
      return;
    }
    setLoadingRuleId(id);

    try {
      const endpoint = `${import.meta.env.VITE_API_URL}/api/approval/approve_rule`;
      const userData = JSON.parse(sessionStorage.getItem('userData')) || {};
      const approvedBy = userData.email;
      const payload = { request_id: id, approved_by: approvedBy };

      const response = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || `Server error: ${response.status}`);
      }

      await response.json();
      setRules((prevRules) =>
        prevRules.map((r) => (r.request_id === id ? { ...r, status: action } : r))
      );
      
      if (selectedRuleDetails?.request_id === id) {
        setSelectedRuleDetails(prev => ({ ...prev, status: action }));
      }
    } catch (error) {
      console.error(`Failed to approve rule ID ${id}:`, error);
    } finally {
      setLoadingRuleId(null);
    }
  };

  const handleConfirmReject = async () => {
    if (selectedRuleId && rejectReason.trim()) {
      setLoadingRuleId(selectedRuleId);
      try {
        const endpoint = `${import.meta.env.VITE_API_URL}/api/approval/reject_rule`;
        const userData = JSON.parse(sessionStorage.getItem('userData')) || {};
        const rejectedBy = userData.email;
        const payload = { request_id: selectedRuleId, rejected_by: rejectedBy, reason: rejectReason };

        const response = await fetch(endpoint, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload),
        });

        if (!response.ok) {
          const errorData = await response.json();
          throw new Error(errorData.error || `Server error: ${response.status}`);
        }

        await response.json();
        setRules((prevRules) =>
          prevRules.map((rule) =>
            rule.request_id === selectedRuleId
              ? { ...rule, status: 'REJECTED', actionBy: rejectedBy, rejectReason }
              : rule
          )
        );
        
        if (selectedRuleDetails?.request_id === selectedRuleId) {
          setSelectedRuleDetails(prev => ({ 
            ...prev, 
            status: 'REJECTED', 
            actionBy: rejectedBy, 
            rejectReason 
          }));
        }
      } catch (error) {
        console.error('Failed to perform REJECT action:', error);
      } finally {
        setLoadingRuleId(null);
      }
    }
    handleRejectDialogClose();
  };

  const handleRejectDialogClose = () => {
    setOpenRejectDialog(false);
    setRejectReason('');
  };

  const handleCardClick = (rule) => {
    setSelectedRuleDetails(rule);
  };

  // MODIFIED USE EFFECT
  useEffect(() => {
    // Check for groupId. If null (not yet fetched by parent), don't fetch rules.
    if (!groupId) {
        setRules([]);
        setLoading(false);
        onTotalItemsChange(0);
        return;
    }
    
    const fetchRules = async () => {
      setLoading(true);
      try {
        const normalizedStatus = selectedStatus.map((s) =>
          s === 'Yet to Approve' ? 'pending' : s.toLowerCase()
        );
        const queryParams = new URLSearchParams();
        if (searchTerm) queryParams.append('search', searchTerm);
        queryParams.append('page', currentPage);
        queryParams.append('limit', itemsPerPage);
        selectedSchema.forEach((s) => queryParams.append('schemas', s));
        selectedTables.forEach((t) => queryParams.append('tables', t));
        selectedOwner.forEach((o) => queryParams.append('owners', o));
        normalizedStatus.forEach((s) => queryParams.append('statuses', s));
        
        // KEY FIX: Use the mandatory groupId from props
        queryParams.append('groupId', groupId); 

        const response = await fetch(`${import.meta.env.VITE_API_URL}/api/approval?${queryParams}`);
        const data = await response.json();

        setRules(Array.isArray(data.items) ? data.items : []);
        onTotalItemsChange(data.totalCount || 0);

        if (data.items && data.items.length > 0 && !selectedRuleDetails) {
          setSelectedRuleDetails(data.items[0]);
        }
      } catch (error) {
        console.error('Failed to fetch rules:', error);
        setRules([]);
        onTotalItemsChange(0);
      } finally {
        setLoading(false);
      }
    };
    fetchRules();
    // Add groupId to the dependency array
  }, [groupId, currentPage, itemsPerPage, searchTerm, selectedSchema, selectedTables, selectedOwner, selectedStatus, onTotalItemsChange]);

  useEffect(() => {
    if (rules && rules.length > 0) {
      const pendingCount = rules.filter((r) => r.status.toLowerCase() === 'pending').length;
      const approvedCount = rules.filter((r) => r.status.toLowerCase() === 'approved').length;
      const rejectedCount = rules.filter((r) => r.status.toLowerCase() === 'rejected').length;
      onStatusCountsChange({ pending: pendingCount, approved: approvedCount, rejected: rejectedCount });
    } else {
      onStatusCountsChange({ pending: 0, approved: 0, rejected: 0 });
    }
  }, [rules, onStatusCountsChange]);

  

  
  return (
    <Box
      sx={{
        width: '100%',
        mt: 2,
        height: '70vh',
        display: 'grid',
        gridTemplateColumns: selectedRuleDetails
          ? 'minmax(0, 1fr) clamp(320px, 34%, 520px)'
          : '1fr',
        gap: 1,
        overflow: 'hidden',
        boxSizing: 'border-box',
        position: 'relative',
      }}
    >
      {/* Left Side - Cards List (Rendering logic remains unchanged) */}
      <Box
        sx={{
          gridColumn: '1 / 2',
          minWidth: 0,
          overflowY: 'auto',
          overflowX: 'hidden',
          pr: 1,
          boxSizing: 'border-box',
        }}
      >
        {loading ? (
          <Stack spacing={2}>
            {[...Array(3)].map((_, index) => (
              <Box key={index} sx={{ p: 2, border: '1px solid #e0e0e0', borderRadius: 1 }}>
                <Skeleton variant="text" width={200} height={24} />
                <Skeleton variant="text" width="60%" height={20} sx={{ mb: 1 }} />
                <Skeleton variant="text" width="80%" height={20} sx={{ mb: 2 }} />
              </Box>
            ))}
          </Stack>
        ) : rules.length === 0 ? (
          <Typography>No approval requests found for the selected filters.</Typography>
        ) : (
          rules.map((rule) => (
            <Card
              key={rule.request_id}
              sx={{
                ...CARD_SX,
                mb: 2,
                position: 'relative',
                cursor: 'pointer',
                backgroundColor:
                  selectedRuleDetails?.request_id === rule.request_id ? '#f0f8ff' : 'white',
                border:
                  selectedRuleDetails?.request_id === rule.request_id
                    ? '2px solid #1976d2'
                    : '1px solid #e0e0e0',
              }}
              onClick={() => handleCardClick(rule)}
            >
              <CardContent sx={{ p: '8px 14px 12px 14px', position: 'relative' }}>
                {/* Operation chip positioned at top-right of entire card */}
                { rule.operation && rule.status?.toLowerCase() === 'pending' && (
                  <Box
                    sx={{
                      position: 'absolute',
                      top: 8,
                      right: 14,
                      zIndex: 1,
                    }}
                  >
                    {renderOperationChip(rule.operation)}
                  </Box>
                )}
                
                {/* Row 1: Table + chips */}
                <Grid container spacing={1} alignItems="center" sx={{ mb: 1 }}>
                  <Grid item xs={12} sm={8} sx={{ minWidth: 0 }}>
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, minWidth: 0 }}>
                      <TableChartIcon sx={{ color: '#1e3a8a70' }} />
                      <Typography
                        variant="h6"
                        sx={{ 
                          ...TITLE_SX, 
                          overflow: 'hidden', 
                          textOverflow: 'ellipsis', 
                          whiteSpace: 'nowrap',
                          cursor: 'pointer',
                          '&:hover': { textDecoration: 'underline' }
                        }}
                        onClick={(e) => {
                          e.stopPropagation();
                          const tableId = `${rule.catalog}-${rule.schema}-${rule.table_name}`;
                          console.log('Navigate to table details:', tableId);
                          navigate(`/rule-management/table/${tableId}`, {
                            state: {
                              tableName: rule.table_name,
                              schemaName: `${rule.catalog}.${rule.schema}`,
                              catalogName: rule.catalog
                            }
                          });
                        }}
                      >
                        {rule.table_name}
                      </Typography>
                    </Box>
                  </Grid>
                  <Grid item xs={12} sm={4} sx={{ minWidth: 0 }}>
                    <Box
                      sx={{
                        display: 'flex',
                        gap: 1,
                        flexWrap: 'wrap',
                        justifyContent: { sm: 'flex-end', xs: 'flex-start' },
                        overflow: 'hidden',
                      }}
                    >
                      {rule.condition_type && (
                        <Chip
                          size="small"
                          label={rule.condition_type}
                          variant="outlined"
                          sx={{ fontWeight: 'bold', fontSize: '10px', borderColor: '#1976d2', color: '#1976d2' }}
                        />
                      )}
                      {rule.severity && (
                        <Chip
                          size="small"
                          label={rule.severity}
                          variant="outlined"
                          sx={{
                            fontWeight: 'bold',
                            fontSize: '11px',
                            height: '22px',
                            borderColor: severityColors[rule.severity] || '#888',
                            color: severityColors[rule.severity] || '#888',
                          }}
                        />
                      )}
                      {rule.status && renderStatusChip(rule.status)}
                    </Box>
                  </Grid>
                </Grid>

                {/* Row 2: catalog.schema */}
                <Grid container sx={{ mb: 1 }}>
                  <Grid item xs={12}>
                    <Typography variant="body2" sx={{ fontSize: 12, color: '#555', wordBreak: 'break-word' }}>
                      {rule.catalog}.{rule.schema}
                    </Typography>
                  </Grid>
                </Grid>

                {/* Row 3: Column, Description, Owner - Vertical Layout */}
                <Box sx={{ mb: 1 }}>
                  <Typography fontSize={13} sx={{ mb: 0.5, wordBreak: 'break-word' }}>
                    <b>Column:</b> {rule.column_name || 'N/A'}
                  </Typography>
                  <Typography fontSize={13} sx={{ mb: 0.5, wordBreak: 'break-word' }}>
                    <b>Description:</b> {rule.rule_description || 'N/A'}
                  </Typography>
                  <Typography fontSize={13} sx={{ wordBreak: 'break-word' }}>
                    <b>Owner:</b> {rule.created_by || 'Unknown'}
                  </Typography>
                </Box>
              </CardContent>
            </Card>
          ))
        )}

        {/* Pagination at bottom center of card list */}
        <Box sx={{ display: 'flex', justifyContent: 'center', mt: 3 }}>
          <MuiPagination
            currentPage={pagination.currentPage}
            totalPages={pagination.totalPages}
            onPageChange={pagination.onPageChange}
          />
        </Box>
      </Box>

      {/* Right Side - Rule Details (Rendering logic remains unchanged) */}
      {selectedRuleDetails && (
        <Box
          sx={{
            gridColumn: '2 / 3',
            backgroundColor: '#f8f9fa',
            borderRadius: 2,
            p: 1.5,
            display: 'flex',
            flexDirection: 'column',
            height: '100%',
            maxHeight: '100%',
            overflowY: 'auto',
            overflowX: 'hidden',
            minWidth: 0,
            boxSizing: 'border-box',
          }}
        >
          <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 1.5 }}>
            <Typography variant="h6" sx={{ color: '#1e3a8a' }}>
              {selectedRuleDetails.operation === 'CREATE'
                ? 'Create Rule Details'
                : selectedRuleDetails.operation === 'UPDATE'
                ? 'Update Rule Details'
                : 'Rule Details'}
            </Typography>
            <IconButton onClick={() => setSelectedRuleDetails(null)} size="small">
              <CloseIcon />
            </IconButton>
          </Box>

          <Box
            sx={{
              border: '1px solid #e0e0e0',
              borderRadius: '4px',
              p: 1.5,
              backgroundColor: 'white',
              mb: 1.5,
              flex: 1,
              overflow: 'hidden',
              boxSizing: 'border-box',
            }}
          >
            <Typography fontSize={13} sx={{ mb: 1 }}>
              <b>Rule Name:</b> {selectedRuleDetails.condition_type}
            </Typography>
            <Typography fontSize={13} sx={{ mb: 1 }}>
              <b>Condition Category:</b> {selectedRuleDetails.condition_category}
            </Typography>
            <Typography fontSize={13} sx={{ mb: 1 }}>
              <b>Violation Threshold:</b> {selectedRuleDetails.violation_threshold}
            </Typography>
            <Typography fontSize={13} sx={{ 
              mb: 1, 
              wordBreak: 'break-all',
              overflowWrap: 'break-word',
              whiteSpace: 'pre-wrap'
            }}>
              <b>Condition Criteria:</b> {selectedRuleDetails.condition_criteria || 'N/A' }
            </Typography>
          </Box>

          {selectedRuleDetails.status?.toLowerCase() === 'pending' && (
            <Stack direction="row" spacing={1.5} justifyContent="flex-end">
              <Button
                onClick={() => {
                  setPendingAction('APPROVE');
                  setOpenConfirmDialog(true);
                }}
                variant="contained"
                color="success"
                disabled={loadingRuleId === selectedRuleDetails.request_id}
              >
                {loadingRuleId === selectedRuleDetails.request_id ? (
                  <CircularProgress size={20} color="inherit" />
                ) : (
                  'Approve'
                )}
              </Button>
              <Button
                onClick={() => {
                  setSelectedRuleId(selectedRuleDetails.request_id);
                  setOpenRejectDialog(true);
                }}
                variant="contained"
                color="error"
                disabled={loadingRuleId === selectedRuleDetails.request_id}
              >
                Reject
              </Button>
            </Stack>
          )}
        </Box>
      )}

      {/* Confirm Dialog (Logic remains unchanged) */}
      <Dialog open={openConfirmDialog} onClose={() => setOpenConfirmDialog(false)}>
        <DialogTitle>Confirm {pendingAction}</DialogTitle>
        <DialogContent>
          <DialogContentText>
            Are you sure you want to {pendingAction === 'APPROVE' ? 'approve' : 'reject'} this rule?
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setOpenConfirmDialog(false)}>Cancel</Button>
          <Button
            onClick={() => {
              setOpenConfirmDialog(false);
              if (pendingAction === 'APPROVE') {
                handleAction(selectedRuleDetails.request_id, 'APPROVED');
              } else if (pendingAction === 'REJECT') {
                setSelectedRuleId(selectedRuleDetails.request_id);
                setOpenRejectDialog(true);
              }
            }}
            variant="contained"
            color={pendingAction === 'APPROVE' ? 'success' : 'error'}
          >
            Confirm
          </Button>
        </DialogActions>
      </Dialog>

      {/* Reject Reason Dialog (Logic remains unchanged) */}
      <Dialog
        open={openRejectDialog}
        onClose={handleRejectDialogClose}
        PaperProps={{ sx: { width: 400, height: 250, p: 2 } }}
      >
        <DialogTitle>Reject Reason</DialogTitle>
        <DialogContent>
          <DialogContentText />
          <Box mt={1}>
            <textarea
              value={rejectReason}
              onChange={(e) => setRejectReason(e.target.value)}
              placeholder="Enter reason for Rejection"
              rows={4}
              style={{
                width: '100%',
                padding: '18px 14px',
                fontSize: '0.85rem',
                borderRadius: '4px',
                border: '1px solid rgba(0, 0, 0, 0.23)',
                backgroundColor: '#fff',
                fontFamily: 'Segeo-UI, Helvetica, Arial, sans-serif',
                boxSizing: 'border-box',
                transition: 'border-color 0.2s, box-shadow 0.2s',
                outline: 'none',
                resize: 'none',
                lineHeight: 1.2,
              }}
              onFocus={(e) => {
                e.target.style.border = '1px solid #1976d2';
                e.target.style.boxShadow = '0 0 0 1px #1976d2';
              }}
              onBlur={(e) => {
                e.target.style.border = '1px solid rgba(0, 0, 0, 0.23)';
                e.target.style.boxShadow = 'none';
              }}
            />
          </Box>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleRejectDialogClose}>Cancel</Button>
          <Button
            onClick={handleConfirmReject}
            color="error"
            variant="contained"
            disabled={!rejectReason.trim() || loadingRuleId !== null}
          >
            {loadingRuleId !== null ? <CircularProgress size={24} color="inherit" /> : 'Reject'}
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default ApprovalCard;