import React from "react";
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  Box,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  OutlinedInput,
  Checkbox,
  ListItemText,
  TextField,
  Grid,
  CircularProgress,
  Typography,
  ToggleButton,
  ToggleButtonGroup,
  Tooltip,
  Switch,
  FormControlLabel
} from "@mui/material";
import FilterAltIcon from '@mui/icons-material/FilterAlt';
import FactCheckIcon from '@mui/icons-material/FactCheck';
import MailOutlineIcon from '@mui/icons-material/MailOutline';
import MailOffIcon from '@mui/icons-material/MailLock';
import DynamicConditionFields from "../../components/dynamic-condition-fields/DynamicConditionFields";
import { ruleManagementApi } from "../../../../services/ruleManagementApi";
import Snackbar from '@mui/material/Snackbar';
import MuiAlert from '@mui/material/Alert';

// Lightweight groups dropdown endpoint: GET /api/groups-list -> [{group_id, group_name}]
const API_GROUPS_LIST_URL = `${import.meta.env.VITE_API_URL}/api/groups-list`;

const Alert = React.forwardRef(function Alert(props, ref) {
  return <MuiAlert elevation={6} ref={ref} variant="filled" {...props} />;
});

// Map condition types back to their categories
const getConditionCategory = (conditionType) => {
  const categoryToTypes = {
    "Completeness Rules": ["NOT_NULL", "BLANK", "MUST_HAVE_VALUE", "NOT_NULL_LENGTH_CHECK"],
    "Format & Pattern Validation": ["REGEX_MATCH", "LENGTH_CHECK", "FORMAT_CHECK"],
    "Range & Threshold Rules": ["RANGE_CHECK", "VALUE_THRESHOLD", "DATE_RANGE"],
    "Uniqueness & Duplicate Checks": ["UNIQUE", "DUPLICATE"],
    "Business Logic Rules": ["CUSTOM_RULE"],
    "Consistency & Standardization Checks": ["CASE_STANDARDIZATION", "MAPPING_CHECK"],
    "Anomaly Detection": ["OUTLIER_DETECTION"],
    "Time-based Validations": ["TIME_STAMP_CHECK"],
    "Trend Analysis": ["ROW_COUNT_TREND"],
    "KPI Statistics": ["KPI_CHECK"],
  };

  for (const [category, types] of Object.entries(categoryToTypes)) {
    if (types.includes(conditionType)) {
      return category;
    }
  }
  return "";
};

const ModifyRules = ({ open, rule, allColumns, onClose, onSave, columnsLoading }) => {
  const [editedRule, setEditedRule] = React.useState(rule || {});
  const [saving, setSaving] = React.useState(false);
  const [snackbarOpen, setSnackbarOpen] = React.useState(false);
  const [snackbarMessage, setSnackbarMessage] = React.useState('');
  const [snackbarSeverity, setSnackbarSeverity] = React.useState('success');
  const [availableGroups, setAvailableGroups] = React.useState([]);
  const [loadingGroups, setLoadingGroups] = React.useState(false);

  // Load the lightweight groups list once, for the "Alert Group" dropdown.
  React.useEffect(() => {
    const fetchGroups = async () => {
      setLoadingGroups(true);
      try {
        const response = await fetch(API_GROUPS_LIST_URL);
        if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
        const data = await response.json();
        setAvailableGroups(Array.isArray(data) ? data : []);
      } catch (e) {
        console.error("Error fetching groups list:", e);
        setAvailableGroups([]);
      } finally {
        setLoadingGroups(false);
      }
    };
    fetchGroups();
  }, []);

  React.useEffect(() => {
  if (rule) {
    // Debug: Log the entire rule object to see its structure
    console.log("Full Rule object:", rule);
    console.log("All rule keys:", Object.keys(rule));
    console.log("Rule object with values:", JSON.stringify(rule, null, 2));

    console.log("Rule condition type:", rule.conditionType || rule.condition_type);
    
    // Check what column-related fields exist for MUST_HAVE_VALUE
    if ((rule.conditionType || rule.condition_type) === 'MUST_HAVE_VALUE') {
      console.log("MUST_HAVE_VALUE rule - checking column fields:");
      console.log("rule.column_name:", rule.column_name);
      console.log("rule.columns:", rule.columns);
      console.log("rule.columnName:", rule.columnName);
      console.log("rule.column:", rule.column);
    }
  

    // Try multiple possible field names for columns
    let parsedColumns = [];
    
    
      // Check all possible column field names
      if (rule.column_name) {
        console.log("Found column_name:", rule.column_name);
        parsedColumns = rule.column_name.split(",").map(col => col.trim()).filter(col => col);
      } else if (rule.columns && Array.isArray(rule.columns)) {
        console.log("Found columns array:", rule.columns);
        parsedColumns = rule.columns;
      } else if (rule.columns && typeof rule.columns === 'string') {
        console.log("Found columns string:", rule.columns);
        parsedColumns = rule.columns.split(",").map(col => col.trim()).filter(col => col);
      } else if (rule.columnName) {
        console.log("Found columnName:", rule.columnName);
        parsedColumns = rule.columnName.split(",").map(col => col.trim()).filter(col => col);
      } else if (rule.column) {
        console.log("Found column:", rule.column);
        parsedColumns = Array.isArray(rule.column) ? rule.column : rule.column.split(",").map(col => col.trim()).filter(col => col);
      }

      // Parse condition criteria - check all possible field names
      let parsedCriteria = {};
      try {
        const criteriaString = rule.condition_criteria || 
                              rule.conditionCriteria || 
                              rule.condition_criteria_json || 
                              rule.criteria || 
                              null;
        
        console.log('Raw criteria from rule:', criteriaString);
        
        if (criteriaString) {
          if (typeof criteriaString === 'string') {
            parsedCriteria = JSON.parse(criteriaString);
          } else if (typeof criteriaString === 'object') {
            parsedCriteria = criteriaString;
          }
        }
      } catch (error) {
        console.warn('Failed to parse condition criteria:', error);
        parsedCriteria = {};
      }

      // Get condition type and derive category if missing
      const conditionType = rule.conditionType || rule.condition_type || "";
      const conditionCategory = rule.conditionCategory || rule.condition_category || getConditionCategory(conditionType);

      setEditedRule({
        ...rule,
        rule_id: rule.rule_id || rule.Rule_id || rule.id,
        columns: parsedColumns,
        rule_description: rule.rule_description || rule.description || "",
        severity: rule.severity || "Warning",
        violation_threshold: rule.violation_threshold || rule.violationThreshold || "",
        conditionCriteria: parsedCriteria,
        conditionCategory: conditionCategory,
        conditionType: conditionType,
        condition_criteria: JSON.stringify(parsedCriteria, null, 2),
        enforcement_action: rule.enforcement_action || "BLOCK_AND_AUDIT",
        email_alert_enabled: (rule.email_alert_enabled ?? rule.emailAlertEnabled) !== false,
        alert_group_id: rule.alert_group_id || rule.alertGroupId || "",
      });
    }
  }, [rule]);

  const handleChange = (field, value) => {
    // If field is condition_criteria and value is an object, stringify it
    if (field === "condition_criteria" && typeof value === 'object' && value !== null) {
      value = JSON.stringify(value, null, 2);
    }
    
 
    if (field === "condition_criteria" && editedRule.condition_criteria) {
      // Check if the new value is empty (empty string, "{}", or whitespace)
      const isEmpty = !value || 
                     value === "" || 
                     value === "{}" || 
                     value.trim() === "" || 
                     value.trim() === "{}";
      
      if (isEmpty) {
        return; // Don't update with empty value
      }
    }
    
    setEditedRule({ ...editedRule, [field]: value });
  };

  const handleSnackbarClose = (event, reason) => {
    if (reason === 'clickaway') {
      return;
    }
    setSnackbarOpen(false);
  };

  const handleSave = async () => {
    if (!editedRule || !editedRule.rule_id) {
      setSnackbarMessage("Error: Rule ID is missing.");
      setSnackbarSeverity("error");
      setSnackbarOpen(true);
      return;
    }

   // Ensure conditionCriteria is properly formatted
    let criteriaToSave = editedRule.conditionCriteria || {};
    if (typeof criteriaToSave === 'string') {
      try {
        criteriaToSave = JSON.parse(criteriaToSave);
      } catch (e) {
        criteriaToSave = {};
      }
    }

    // Remove rawValue before saving (it's only for UI purposes)
    if (criteriaToSave.rawValue !== undefined) {
      const { rawValue, ...cleanCriteria } = criteriaToSave;
      criteriaToSave = cleanCriteria;
    }

    console.log("About to save - editedRule.conditionCriteria:", editedRule.conditionCriteria);
    console.log("About to save - criteriaToSave:", criteriaToSave);
    console.log("About to save - stringified:", JSON.stringify(criteriaToSave));

    const payload = {
      rule_description: editedRule.rule_description,
      severity: editedRule.severity,
      violation_threshold: editedRule.violation_threshold,
      column_name: (editedRule.columns || []).join(", "),
      condition_criteria: JSON.stringify(criteriaToSave),
      created_by: editedRule.created_by || "test_user",
      enforcement_action: editedRule.enforcement_action || "BLOCK_AND_AUDIT",
      email_alert_enabled: editedRule.email_alert_enabled !== false,
      alert_group_id: editedRule.alert_group_id || null
    };

    console.log("Full payload being sent:", payload);

    try {
      setSaving(true);
      const response = await fetch(`${import.meta.env.VITE_API_URL}/api/rules/${editedRule.rule_id}/save_request`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      const result = await response.json();
      if (response.ok) {
        setSnackbarMessage(result.message || "Rule updated successfully!");
        setSnackbarSeverity("success");
        setSnackbarOpen(true);
        onSave();
        onClose();
      } else {
        setSnackbarMessage(result.error || "Failed to update rule.");
        setSnackbarSeverity("error");
        setSnackbarOpen(true);
      }
    } catch (error) {
      setSnackbarMessage(`Error: ${error.message}`);
      setSnackbarSeverity("error");
      setSnackbarOpen(true);
    } finally {
      setSaving(false);
    }
  };

  return (
    <Box p={1}>
      <Dialog
        open={open}
        onClose={onClose}
        maxWidth={false}
        sx={{
          "& .MuiDialog-paper": {
            width: "355px",  
            maxWidth: "90%",  
          },
        }}
      >
        {/* <DialogTitle>Edit Rule - {editedRule.conditionType}</DialogTitle> */}
         <DialogTitle sx={{ 
          wordBreak: 'break-word',
          overflowWrap: 'break-word',
          whiteSpace: 'normal'
        }}>
          Edit Rule - {editedRule.conditionType}
        </DialogTitle>
        <DialogContent dividers>
          <Box display="flex" flexDirection="column" gap={2}>
            {/* Columns */}
            <Box>
              <FormControl fullWidth size="small">
                <InputLabel>Columns</InputLabel>
                <Select
                  multiple
                  value={editedRule.columns || []}
                  onChange={(e) => {
                    console.log("Selected columns:", e.target.value);
                    handleChange("columns", e.target.value);
                  }}
                  input={<OutlinedInput label="Columns" />}
                  renderValue={(selected) => {
                    console.log("Render value - selected:", selected);
                    return selected.join(", ");
                  }}
                  disabled={columnsLoading}
                >
                  {columnsLoading ? (
                    <MenuItem disabled>Loading columns...</MenuItem>
                  ) : (
                    allColumns.map((col) => {
                      const isChecked = (editedRule.columns || []).includes(col);
                      if (isChecked) {
                        console.log(`Column "${col}" should be checked`);
                      }
                      return (
                        <MenuItem key={col} value={col}>
                          <Checkbox checked={isChecked} />
                          <ListItemText primary={col} />
                        </MenuItem>
                      );
                    })
                  )}
                </Select>
              </FormControl>
            </Box>

            {/* Description */}
            <Box>
              <textarea
                value={editedRule.rule_description || ""}
                onChange={(e) => handleChange("rule_description", e.target.value)}
                placeholder="Enter Rule description"
                rows={4}
                style={{
                  width: '100%',
                  padding: '10px 14px',
                  fontSize: '0.85rem',
                  borderRadius: '4px',
                  border: '1px solid rgba(0, 0, 0, 0.23)',
                  backgroundColor: '#fff',
                  fontFamily: 'Segoe-UI, Helvetica, Arial, sans-serif',
                  boxSizing: 'border-box',
                  transition: 'border-color 0.2s, box-shadow 0.2s',
                  outline: 'none',
                  resize: 'none',
                  lineHeight: 1.2,
                }}
                onFocus={(e) => {
                  e.target.style.border = '1px solid #1976d2';
                  e.target.style.boxShadow = '0 0 0 1px #1976d2';
                }}
                onBlur={(e) => {
                  e.target.style.border = '1px solid rgba(0, 0, 0, 0.23)';
                  e.target.style.boxShadow = 'none';
                }}
              />
            </Box>

            {/* Condition Criteria Fields */}
            <Box mt={1}>
              <DynamicConditionFields
                category={editedRule.conditionCategory}
                type={editedRule.conditionType}
                columns={editedRule.columns || []}
                criteria={editedRule.conditionCriteria || {}}
                onCriteriaChange={(updated) => {
                  // Keep conditionCriteria (object) and condition_criteria (JSON
                  // string) in sync — both are read in different places in this
                  // component.
                  setEditedRule(prev => ({
                    ...prev,
                    conditionCriteria: updated,
                    condition_criteria: JSON.stringify(updated, null, 2),
                  }));
                }}
              />
            </Box>

            <Grid container spacing={2} mt={1} justifyContent={"space-between"}>
              <Grid item xs={12} md={6}>
                <Box>
                  {/* Severity */}
                  <FormControl size="small" sx={{width: 145}}>
                    <InputLabel>Severity</InputLabel>
                    <Select
                      value={editedRule.severity || ""}
                      onChange={(e) => handleChange("severity", e.target.value)}
                      label="Severity"
                    >
                      <MenuItem value="Warning">Warning</MenuItem>
                      <MenuItem value="Critical">Critical</MenuItem>
                    </Select>
                  </FormControl>
                </Box>
              </Grid>

              <Grid item xs={12} md={6}>
                <Box>
                  {/* Threshold */}
                  <TextField
                    label="Violation Threshold (%)"
                    type="number"
                    size="small"
                    value={editedRule.violation_threshold || ""}
                    onChange={(e) => handleChange("violation_threshold", e.target.value)}
                    sx={{width: 145}}
                  />
                </Box>
              </Grid>
            </Grid>

            <Box mt={2}>
              <Typography variant="caption" color="text.secondary" sx={{ display: "block", mb: 0.5 }}>
                On failure
              </Typography>
              <ToggleButtonGroup
                value={editedRule.enforcement_action || "BLOCK_AND_AUDIT"}
                exclusive
                size="small"
                fullWidth
                onChange={(event, newValue) => {
                  if (newValue) handleChange("enforcement_action", newValue);
                }}
              >
                <ToggleButton value="BLOCK_AND_AUDIT" sx={{ textTransform: "none", gap: 0.75 }}>
                  <Tooltip title="Bad records are held back from Silver and logged to dq_bad_records">
                    <Box display="flex" alignItems="center" gap={0.75}>
                      <FilterAltIcon fontSize="small" />
                      Filter & audit
                    </Box>
                  </Tooltip>
                </ToggleButton>
                <ToggleButton value="AUDIT_ONLY" sx={{ textTransform: "none", gap: 0.75 }}>
                  <Tooltip title="Bad records still move to Silver, but are also logged to dq_bad_records">
                    <Box display="flex" alignItems="center" gap={0.75}>
                      <FactCheckIcon fontSize="small" />
                      Audit only
                    </Box>
                  </Tooltip>
                </ToggleButton>
              </ToggleButtonGroup>
            </Box>

            {/* Email Alert: enable/disable per-rule email notifications, and
                optionally attach a specific group to receive them. */}
            <Box mt={2}>
              <Typography variant="caption" color="text.secondary" sx={{ display: "block", mb: 0.5 }}>
                Email Alert
              </Typography>
              <FormControlLabel
                control={
                  <Switch
                    size="small"
                    checked={editedRule.email_alert_enabled !== false}
                    onChange={(e) => handleChange("email_alert_enabled", e.target.checked)}
                  />
                }
                label={
                  <Box display="flex" alignItems="center" gap={0.5}>
                    {editedRule.email_alert_enabled !== false
                      ? <MailOutlineIcon fontSize="small" />
                      : <MailOffIcon fontSize="small" />}
                    <Typography variant="body2">
                      {editedRule.email_alert_enabled !== false ? "Alert on" : "Alert off"}
                    </Typography>
                  </Box>
                }
                sx={{ ml: 0 }}
              />

              {editedRule.email_alert_enabled !== false && (
                <Box mt={1}>
                  <FormControl fullWidth size="small">
                    <InputLabel>Alert Group (optional)</InputLabel>
                    <Select
                      value={editedRule.alert_group_id || ""}
                      onChange={(e) => handleChange("alert_group_id", e.target.value)}
                      label="Alert Group (optional)"
                      displayEmpty
                      disabled={loadingGroups}
                    >
                      <MenuItem value="">
                        <em>Default: table's approver group</em>
                      </MenuItem>
                      {availableGroups.map((g) => (
                        <MenuItem key={g.group_id} value={g.group_id}>{g.group_name}</MenuItem>
                      ))}
                    </Select>
                  </FormControl>
                </Box>
              )}
            </Box>
          </Box>
        </DialogContent>
        <DialogActions>
          <Button onClick={onClose} color="inherit" disabled={saving}>
            Cancel
          </Button>
          <Button
            onClick={handleSave}
            variant="contained"
            color="primary"
            disabled={saving}
          >
            {saving ? <CircularProgress size={20} /> : 'Save'}
          </Button>
        </DialogActions>
      </Dialog>
      <Snackbar
        open={snackbarOpen}
        autoHideDuration={3000}
        onClose={() => setSnackbarOpen(false)}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}
      >
        <Alert
          onClose={() => setSnackbarOpen(false)}
          severity={snackbarSeverity}
          sx={{ width: '100%' }}
        >
          {snackbarMessage}
        </Alert>
      </Snackbar>
    </Box>
  );
};

export default ModifyRules;
