import time
import requests
import uuid
import json
import os
import yaml
from config import config  # Imports from the config.py file at the top level

# --- CONFIGURATION LOADING ---
CONFIG_PATH = os.path.join(os.path.dirname(os.path.dirname(__file__)), "config.yaml")
try:
    with open(CONFIG_PATH, "r") as f:
        yaml_config = yaml.safe_load(f)
except FileNotFoundError:
    raise RuntimeError(f"Configuration file not found at {CONFIG_PATH}. Please check the path.")


# Assign values
CATALOG = yaml_config.get("catalog")
SCHEMA = yaml_config.get("schema")
RULE_TABLE = yaml_config.get("rule_table")
TABLE_CONFIG = yaml_config.get("table_config")
GROUP_TABLE = yaml_config.get("group_table")  
USER_TABLE = yaml_config.get("user_table")    

if not all([CATALOG, SCHEMA, RULE_TABLE, TABLE_CONFIG, GROUP_TABLE, USER_TABLE]):
    raise ValueError("Missing critical table configuration in config.yaml.")

# --- CORE QUERY FUNCTIONS ---

def query_table(name, query, params=None):
    """
    Executes a SQL query on Databricks using the Statement Execution API, 
    waiting for results and returning formatted data.
    """
    url = f"{config.DATABRICKS_HOST}/api/2.0/sql/statements"
    headers = {
        "Authorization": f"Bearer {config.DATABRICKS_TOKEN}",
        "Content-Type": "application/json"
    }
    payload = {
        "statement": query,
        "warehouse_id": config.SQL_WAREHOUSE_ID,
        "wait_timeout": "10s"
    }

    if params:
        payload["parameters"] = params

    res = requests.post(url, headers=headers, json=payload)
    res.raise_for_status()
    response_json = res.json()
    statement_id = response_json.get("statement_id")

    if not statement_id:
        raise Exception(f"No statement_id returned for query '{name}'")

    status_url = f"{config.DATABRICKS_HOST}/api/2.0/sql/statements/{statement_id}"

    while True:
        status_res = requests.get(status_url, headers=headers)
        status_res.raise_for_status()
        status_json = status_res.json()
        state = status_json.get("status", {}).get("state")

        if state == "SUCCEEDED":
            manifest = status_json.get("manifest", {})
            schema = manifest.get("schema", {})
            columns = [col["name"] for col in schema.get("columns", [])]
            full_result = status_json.get("result", {})
            data_array = full_result.get("data_array", [])
            formatted_data = [dict(zip(columns, row)) for row in data_array]
            return formatted_data
        elif state in ["FAILED", "CANCELED", "CLOSED"]:
            error = status_json.get("status", {}).get("error", {})
            raise Exception(f"Query '{name}' failed: {error.get('message', 'Unknown error')}")
        
        time.sleep(1)

def execute_write_query(name, query, params=None):
    """
    Executes a non-SELECT SQL query (INSERT/UPDATE/DELETE).
    Uses the same logic as query_table but returns True on success.
    """
    # This function is identical to query_table's execution flow but typically used for DML
    # Reusing query_table logic ensures consistency with the Databricks API flow.
    query_table(name, query, params)
    return True # Since query_table succeeded in this context, the write succeeded.


# ----------------------------------------------------------------------
# --- GROUP MANAGEMENT FUNCTIONS (Parameterized) -------------------------
# ----------------------------------------------------------------------

def get_groups_data(search=None, page=1, limit=10, user_id=None):
    """
    Builds and executes the SQL to get a paginated list of groups,
    with an optional search filter and a check for user subscription status.
    """
    try:
        page = int(page)
        limit = int(limit)
    except (ValueError, TypeError):
        page = 1
        limit = 10

    offset = (page - 1) * limit

    # PARAMETERIZATION: Replacing all hardcoded table paths with config variables
    base_query = f"""
        WITH FilteredGroups AS (
            SELECT
                g.group_id,
                g.group_name,
                COUNT(DISTINCT u.user_id) AS group_size,
                COUNT(DISTINCT t.catalog_name, t.schema_name, t.table_name) AS tables,
                COUNT(DISTINCT r.rule_id) AS rules,
                g.group_owner AS owner,
                g.created_at,
                -- Check if the current user is a member of the group
                CASE WHEN EXISTS (
                    SELECT 1
                    FROM {CATALOG}.{SCHEMA}.{USER_TABLE} AS user_membership
                    WHERE user_membership.user_id = :user_id AND array_contains(user_membership.group_id, g.group_id)
                ) THEN true ELSE false END AS subscription_status
            FROM
                {CATALOG}.{SCHEMA}.{GROUP_TABLE} AS g
            LEFT JOIN
                {CATALOG}.{SCHEMA}.{TABLE_CONFIG} AS t ON g.group_id = t.group_id
            LEFT JOIN
                {CATALOG}.{SCHEMA}.{USER_TABLE} AS u ON array_contains(u.group_id, g.group_id)
            -- CORRECTED JOIN: joining rules to tables, then tables to groups
            LEFT JOIN
                {CATALOG}.{SCHEMA}.{RULE_TABLE} AS r ON t.catalog_name = r.catalog_name AND t.schema_name = r.schema_name AND t.table_name = r.table_name
            WHERE 1=1
    """

    params = []
    if user_id:
        params.append({"name": "user_id", "type": "STRING", "value": user_id})

    if search:
        base_query += " AND g.group_name LIKE :search"
        params.append({"name": "search", "type": "STRING", "value": f"%{search}%"})

    final_query = base_query + f"""
            GROUP BY
                g.group_id, g.group_name, g.group_owner, g.created_at
        )
        SELECT
            *,
            (SELECT COUNT(*) FROM FilteredGroups) as total_groups
        FROM FilteredGroups
        ORDER BY created_at DESC
        LIMIT {limit} OFFSET {offset}
    """

    return query_table("get_groups_data", final_query, params)


def get_add_table_data(search=None, page=1, limit=10):
    """
    Builds the SQL to get a paginated list of tables for the "Add Table" UI.
    """
    
    offset = (page - 1) * limit

    # PARAMETERIZATION: Replacing hardcoded table paths
    base_query = f"""
        WITH FilteredTables AS (
            SELECT
                t.catalog_name,
                t.schema_name,
                t.table_name,
                collect_list(g.group_name) AS Groups
            FROM
                {CATALOG}.{SCHEMA}.{TABLE_CONFIG} AS t
            JOIN
                {CATALOG}.{SCHEMA}.{GROUP_TABLE} AS g ON t.group_id = g.group_id
            WHERE 1=1
    """
    
    params = []
    if search:
        base_query += " AND t.table_name LIKE :search"
        params.append({"name": "search", "type": "STRING", "value": f"%{search}%"})

    base_query += """
            GROUP BY
            t.catalog_name,
            t.schema_name,
            t.table_name
        )
    """

    final_query = base_query + f"""
        , TotalRows AS (
            SELECT COUNT(*) AS total_count FROM FilteredTables
        )
        SELECT
            ft.catalog_name,
            ft.schema_name,
            ft.table_name,
            ft.Groups,
            tr.total_count AS total_rows
        FROM
            FilteredTables AS ft,
            TotalRows AS tr
        ORDER BY
            ft.table_name
        LIMIT {limit} OFFSET {offset}
    """
    
    raw_data = query_table("get_add_table_data", final_query, params)
    
    # Post-process data
    for row in raw_data:
        if 'Groups' in row and isinstance(row['Groups'], str):
            try:
                row['Groups'] = json.loads(row['Groups'])
            except json.JSONDecodeError:
                row['Groups'] = [] 
                
    return raw_data

def get_all_tables_data():
    """
    Builds and executes the SQL to get a list of all tables and their associated groups.
    NOTE: Assumes the top-level CATALOG is the Unity Catalog source for 'information_schema'.
    """
    # PARAMETERIZATION: Replacing hardcoded table paths
    query = f"""
        SELECT
            t.table_catalog as catalog_name,
            t.table_schema as schema_name,
            t.table_name,
            collect_list(g.group_name) AS Groups
        FROM
            {CATALOG}.information_schema.tables AS t
        LEFT JOIN
            {CATALOG}.{SCHEMA}.{TABLE_CONFIG} AS dt 
            ON t.table_catalog = dt.catalog_name 
            AND t.table_schema = dt.schema_name 
            AND t.table_name = dt.table_name
        LEFT JOIN
            {CATALOG}.{SCHEMA}.{GROUP_TABLE} AS g 
            ON dt.group_id = g.group_id
        GROUP BY
            t.table_catalog,
            t.table_schema,
            t.table_name
        ORDER BY
            t.table_name
    """
    
    raw_data = query_table("get_all_tables_data", query)
    
    processed_tables = []
    for row in raw_data:
        processed_row = {
            "Groups": row.get('Groups', []),
            "catalog_name": row['catalog_name'],
            "schema_name": row['schema_name'],
            "table_name": row['table_name']
        }
        processed_tables.append(processed_row)
    
    return {
        "tables": processed_tables
    }


def create_group(group_details):
    """
    Handles the creation of a new group and associates users and tables.
    """
    group_id = str(uuid.uuid4())
    group_name = group_details.get("group_name")
    owner_name = group_details.get("owner_name")
    tables = group_details.get("tables", [])
    user_ids = group_details.get("user_ids", [])

    # --- Create group ---
    # PARAMETERIZATION: Use GROUP_TABLE
    group_query = f"""
        INSERT INTO {CATALOG}.{SCHEMA}.{GROUP_TABLE} (
            group_id, group_name, group_owner, created_at, subscription
        ) VALUES (
            :group_id, :group_name, :group_owner, now(), true
        )
    """
    group_params = [
        {"name": "group_id", "type": "STRING", "value": group_id},
        {"name": "group_name", "type": "STRING", "value": group_name},
        {"name": "group_owner", "type": "STRING", "value": owner_name},
    ]
    execute_write_query("create_group", group_query, group_params)

    # --- Insert tables ---
    if tables:
        # PARAMETERIZATION: Use TABLE_CONFIG
        table_insert_query = f"""
            INSERT INTO {CATALOG}.{SCHEMA}.{TABLE_CONFIG} 
            (group_id, catalog_name, schema_name, table_name)
            VALUES (:group_id, :catalog_name, :schema_name, :table_name)
        """
        for full_table_name in tables:
            try:
                # Assuming the format is 'catalog-schema-table'
                catalog_name, schema_name, table_name = full_table_name.split('-', 2)
            except ValueError:
                continue
            table_params = [
                {"name": "group_id", "type": "STRING", "value": group_id},
                {"name": "catalog_name", "type": "STRING", "value": catalog_name},
                {"name": "schema_name", "type": "STRING", "value": schema_name},
                {"name": "table_name", "type": "STRING", "value": table_name}
            ]
            execute_write_query("link_table_to_group", table_insert_query, table_params)

    # --- Update users ---
    if user_ids:
        # PARAMETERIZATION: Use USER_TABLE
        user_update_query = f"""
            UPDATE {CATALOG}.{SCHEMA}.{USER_TABLE}
            SET group_id = array_distinct(concat(group_id, array(:group_id)))
            WHERE user_id = :user_id
        """
        for user_id in user_ids:
            user_params = [
                {"name": "group_id", "type": "STRING", "value": group_id},
                {"name": "user_id", "type": "STRING", "value": user_id}
            ]
            execute_write_query("update_user_groups", user_update_query, user_params)

    return {
        "group_id": group_id,
        "group_name": group_name,
        "owner": owner_name,
        "tables_added": len(tables),
        "users_updated": len(user_ids),
        "status": "created"
    }

def get_group_by_id(group_id):
    """
    Builds and executes the SQL to get details for a single group by its ID.
    """
    if not group_id:
        raise ValueError("Group ID must be provided.")

    # PARAMETERIZATION: Use GROUP_TABLE, TABLE_CONFIG, and USER_TABLE
    query = f"""
        SELECT
            g.group_id,
            g.group_name,
            COUNT(DISTINCT u.user_id) AS group_size,
            COUNT(DISTINCT t.catalog_name, t.schema_name, t.table_name) AS tables,
            g.group_owner AS owner,
            g.created_at,
            CASE
                WHEN g.subscription = true THEN 'Unsubscribe'
                ELSE 'Subscribe'
            END AS subscription
        FROM
            {CATALOG}.{SCHEMA}.{GROUP_TABLE} AS g
        LEFT JOIN 
            {CATALOG}.{SCHEMA}.{TABLE_CONFIG} AS t ON g.group_id = t.group_id
        LEFT JOIN 
            {CATALOG}.{SCHEMA}.{USER_TABLE} AS u ON array_contains(u.group_id, g.group_id)
        WHERE
            g.group_id = :group_id
        GROUP BY
            g.group_id, g.group_name, g.group_owner, g.created_at, g.subscription
    """

    params = [
        {"name": "group_id", "type": "STRING", "value": group_id}
    ]

    result = query_table("get_group_by_id", query, params)
    
    if result:
        return result[0]
    else:
        return None
    
def get_group_tables_data(groupId, search=None):
    """
    Fetches the list of tables for a specific group, with an optional search.
    """
    # PARAMETERIZATION: Use TABLE_CONFIG
    query_parts = [
        f"""
        SELECT table_name, catalog_name, schema_name
        FROM {CATALOG}.{SCHEMA}.{TABLE_CONFIG}
        WHERE group_id = :groupId
        """
    ]
    params = [{"name": "groupId", "type": "STRING", "value": groupId}]

    if search:
        query_parts.append("""
            AND (
                table_name LIKE :search OR
                catalog_name LIKE :search OR
                schema_name LIKE :search
            )
        """)
        params.append({"name": "search", "type": "STRING", "value": f"%{search}%"})

    final_query = " ".join(query_parts)
    return query_table("get_group_tables_data", final_query, params)

def get_group_members_data(groupId, search=None):
    """
    Fetches the list of members for a specific group, with an optional search.
    """
    # PARAMETERIZATION: Use USER_TABLE
    query_parts = [
        f"""
        SELECT user_id, user_name, user_role
        FROM {CATALOG}.{SCHEMA}.{USER_TABLE}
        WHERE array_contains(group_id, :groupId)
        """
    ]
    params = [{"name": "groupId", "type": "STRING", "value": groupId}]

    if search:
        query_parts.append("AND user_name LIKE :search")
        params.append({"name": "search", "type": "STRING", "value": f"%{search}%"})

    final_query = " ".join(query_parts)
    return query_table("get_group_members_data", final_query, params)

def add_tables_to_group_data(groupId, tables_to_add):
    """
    Adds a list of tables to a specific group in the mapping table.
    """
    if not tables_to_add:
        raise ValueError("No tables provided to add.")

    for table in tables_to_add:
        # PARAMETERIZATION: Use TABLE_CONFIG
        insert_query = f"""
            INSERT INTO {CATALOG}.{SCHEMA}.{TABLE_CONFIG}
            (group_id, catalog_name, schema_name, table_name)
            VALUES (:groupId, :catalog_name, :schema_name, :table_name)
        """
        params = [
            {"name": "groupId", "type": "STRING", "value": groupId},
            {"name": "catalog_name", "type": "STRING", "value": table.get("catalog_name")},
            {"name": "schema_name", "type": "STRING", "value": table.get("schema_name")},
            {"name": "table_name", "type": "STRING", "value": table.get("table_name")}
        ]
        query_table(f"add_{table.get('table_name')}_to_group_{groupId}", insert_query, params)
        
    return {"status": "success", "message": f"{len(tables_to_add)} tables added to group."}

def add_members_to_group_data(groupId, user_ids):
    """
    Adds a group ID to the group_id array for a list of specified users.
    """
    for user_id in user_ids:
        # PARAMETERIZATION: Use USER_TABLE
        update_query = f"""
            UPDATE {CATALOG}.{SCHEMA}.{USER_TABLE}
            SET group_id = array_union(group_id, array(:groupId))
            WHERE user_id = :user_id
        """
        params = [
            {"name": "groupId", "type": "STRING", "value": groupId},
            {"name": "user_id", "type": "STRING", "value": user_id},
        ]
        query_table(f"add_user_{user_id}_to_group_{groupId}", update_query, params)

    return {
        "status": "success",
        "message": f"{len(user_ids)} members added to group."
    }


def delete_group_data(groupId):
    """
    Deletes a group and all its associated mappings and user references.
    """
    params = [{"name": "groupId", "type": "STRING", "value": groupId}]

    # 1. Delete all table mappings for this group
    # PARAMETERIZATION: Use TABLE_CONFIG
    mapping_delete_query = f"DELETE FROM {CATALOG}.{SCHEMA}.{TABLE_CONFIG} WHERE group_id = :groupId"
    query_table(f"delete_tables_{groupId}", mapping_delete_query, params)
    
    # 2. Remove the group ID from all users' group_id arrays
    # PARAMETERIZATION: Use USER_TABLE
    user_update_query = f"""
        UPDATE {CATALOG}.{SCHEMA}.{USER_TABLE}
        SET group_id = array_remove(group_id, :groupId)
        WHERE array_contains(group_id, :groupId)
    """
    query_table(f"update_users_for_group_{groupId}", user_update_query, params)

    # 3. Finally, delete the group itself
    # PARAMETERIZATION: Use GROUP_TABLE
    group_delete_query = f"DELETE FROM {CATALOG}.{SCHEMA}.{GROUP_TABLE} WHERE group_id = :groupId"
    query_table(f"delete_group_{groupId}", group_delete_query, params)

    return {"status": "success", "message": f"Group {groupId} and all associated data deleted."}

def remove_members_from_group_data(groupId, user_ids):
    """
    Removes a group ID from the group_id array for a list of specified users.
    """
    if not user_ids:
        raise ValueError("No user IDs provided.")

    for user_id in user_ids:
        # PARAMETERIZATION: Use USER_TABLE
        update_query = f"""
            UPDATE {CATALOG}.{SCHEMA}.{USER_TABLE}
            SET group_id = array_remove(group_id, :groupId)
            WHERE user_id = :user_id
        """
        params = [
            {"name": "groupId", "type": "STRING", "value": groupId},
            {"name": "user_id", "type": "STRING", "value": user_id}
        ]
        query_table(f"remove_user_{user_id}_from_group_{groupId}", update_query, params)

    return {"status": "success", "message": f"{len(user_ids)} members removed from group."}

def get_users_data():
    """
    Builds and executes the SQL to get the list of all users.
    """
    
    # PARAMETERIZATION: Use USER_TABLE
    query = f"""
        SELECT
            user_id,
            user_name
        FROM
            {CATALOG}.{SCHEMA}.{USER_TABLE}
    """
    
    return query_table("get_users", query)

def get_groups_list():
    """Simple un-paginated list of all groups (group_id + group_name) for dropdowns."""
    query = f"""
        SELECT group_id, group_name
        FROM {CATALOG}.{SCHEMA}.{GROUP_TABLE}
        ORDER BY group_name
    """
    return query_table("get_groups_list", query)